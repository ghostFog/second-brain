/* ============================================
 * 第二脑 — 文件树右键菜单（统一覆盖目录 / 笔记 / 空白区三种场景）
 * 作者: 火 冰
 * 功能:
 *   - 目录右键：在资源管理器打开 / 新建目录(该目录下) / 新建笔记(该目录下) / 删除 / 移动
 *   - 笔记右键：在资源管理器打开 / 新建笔记(同级目录下) / 删除 / 移动
 *   - 空白区右键：新建目录(根目录下) / 新建笔记(根目录下) / 显示/隐藏隐藏目录
 *   - 所有场景命中后 stopPropagation，阻断冒泡到 document，避免与 app-vault.js 旧菜单重复
 * ============================================ */

'use strict';

/* 关闭文件树右键菜单 */
function closeFileTreeContextMenu() {
  const m = document.getElementById('tree-ctx-menu');
  const ov = document.getElementById('tree-ctx-backdrop');
  if (m) m.remove();
  if (ov) ov.remove();
  // 清除注入给插件的右键目标路径（防串库/串操作）
  window.__pluginCtxNote = null;
  window.__pluginCtxFolder = null;
}

/* 便捷：构造一个普通菜单项 */
function treeSpec(label, icon, action, disabled) {
  return { label: label, icon: icon, action: action, disabled: !!disabled };
}

/* 列出全部非空目录（不含 .md 文件），用于「移动到…」子菜单 / 根目录下新建的父选择
 * 过滤掉隐藏目录（任一路径段以 . 开头，如 .obsidian/.second-brain），避免移动到隐藏目录中。
 * 作者: 火 冰 */
async function listDirs() {
  try {
    const list = await noteStore.list();
    const set = new Set();
    list.forEach(n => {
      const f = n.folder;
      if (f && !f.split('/').some(seg => seg.startsWith('.'))) set.add(f);
    });
    const dirs = Array.from(set).sort((a, b) => a.localeCompare(b, 'zh'));
    return dirs;
  } catch (_) { return []; }
}

/* 取某 slot 的插件右键菜单项；在弹菜单前把目标路径暴露给插件
 * （__pluginCtxNote/__pluginCtxFolder），供插件按目标文件/目录操作。
 * slot: 'file-tree'|'file-tree-folder'；kind: 'note'|'folder'；target: 相对库根路径（可能为空串=根）。
 * 无已启用的插件菜单项时返回 []（不产生多余分隔线）。
 * 作者: 火 冰 */
function pluginFileTreeItems(slot, kind, target) {
  if (typeof pluginManager === 'undefined' || !pluginManager || typeof pluginManager.getContextMenus !== 'function') return [];
  const items = pluginManager.getContextMenus(slot);
  if (!items || !items.length) return [];
  // 菜单项点击时会先 closeFileTreeContextMenu()（其中会把 __pluginCtxNote/__pluginCtxFolder 清空），
  // 导致插件动作里 resolveFileTarget() 取不到刚才右键的笔记。这里给每个 action（含 children 二级子项）
  // 包一层：执行前恢复目标路径，保证「右键笔记 → Git 二级菜单」各操作能拿到该笔记路径。作者: 火 冰
  const bindCtx = function (it) {
    if (!it) return;
    if (typeof it.action === 'function') {
      const orig = it.action;
      it.action = function () {
        if (kind === 'note') window.__pluginCtxNote = target;
        else if (kind === 'folder') window.__pluginCtxFolder = target;
        return orig.apply(this, arguments);
      };
    }
    if (Array.isArray(it.children)) it.children.forEach(bindCtx);
  };
  items.forEach(bindCtx);
  if (kind === 'note') window.__pluginCtxNote = target;
  else if (kind === 'folder') window.__pluginCtxFolder = target;
  return ['-', ...items];
}

/* 资源管理器定位桌面文件/目录；网页版提示仅桌面版可用。
 * main.js 的 notes:reveal 底层用 shell.showItemInFolder，对文件/目录都支持，
 * 所以统一调 revealNote 即可（参数路径若是目录，Electron 也能正确定位）。
 * 作者: 火 冰 */
function openInExplorer(path) {
  // 普通项目窗口：路径是相对项目根的 rel，必须走 project:reveal 按项目根解析；
  // 若误走 notes:reveal（按知识库根 resolveVaultPath）路径在知识库下不存在 → 静默无反应。
  if (typeof sbIsProjectMode === 'function' && sbIsProjectMode()
      && window.noteDesktop && window.noteDesktop.project && window.noteDesktop.project.reveal) {
    window.noteDesktop.project.reveal(path).catch(() => {});
    return;
  }
  const bridge = window.noteDesktop;
  if (!bridge) { showToast('该功能仅桌面版可用'); return; }
  if (bridge.revealNote) bridge.revealNote(path).catch(() => {});
  else { showToast('资源管理器定位失败'); }
}

/* 删除笔记路径对应的标签页 + 缓存；若 edCurrent 正好被删 → 切换到下一个打开笔记
 * 作者: 火 冰 */
function handleDeleteOfCurrent(path) {
  if (path !== edCurrent) return;
  edOpenTabs = edOpenTabs.filter(p => p !== path);
  delete edOutdated[path];
  edCurrent = edOpenTabs[edOpenTabs.length - 1] || null;
  renderTabs();
  if (edCurrent) renderArticle();
  else if (typeof vdSetValue === 'function') vdSetValue('');
}

/* 右键菜单 动作：删除笔记 */
async function actDeleteNote(path) {
  // 项目模式守卫：走知识库 noteStore 会误删知识库同名笔记，暂不支持
  if (sbIsProjectMode()) { showToast('项目模式暂不支持在应用内删除，请在系统资源管理器操作'); return; }
  if (!confirm('确定删除笔记「' + path.split('/').pop() + '」吗？\n（同时清理该笔记的 AI 索引）')) return;
  try {
    await noteStore.remove(path);
    showToast('已删除：' + path.split('/').pop());
  } catch (e) { showToast('删除失败：' + (e && e.message || e)); return; }
  handleDeleteOfCurrent(path);
  await refreshTreeAfterChange();
}

/* 右键菜单 动作：删除目录（递归删所有下级笔记 + 索引） */
async function actDeleteDir(dir) {
  // 项目模式守卫：走知识库 noteStore 会误删知识库同名目录，暂不支持
  if (sbIsProjectMode()) { showToast('项目模式暂不支持在应用内删除，请在系统资源管理器操作'); return; }
  if (!confirm('确定删除目录「' + dir + '」及其下所有笔记吗？\n（每篇笔记的 AI 索引将一并清理）')) return;
  try {
    const removed = await noteStore.removeDir(dir);
    showToast('已删除目录下 ' + removed + ' 篇笔记');
  } catch (e) { showToast('删除失败：' + (e && e.message || e)); return; }
  if (edCurrent && edCurrent.startsWith(dir.replace(/[\\/]+$/, '') + '/')) {
    handleDeleteOfCurrent(edCurrent);
  }
  await refreshTreeAfterChange();
}

/* 右键菜单 动作：移动笔记到新父目录（跨目录移动；若新父目录下已存在同名笔记则失败） */
async function actMoveNote(oldPath, newPath) {
  if (oldPath === newPath) return;
  // 项目模式守卫：走知识库 noteStore 会误移动知识库同名文件，暂不支持
  if (sbIsProjectMode()) { showToast('项目模式暂不支持在应用内移动，请在系统资源管理器操作'); return; }
  try {
    const ok = await noteStore.move(oldPath, newPath);
    if (!ok) { showToast('移动失败：目标可能已存在'); return; }
    showToast('已移动：' + oldPath.split('/').pop());
  } catch (e) { showToast('移动失败：' + (e && e.message || e)); return; }
  if (oldPath === edCurrent) {
    edCurrent = newPath;
    edOpenTabs = edOpenTabs.map(p => p === oldPath ? newPath : p);
    if (edOutdated[oldPath] != null) { edOutdated[newPath] = edOutdated[oldPath]; delete edOutdated[oldPath]; }
    if (edDirty.has(oldPath)) { edDirty.delete(oldPath); edDirty.add(newPath); }
    if (edMissing.has(oldPath)) { edMissing.delete(oldPath); edMissing.add(newPath); } // ED-60：丢失标记随移动迁移
    await openNote(newPath);
    renderTabs();
  }
  await refreshTreeAfterChange();
}

/* 右键菜单 动作：移动目录（整体搬到新父目录下，保留内部相对路径；禁止拖入自身子目录） */
async function actMoveDir(oldDir, newParent) {
  if ((newParent + '/').startsWith(oldDir.replace(/[\\/]+$/, '') + '/')) {
    showToast('不能把目录移动到它自己的子目录里');
    return;
  }
  // 项目模式守卫：走知识库 noteStore 会误移动知识库同名目录，暂不支持
  if (sbIsProjectMode()) { showToast('项目模式暂不支持在应用内移动，请在系统资源管理器操作'); return; }
  try {
    const moved = await noteStore.moveDir(oldDir, newParent);
    showToast('已移动目录「' + oldDir.split('/').pop() + '」' + (moved ? '（含 ' + moved + ' 篇笔记）' : ''));
  } catch (e) { showToast('移动失败：' + (e && e.message || e)); return; }
  // 同步当前打开笔记路径
  if (edCurrent && edCurrent.startsWith(oldDir.replace(/[\\/]+$/, '') + '/')) {
    const oldPrefix = oldDir.replace(/[\\/]+$/, '') + '/';
    const newDirName = oldDir.split('/').pop();
    const newPrefix = (newParent || '').replace(/[\\/]+$/, '') + '/' + newDirName + '/';
    const rel = edCurrent.slice(oldPrefix.length);
    const newPath = newPrefix + rel;
    edOpenTabs = edOpenTabs.map(p => p === edCurrent ? newPath : p);
    if (edOutdated[edCurrent] != null) { edOutdated[newPath] = edOutdated[edCurrent]; delete edOutdated[edCurrent]; }
    if (edDirty.has(edCurrent)) { /* 脏标记保持指向新路径 */ edDirty.delete(edCurrent); edDirty.add(newPath); }
    if (edMissing.has(edCurrent)) { edMissing.delete(edCurrent); edMissing.add(newPath); } // ED-60：丢失标记随目录迁移
    edCurrent = newPath;
    await openNote(newPath);
    renderTabs();
  }
  await refreshTreeAfterChange();
}

/* 变更后统一刷新文件树 + 笔记列表缓存
 * 项目模式：走项目列表刷新（sbProject.refresh → project:list），绝不能误拉知识库列表
 * 把目录树重绘成知识库内容（Bug-073「目录区变成上一次打开的知识库」的统一收口点）。
 * 作者: 火 冰 */
async function refreshTreeAfterChange() {
  if (sbIsProjectMode()) { await window.sbProject.refresh(); refreshIcons(); return; }
  edNotes = (await noteStore.list()).sort((a, b) => a.path.localeCompare(b.path, 'zh'));
  renderFileTree(edNotes);
  refreshIcons();
}

/* 绑定文件树右上角手动刷新按钮（HTML：#file-tree-refresh）。
 * 资源管理器手动增删改后，点此按钮立即重新扫描磁盘并刷新文件树，无需等 ED-60 的 10s 自动快照周期。
 * 幂等绑定：先 removeEventListener 旧 handler，防止 initEditor 重入（切视图返回）时重复绑定。
 * @author 火 冰 */
function bindFileTreeRefreshButton() {
  const btn = document.getElementById('file-tree-refresh');
  if (!btn) return;
  if (btn.__sbRefreshHandler) { btn.removeEventListener('click', btn.__sbRefreshHandler); }
  btn.__sbRefreshHandler = function () {
    btn.disabled = true;
    btn.style.opacity = '0.5';
    Promise.resolve(refreshTreeAfterChange()).then(function () {
      btn.disabled = false; btn.style.opacity = '';
    }).catch(function () { btn.disabled = false; btn.style.opacity = ''; });
  };
  btn.addEventListener('click', btn.__sbRefreshHandler);
}

/* 构建单个菜单项（支持二级子菜单 / 分隔线 / 禁用态） */
function buildTreeCtxItem(spec) {
  const el = document.createElement('div');
  if (spec === '-') { el.className = 'edit-ctx-sep'; return el; }
  el.className = 'edit-ctx-item' + (spec.disabled ? ' is-disabled' : '');
  const icon = spec.icon ? '<i data-lucide="' + spec.icon + '" class="w-3.5 h-3.5 shrink-0"></i>' : '';
  const caret = spec.children ? '<i data-lucide="chevron-right" class="ctxcaret w-3.5 h-3.5"></i>' : '';
  el.innerHTML = icon + '<span class="flex-1">' + esc(spec.label) + '</span>' + caret;
  if (spec.children) {
    const sub = document.createElement('div');
    sub.className = 'ctx-submenu';
    spec.children.forEach(cs => sub.appendChild(buildTreeCtxItem(cs)));
    el.appendChild(sub);
  }
  if (!spec.disabled && !spec.children) {
    el.addEventListener('click', e => {
      e.stopPropagation();
      closeFileTreeContextMenu();
      try { spec.action && spec.action(); } catch (_) {}
    });
  }
  return el;
}

/* 显示右键菜单（自动靠边翻转，避免溢出） */
function showFileTreeContextMenu(x, y, schema) {
  closeFileTreeContextMenu();
  const menu = document.createElement('div');
  menu.id = 'tree-ctx-menu';
  menu.className = 'edit-ctx';
  menu.style.minWidth = '180px';
  schema.forEach(s => menu.appendChild(buildTreeCtxItem(s)));
  document.body.appendChild(menu);
  const r = menu.getBoundingClientRect();
  const vw = window.innerWidth, vh = window.innerHeight;
  let left = Math.min(Math.max(8, x), Math.max(8, vw - r.width));
  let top = Math.min(Math.max(8, y), Math.max(8, vh - r.height));
  menu.style.left = left + 'px';
  menu.style.top = top + 'px';
  // 二级子菜单方向自适应：父菜单靠近右边缘/底部时，让子菜单向左/向上展开，避免超出可视区
  if (left + r.width + 210 > vw) menu.classList.add('ctx-flip-sub');
  if (top + r.height + 240 > vh) menu.classList.add('ctx-grow-up');
  // 遮罩：点击 / 右键 / 滚动 关闭
  const overlay = document.createElement('div');
  overlay.id = 'tree-ctx-backdrop';
  overlay.style.cssText = 'position:fixed;inset:0;z-index:122;';
  overlay.addEventListener('contextmenu', e => { e.preventDefault(); closeFileTreeContextMenu(); });
  overlay.addEventListener('click', closeFileTreeContextMenu);
  overlay.addEventListener('scroll', closeFileTreeContextMenu, true);
  document.body.appendChild(overlay);
  refreshIcons();
}

/* 笔记右键「打开」二级子菜单：在资源管理器打开 + 各 Provider 支持的打开方式
 * 依据该文件后缀，取 pluginManager.getEditorProviders(ext) 命中的 Provider 的 openers；
 * 无 Provider（仅兜底）时仍给出纯文本编辑；生成异常时仅保留资源管理器定位。
 * 作者: 火 冰 */
function buildOpenChildren(path) {
  const children = [treeSpec('在资源管理器打开', 'folder-open', () => openInExplorer(path))];
  try {
    const ext = (typeof fileExtension === 'function') ? fileExtension(path) : '';
    const pm = (typeof pluginManager !== 'undefined' && pluginManager && pluginManager.getEditorProviders) ? pluginManager : null;
    const prov = (pm ? pm.getEditorProviders(ext) : [])[0];
    if (prov && prov.openers) {
      prov.openers.forEach(o => {
        children.push(treeSpec(o.label, o.icon || 'file-type', () => openNote(path, { mode: o.id })));
      });
    }
  } catch (_) { /* 忽略：失败时仅保留资源管理器打开 */ }
  return children;
}

/** 重建笔记元数据（指纹对比，仅差异目录写盘）。
 *  @param {string} dir 目标目录相对路径：空串=全库重建；非空=仅重建该目录子树。
 *         资源管理器手动新增/修改/删除文件后，用本按钮对比检测、最小化写入。
 *  @author 火 冰 */
async function rebuildMeta(dir) {
  // 项目模式守卫：重建的是知识库元数据，与项目无关
  if (sbIsProjectMode()) { showToast('项目模式不使用笔记元数据，无需重建'); return; }
  const bridge = window.noteDesktop;
  const scope = String(dir || '');
  const canSub = !!(bridge && bridge.refreshDirMeta);
  const canAll = !!(bridge && bridge.refreshMeta);
  if (!canSub && !canAll) {
    if (typeof showToast === 'function') showToast('该功能仅桌面版可用');
    return;
  }
  if (typeof showToast === 'function') showToast('正在检测笔记数据…');
  try {
    // 有具体目录则只重建该子树，否则全库重建（均为对比检测，无变化不写盘）
    const result = (scope && canSub) ? await bridge.refreshDirMeta(scope, false) : await bridge.refreshMeta();
    /* 刷新文件树 UI */
    try { await refreshTreeAfterChange(); } catch (_) { /* 忽略 */ }
    if (typeof showToast === 'function') {
      const changed = result && Array.isArray(result.written) ? result.written.length : 0;
      const scanned = result && result.dirs ? result.dirs : 0;
      showToast(changed
        ? '笔记数据已更新（' + changed + ' 个目录 / 共检测 ' + scanned + ' 个）'
        : '笔记数据无变化（共检测 ' + scanned + ' 个目录）');
    }
  } catch (_) {
    if (typeof showToast === 'function') showToast('重建失败');
  }
}

/* 绑定文件树右键：在 #file-tree 上做委托，统一处理目录 / 笔记 / 空白区三种场景
 * 所有匹配场景命中后 stopPropagation，阻断冒泡到 document，确保只弹一份菜单。
 * 作者: 火 冰 */
function bindFileTreeContextMenu() {
  const root = document.getElementById('file-tree');
  if (!root) return;

  root.addEventListener('contextmenu', async e => {
    e.preventDefault();
    e.stopPropagation();                            // ★ 关键：阻断到 document，防止 app-vault.js 旧菜单再弹一份
    const folderNode = e.target.closest('.tree-folder');
    const noteNode = e.target.closest('.tree-file');

    if (folderNode) {
      // ===== 目录菜单 =====
      const targetDir = folderNode.dataset.folder || '';
      const dirs = await listDirs();
      // 移动到… 子菜单：根目录 + 全部目录，过滤自身
      const moveChildren = [
        treeSpec('根目录', 'folder', () => actMoveDir(targetDir, '')),
        ...dirs.filter(d => d !== targetDir).map(d => treeSpec(d, 'folder', () => actMoveDir(targetDir, d))),
      ];
      showFileTreeContextMenu(e.clientX, e.clientY, [
        treeSpec('在资源管理器打开', 'folder-open', () => openInExplorer(targetDir)),
        '-',
        treeSpec('新建目录', 'folder-plus', () => doNewFolder(targetDir)),
        treeSpec('新建笔记', 'file-plus', () => doNewNote(targetDir)),
        '-',
        { label: '移动到…', icon: 'move-right', children: moveChildren },
        treeSpec('重命名', 'edit-3', () => renameDirInline(targetDir)),
        '-',
        treeSpec('删除目录', 'trash-2', () => actDeleteDir(targetDir)),
        treeSpec('重建笔记数据', 'refresh-cw', () => rebuildMeta(targetDir)),
        ...pluginFileTreeItems('file-tree-folder', 'folder', targetDir),
      ]);
      return;
    }

    if (noteNode) {
      // ===== 笔记菜单 =====
      const targetPath = noteNode.dataset.path || '';
      const siblingDir = targetPath.includes('/') ? targetPath.slice(0, targetPath.lastIndexOf('/')) : '';
      const dirs = await listDirs();
      const moveChildren = [
        treeSpec('根目录', 'folder', () => actMoveNote(targetPath, targetPath.split('/').pop())),
        ...dirs.map(d => treeSpec(d, 'folder', () => actMoveNote(targetPath, (d ? d + '/' : '') + targetPath.split('/').pop()))),
      ];
      showFileTreeContextMenu(e.clientX, e.clientY, [
        { label: '打开', icon: 'folder-open', children: buildOpenChildren(targetPath) },
        '-',
        treeSpec('新建笔记', 'file-plus', () => doNewNote(siblingDir)),
        '-',
        { label: '移动到…', icon: 'move-right', children: moveChildren },
        treeSpec('重命名', 'edit-3', () => renameNoteFile(targetPath)),
        '-',
        treeSpec('删除笔记', 'trash-2', () => actDeleteNote(targetPath)),
        ...pluginFileTreeItems('file-tree', 'note', targetPath),
      ]);
      return;
    }

    // ===== 空白区菜单 =====
    const showHidden = restoreS('showHidden', false);
    showFileTreeContextMenu(e.clientX, e.clientY, [
      treeSpec('新建目录', 'folder-plus', () => doNewFolder('')),
      treeSpec('新建笔记', 'file-plus', () => doNewNote('')),
      '-',
      treeSpec((showHidden ? '隐藏隐藏目录' : '显示隐藏目录'), showHidden ? 'eye-off' : 'eye', () => toggleHiddenFiles()),
      '-',
      treeSpec('重建笔记数据', 'refresh-cw', () => rebuildMeta('')),
      ...pluginFileTreeItems('file-tree-blank', 'root', ''),
    ]);
  });

  // 全局 Escape 兜底关闭（与 edit-ctx.js / vault 菜单各自独立）
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') closeFileTreeContextMenu();
  });
}
