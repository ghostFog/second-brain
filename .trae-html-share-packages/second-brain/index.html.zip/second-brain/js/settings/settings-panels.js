/* ============================================
 * 第二脑 — 设置视图·面板 HTML
 * 作者: 火 冰
 * 功能: 各分类设置面板 HTML 生成（常规/编辑器/快捷键/同步与备份/隐私与安全/插件管理/关于/AI 问答）、
 *       文件类型主从明细、版本历史（设置-关于）
 * 说明: 与 js/settings/*.js 共享全局词法作用域（顶层声明跨文件可见）；
 *       依赖 settings-shortcuts 的 shortcutPanelHTML、settings-plugins 的 pluginMgrItemHTML、
 *       settings-ai 的 aiPathField/AI_EMBED_LIB/AI_RERANK_LIB/DEFAULT_AI_FIELDS
 * ============================================ */

'use strict';

  /* 文件类型 → 默认打开方式 映射表（后缀由插件注册，openers 来自命中 Provider）
   * 界面采用主从布局：左侧文件类型列表，右侧当前选中类型的识别模式与默认打开方式。
   * 作者: 火 冰 */
  function fileTypesHtml() {
    const pm = (typeof pluginManager !== 'undefined' && pluginManager) ? pluginManager : null;
    const exts = (pm && pm.getEditorExtensions) ? pm.getEditorExtensions() : [];
    if (!exts.length) {
      return '<div class="text-caption" style="color:var(--note-ink-3);">暂无可配置的文件类型（由插件注册编辑器后缀后出现）。</div>';
    }
    // 左侧文件类型列表项（首个默认选中）
    const items = exts.map(function (ext, i) {
      const on = i === 0 ? ' active' : '';
      return '<button type="button" class="ft-item' + on + '" data-ext="' + ext + '" style="display:block;width:100%;text-align:left;' + (on ? 'background:var(--note-brand-600);color:#FFF;' : 'color:var(--note-ink);') + '">'
        + '<span class="font-mono">*.' + ext + '</span></button>';
    }).join('');
    return '<div class="ft-panel flex gap-3">'
      + '<div class="ft-list w-44 shrink-0 rounded-lg border overflow-hidden" data-ft-list style="border-color:var(--note-border);">' + items + '</div>'
      + '<div class="ft-detail flex-1 rounded-lg border p-4" data-ft-detail style="border-color:var(--note-border);">' + renderFtDetail(exts[0]) + '</div>'
      + '</div>';
  }

  /* 渲染某个文件类型在右侧的详情：识别模式 + 来源 + 默认打开方式
   * @param {string} ext 文件后缀（不含点）
   * @returns {string} 详情 HTML */
  function renderFtDetail(ext) {
    const pm = (typeof pluginManager !== 'undefined' && pluginManager) ? pluginManager : null;
    const provs = (pm && pm.getEditorProviders) ? pm.getEditorProviders(ext) : [];
    const prov = provs[0];
    const openers = (prov && prov.openers) ? prov.openers : [];
    const src = (prov && prov.name) ? prov.name : '—';
    const saved = restoreS('openAs:' + ext, '');
    const opts = ['<option value="">跟随默认</option>'] // 空=跟随默认；首个 openable 常为「跟随默认」选择类型
      .concat(openers.map(function (o) {
        return '<option value="' + o.id + '"' + (String(o.id) === String(saved) ? ' selected' : '') + '>' + o.label + '</option>';
      })).join('');
    return '<div class="text-[14px] font-semibold mb-3" style="color:var(--note-ink);">文件类型：<span class="font-mono">*.' + esc(ext) + '</span></div>'
      + '<div class="text-caption mb-1.5" style="color:var(--note-ink-3);">识别扩展名模式</div>'
      + '<div class="font-mono text-[13px] rounded-md px-3 py-2 mb-4" style="background:var(--note-surface-2); border:1px solid var(--note-border); color:var(--note-ink);">*.' + esc(ext) + '</div>'
      + '<div class="flex items-center justify-between gap-4"><div class="flex-1"><div class="text-[13px]" style="color:var(--note-ink);">默认打开方式</div><div class="text-caption" style="color:var(--note-ink-3);">来源：' + esc(src) + '</div></div>'
      + '<select class="select-box shrink-0 ft-openSel" data-skey="openAs:' + esc(ext) + '">' + opts + '</select></div>';
  }

  /* ============================
   * 版本历史（设置-关于）
   * 数据源：js/changelog.js 暴露的全局 CHANGELOG（新→旧）。
   * ============================ */

  /** 全局版本历史数组（js/changelog.js 注入），无则回退空数组 */
  function changelog() {
    return (typeof window !== 'undefined' && window.CHANGELOG && window.CHANGELOG.length)
      ? window.CHANGELOG
      : [];
  }

  /** 当前版本号：取版本历史最新一条；无历史则回退默认 */
  function currentVersion() {
    const log = changelog();
    return (log.length ? log[0].version : '0.0.1');
  }

  /* 渲染版本历史时间线（新→旧），最大高度内可滚动 */
  function versionHistoryHtml() {
    const log = changelog();
    if (!log.length) return '<p class="text-caption" style="color:var(--note-ink-3);">暂无版本记录</p>';
    return '<div class="flex flex-col gap-3 max-h-80 overflow-y-auto pr-1">'
      + log.map(function (v) {
        const items = (v.items || []).map(function (it) {
          return '<li class="flex gap-2"><span class="shrink-0 mt-1.5 w-1.5 h-1.5 rounded-full" style="background:var(--note-ink-3);"></span>'
            + '<span class="text-caption leading-relaxed" style="color:var(--note-ink-2);">' + esc(it) + '</span></li>';
        }).join('');
        const head = (v.title ? ' · ' + esc(v.title) : '');
        return '<div class="rounded-lg border p-3" style="border-color:var(--note-border);">'
          + '<div class="flex items-center justify-between gap-2 mb-1"><span class="text-[13px] font-semibold nums" style="color:var(--note-brand-600);">v' + esc(v.version) + head + '</span>'
          + '<span class="text-caption nums shrink-0" style="color:var(--note-ink-3);">' + esc(v.date || '') + '</span></div>'
          + '<ul class="flex flex-col gap-1">' + items + '</ul></div>';
      }).join('')
      + '</div>';
  }

  /* 各分类面板 HTML */
  function settingsPanelHtml(cat) {
    // 是否具备 Ollama 运行状态管理能力（桌面桥接才有），用于生成模型刷新频率等 UI
    const canManage = typeof (window.noteDesktop && window.noteDesktop.ai && window.noteDesktop.ai.manageOllamaModel) === 'function';
    if (cat === '常规') {
      // 「外观」内容已并入「常规」（ST-33）：主题/强调色/字体/密度/Ribbon/其他 + 关闭按钮行为
      return settingsPanel(cat, CATS[cat],
        '<section class="settings-group" id="gen-sec-main">'
        + '<h3 class="text-body font-semibold mb-4" style="color: var(--note-ink);">通用</h3>'
        + '<div class="flex items-center justify-between py-3"><div class="flex-1 pr-4"><div class="text-[14px]" style="color:var(--note-ink);">关闭按钮行为</div><div class="text-caption" style="color:var(--note-ink-3);">点击右上角 × 后，是退出程序、缩小到托盘，还是每次弹框选择</div></div><div class="relative"><select class="select-box" id="close-action" data-skey="closeAction"><option value="confirm">每次询问</option><option value="quit">直接退出</option><option value="tray">缩小到托盘</option></select></div></div>'
        + '<div class="flex items-center justify-between py-3"><div class="flex-1 pr-4"><div class="text-[14px]" style="color:var(--note-ink);">开发者模式</div><div class="text-caption" style="color:var(--note-ink-3);">开启后 AI 问答显示检索时长/首token/每秒token 与资料相关度，并自动打印完整提示词（调试用）</div></div><label class="toggle"><input type="checkbox" data-skey="devMode"><span class="toggle-track"></span></label></div>'
        + '</section>'
        + '<section class="settings-group" id="gen-theme-mode">'
        + '<h3 class="text-body font-semibold mb-4" style="color: var(--note-ink);">主题模式</h3>'
        + '<div class="grid grid-cols-3 gap-3">'
        + '<div class="theme-card" data-theme-mode="dark"><div class="mb-3"><div class="w-full h-16 rounded-md overflow-hidden flex" style="border: 1px solid var(--note-border);"><div class="flex-1" style="background: #1E1E2E;"></div><div style="width: 30%; background: #2D2D3F;"></div></div></div><div class="flex items-center justify-between"><span class="text-[14px]" style="color: var(--note-ink);">深色</span><i data-lucide="check" class="theme-card-check w-4 h-4" style="color: var(--note-brand-600);"></i></div></div>'
        + '<div class="theme-card" data-theme-mode="light"><div class="mb-3"><div class="w-full h-16 rounded-md overflow-hidden flex" style="border: 1px solid var(--note-border);"><div class="flex-1" style="background: #FFFFFF;"></div><div style="width: 30%; background: #F7F7FA;"></div></div></div><div class="flex items-center justify-between"><span class="text-[14px]" style="color: var(--note-ink-2);">浅色</span><i data-lucide="check" class="theme-card-check w-4 h-4" style="color: var(--note-brand-600); display: none;"></i></div></div>'
        + '<div class="theme-card" data-theme-mode="auto"><div class="mb-3"><div class="w-full h-16 rounded-md overflow-hidden flex" style="border: 1px solid var(--note-border);"><div class="flex-1" style="background: linear-gradient(90deg, #1E1E2E 50%, #FFFFFF 50%);"></div><div style="width: 30%; background: linear-gradient(90deg, #2D2D3F 50%, #F7F7FA 50%);"></div></div></div><div class="flex items-center justify-between"><span class="text-[14px]" style="color: var(--note-ink-2);">跟随系统</span><i data-lucide="check" class="theme-card-check w-4 h-4" style="color: var(--note-brand-600); display: none;"></i></div></div>'
        + '</div></section>'
        + '<section class="settings-group" id="gen-accent-color">'
        + '<h3 class="text-body font-semibold mb-4" style="color: var(--note-ink);">强调色</h3>'
        + '<p class="text-caption mb-4" style="color: var(--note-ink-3);">选择应用主色调，影响按钮、链接和高亮元素。</p>'
        + '<div class="flex items-center gap-4 flex-wrap">'
        + '<div class="color-dot" data-accent="#7C3AED" style="background: #7C3AED;"></div>'
        + '<div class="color-dot" data-accent="#3B82F6" style="background: #3B82F6;"></div>'
        + '<div class="color-dot" data-accent="#22C55E" style="background: #22C55E;"></div>'
        + '<div class="color-dot" data-accent="#F97316" style="background: #F97316;"></div>'
        + '<div class="color-dot" data-accent="#EF4444" style="background: #EF4444;"></div>'
        + '<div class="color-dot" data-accent="#EC4899" style="background: #EC4899;"></div>'
        + '</div></section>'
        + '<section class="settings-group" id="gen-font-settings">'
        + '<h3 class="text-body font-semibold mb-4" style="color: var(--note-ink);">字体设置</h3>'
        + '<div class="mb-6"><div class="flex items-center justify-between mb-3"><div><div class="text-[14px]" style="color: var(--note-ink);">字体大小</div><div class="text-caption" style="color: var(--note-ink-3);">调整编辑器正文的字号</div></div><span id="font-size-label" class="text-mono nums px-2 py-0.5 rounded" style="background: var(--note-surface-2); color: var(--note-ink);">15px</span></div>'
        + '<div class="flex items-center gap-3"><span class="text-caption" style="color: var(--note-ink-3);">14</span><input id="font-size-slider" type="range" min="14" max="18" value="15" class="range-slider flex-1"><span class="text-caption" style="color: var(--note-ink-3);">18</span></div></div>'
        + '<div class="mb-4"><div class="flex items-center justify-between gap-4 flex-wrap"><div class="flex-1 min-w-[120px]"><div class="text-[14px]" style="color: var(--note-ink);">字体族</div><div class="text-caption" style="color: var(--note-ink-3);">编辑器正文使用的字体</div></div><div class="relative"><select id="font-family-select" class="select-box"><option>Inter</option><option>Noto Sans SC</option><option>系统默认</option></select><i data-lucide="chevron-down" class="w-4 h-4 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" style="color: var(--note-ink-3);"></i></div></div></div>'
        + '<div><div class="flex items-center justify-between gap-4 flex-wrap"><div class="flex-1 min-w-[120px]"><div class="text-[14px]" style="color: var(--note-ink);">代码字体</div><div class="text-caption" style="color: var(--note-ink-3);">代码块使用的等宽字体</div></div><div class="relative"><select id="font-mono-select" class="select-box"><option>JetBrains Mono</option><option>Fira Code</option><option>Cascadia Code</option></select><i data-lucide="chevron-down" class="w-4 h-4 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" style="color: var(--note-ink-3);"></i></div></div></div>'
        + '</section>'
        + '<section class="settings-group" id="gen-interface-density">'
        + '<h3 class="text-body font-semibold mb-4" style="color: var(--note-ink);">界面密度</h3>'
        + '<p class="text-caption mb-4" style="color: var(--note-ink-3);">调整界面元素的间距与紧凑程度。</p>'
        + '<div class="grid grid-cols-3 gap-3">'
        + '<div class="density-opt" data-skey="density" data-value="紧凑"><div class="flex items-center gap-2 mb-1"><span class="density-radio"></span><span class="text-[14px]" style="color: var(--note-ink);">紧凑</span></div><p class="text-caption" style="color: var(--note-ink-3);">更小的间距，适合小屏幕</p></div>'
        + '<div class="density-opt" data-skey="density" data-value="标准" data-active="1"><div class="flex items-center gap-2 mb-1"><span class="density-radio"></span><span class="text-[14px]" style="color: var(--note-ink);">标准</span></div><p class="text-caption" style="color: var(--note-ink-3);">平衡的间距与可读性</p></div>'
        + '<div class="density-opt" data-skey="density" data-value="舒适"><div class="flex items-center gap-2 mb-1"><span class="density-radio"></span><span class="text-[14px]" style="color: var(--note-ink);">舒适</span></div><p class="text-caption" style="color: var(--note-ink-3);">更宽松的间距，缓解视觉疲劳</p></div>'
        + '</div></section>'
        + '<section class="settings-group" id="gen-ribbon-navigation-bar">'
        + '<h3 class="text-body font-semibold mb-4" style="color: var(--note-ink);">Ribbon 导航栏</h3>'
        + '<p class="text-caption mb-4" style="color: var(--note-ink-3);">左侧导航按钮支持拖拽排序和置顶，设置按钮始终固定在最后。超过最大数量的按钮会折叠到三点菜单中，点击可展开查看并切换。排序和置顶会自动保存，下次启动保持不变。</p>'
        + '<div class="mb-6"><div class="flex items-center justify-between mb-3"><div><div class="text-[14px]" style="color: var(--note-ink);">最大显示数量</div><div class="text-caption" style="color: var(--note-ink-3);">含设置按钮，范围 7-15</div></div><span id="ribbon-max-label" class="text-mono nums px-2 py-0.5 rounded" style="background: var(--note-surface-2); color: var(--note-ink);">7</span></div>'
        + '<div class="flex items-center gap-3"><span class="text-caption" style="color: var(--note-ink-3);">7</span><input id="ribbon-max-slider" type="range" min="7" max="15" value="7" class="range-slider flex-1"><span class="text-caption" style="color: var(--note-ink-3);">15</span></div></div>'
        + '<div class="text-caption" style="color: var(--note-ink-3);"><strong style="color: var(--note-ink-2);">操作提示：</strong>拖拽按钮图标可重新排序，右键按钮可置顶 / 取消置顶，设置按钮不可移动。</div>'
        + '</section>'
        + '<section class="settings-group" id="gen-other">'
        + '<h3 class="text-body font-semibold mb-4" style="color: var(--note-ink);">其他</h3>'
        + '<div class="flex flex-col gap-1">'
        + '<div class="flex items-center justify-between py-3"><div class="flex-1 pr-4"><div class="text-[14px]" style="color: var(--note-ink);">减少动画</div><div class="text-caption" style="color: var(--note-ink-3);">降低界面过渡与动画强度</div></div><label class="toggle"><input type="checkbox" data-skey="reduceMotion"><span class="toggle-track"></span></label></div>'
        + '<div class="border-t py-3" style="border-color:var(--note-border);"><div class="text-[14px]" style="color: var(--note-ink);">运行日志目录</div><div class="text-caption mb-2" style="color: var(--note-ink-3);">git 操作失败等运行日志写入位置，留空使用默认目录</div><div class="flex items-center gap-2"><input id="gen-logdir" type="text" placeholder="默认：userData/logs" autocomplete="off" class="flex-1 px-2 py-1.5 rounded text-[13px]" style="color:var(--note-ink);background:var(--note-surface-2);border:1px solid var(--note-border);"><button data-saction="pick-logdir" class="px-3 py-1.5 rounded text-[12px] shrink-0 border" style="color:var(--note-ink-2);background:var(--note-surface-2);border-color:var(--note-border);">浏览…</button><button data-saction="set-logdir" class="px-3 py-1.5 rounded text-[12px] shrink-0" style="background:var(--note-brand-600);color:#FFFFFF;">保存目录</button><button data-saction="view-log" class="px-3 py-1.5 rounded text-[12px] shrink-0 border" style="color:var(--note-ink-2);background:var(--note-surface-2);border-color:var(--note-border);">查看</button></div></div>'
        + '<div class="border-t py-3" style="border-color:var(--note-border);"><div class="text-[14px]" style="color: var(--note-ink);">单日志文件大小(MB)</div><div class="text-caption mb-2" style="color: var(--note-ink-3);">单份日志（app.log / error.log）超限自动轮换拆分（旧文件 → .1），默认 5</div><div class="flex items-center gap-2"><input id="gen-logmax" type="number" min="1" max="1024" step="1" placeholder="5" class="w-24 px-2 py-1.5 rounded text-[13px]" style="color:var(--note-ink);background:var(--note-surface-2);border:1px solid var(--note-border);"><button data-saction="set-logmax" class="px-3 py-1.5 rounded text-[12px] shrink-0" style="background:var(--note-brand-600);color:#FFFFFF;">保存</button></div></div>'
        + '</div>'
        + '</section>');
    }
    if (cat === '编辑器') {
      return settingsPanel(cat, CATS[cat],
        '<section class="settings-group"><h3 class="text-body font-semibold mb-4" style="color:var(--note-ink);">编辑基础</h3>'
        + '<div class="flex items-center justify-between py-3"><div class="flex-1 pr-4"><div class="text-[14px]" style="color:var(--note-ink);">默认编辑模式</div><div class="text-caption" style="color:var(--note-ink-3);">打开笔记时的初始模式</div></div><div class="relative"><select class="select-box" data-skey="edMode"><option>编辑</option><option>预览</option></select></div></div>'
        + tgRow('自动保存', '编辑后自动写入磁盘', true, 'edAutoSave')
        + tgRow('智能列表延续', '回车自动延续列表缩进', true, 'smartList')
        + tgRow('显示行号', '代码块显示行号序号', true, 'codeLineNumbers')
        + tgRow('代码块内容换行', '长代码自动折行（关闭时横向滚动）', false, 'codeWrap')
        + '</section>'
        + '<section class="settings-group"><h3 class="text-body font-semibold mb-4" style="color:var(--note-ink);">文件类型</h3>'
        + '<div class="text-caption mb-2" style="color:var(--note-ink-3);">不同后缀文件的默认打开方式（由插件注册）</div>'
        + fileTypesHtml()
        + '</section>');
    }
    if (cat === '快捷键') {
      return settingsPanel(cat, CATS[cat], shortcutPanelHTML());
    }
    if (cat === '同步与备份') {
      return settingsPanel(cat, CATS[cat],
        '<section class="settings-group">'
        + tgRow('自动同步', '笔记变更后自动云端同步', true, 'autoSync')
        + '<div class="border-t flex items-center justify-between py-3" style="border-color:var(--note-border);"><div class="flex-1 pr-4"><div class="text-[14px]" style="color:var(--note-ink);">同步间隔</div><div class="text-caption" style="color:var(--note-ink-3);">云端同步检查频率</div></div><div class="relative"><select class="select-box" data-skey="syncInterval"><option>每 5 分钟</option><option>每 10 分钟</option><option>每 30 分钟</option></select></div></div>'
        + '<div class="border-t pt-4" style="border-color:var(--note-border);"><button class="w-full flex items-center justify-center gap-1.5 py-2.5 rounded-md text-[13px] font-medium" data-saction="sync-now" style="background:var(--note-brand-600); color:#FFFFFF;"><i data-lucide="refresh-cw" class="w-4 h-4"></i>立即同步</button></div></section>'
        + '<section class="settings-group"><div class="flex items-center justify-between mb-3"><h3 class="text-body font-semibold" style="color:var(--note-ink);">本地备份</h3><button class="px-3 py-1.5 rounded-md text-caption border hover:opacity-80" data-saction="backup" style="border-color:var(--note-border); color:var(--note-ink-2); background:var(--note-surface-2);">备份到本地</button></div><p class="text-caption" style="color:var(--note-ink-3);">备份目录：笔记库根目录 /backups</p></section>');
    }
    if (cat === '隐私与安全') {
      return settingsPanel(cat, CATS[cat],
        '<section class="settings-group">'
        + tgRow('插件沙箱', '隔离插件权限，降低风险', true, 'pluginSandbox')
        + tgRow('应用通知', '允许应用发送系统通知', false, 'appNotify')
        + tgRow('崩溃报告', '匿名提交崩溃与错误报告', false, 'crashReport')
        + '</section>'
        // 应用密码（SEC-01/02）：密码本地 scrypt 哈希存储；开启后启动/超时需输入密码
        + '<section class="settings-group" id="sec-group">'
        + '<div class="flex items-center justify-between mb-3"><h3 class="text-body font-semibold" style="color:var(--note-ink);">应用密码</h3><span id="sec-status" class="text-[11px] px-2 py-0.5 rounded-full border" style="border-color:var(--note-border); color:var(--note-ink-3); background:var(--note-surface-2);">检测中…</span></div>'
        + '<p class="text-caption mb-2" style="color:var(--note-ink-3);">开启后，每次打开应用或超时自动锁定后都需输入密码。密码仅本地存储，忘记无法找回。</p>'
        + '<div class="border-t pt-3" style="border-color:var(--note-border);"><div id="sec-actions"></div></div>'
        // 超时锁定
        + '<div class="border-t flex items-center justify-between py-3" style="border-color:var(--note-border);"><div class="flex-1 pr-4"><div class="text-[14px]" style="color:var(--note-ink);">超时自动锁定</div><div class="text-caption" style="color:var(--note-ink-3);">无操作达到设定时间后锁定（需已设置密码）</div></div><label class="toggle"><input type="checkbox" id="sec-lock-enable"><span class="toggle-track"></span></label></div>'
        + '<div class="border-t flex items-center justify-between py-3" style="border-color:var(--note-border);"><div class="flex-1 pr-4"><div class="text-[14px]" style="color:var(--note-ink);">锁定时间（分钟）</div><div class="text-caption" style="color:var(--note-ink-3);">范围 1 - 120</div></div><input type="number" id="sec-lock-min" min="1" max="120" class="rounded-md px-3 py-1.5 text-[13px] outline-none nums" style="width:88px;background:var(--note-surface-2); border:1px solid var(--note-border); color:var(--note-ink);"></div>'
        + '</section>'
        // 笔记加密（ENC-02）：笔记加密密码按库设置，加密存储；落盘内容加密、读取解密
        + '<section class="settings-group" id="enc-group">'
        + '<div class="flex items-center justify-between mb-3"><h3 class="text-body font-semibold" style="color:var(--note-ink);">笔记加密</h3><span id="enc-status" class="text-[11px] px-2 py-0.5 rounded-full border" style="border-color:var(--note-border); color:var(--note-ink-3); background:var(--note-surface-2);">检测中…</span></div>'
        + '<p class="text-caption mb-2" style="color:var(--note-ink-3);">开启后，本知识库的笔记以加密形式写入磁盘（按库设置），库根 .vault-enc.json 记录已加密文件列表。密码仅本地加密存储，忘记无法找回；取消密码时已加密笔记将解密还原为明文。</p>'
        + '<div class="border-t pt-3" style="border-color:var(--note-border);"><div id="enc-actions"></div></div>'
        // 盐来源：未设应用密码用固定盐，设置应用密码后以其明文为盐（取消应用密码自动还原）
        + '<div class="border-t flex items-center justify-between py-3" style="border-color:var(--note-border);"><div class="flex-1 pr-4"><div class="text-[14px]" style="color:var(--note-ink);">盐来源</div><div class="text-caption" style="color:var(--note-ink-3);">未设置应用密码时用固定盐；设置应用密码后以其明文作为盐，取消应用密码时自动还原固定盐</div></div><span id="enc-salt" class="text-[11px] px-2 py-0.5 rounded-full border" style="border-color:var(--note-border); color:var(--note-ink-3); background:var(--note-surface-2);">-</span></div>'
        + '</section>');
    }
    if (cat === '插件管理') {
      const installed = (pluginData || []).filter(p => p.installed);
      const list = installed.length
        ? installed.map(pluginMgrItemHTML).join('')
        : '<p class="text-[13px] p-4" style="color:var(--note-ink-3);">尚未安装任何插件</p>';
      return settingsPanel(cat, CATS[cat],
        '<section class="settings-group"><div class="flex items-center justify-between mb-3"><h3 class="text-body font-semibold" style="color:var(--note-ink);">已安装插件</h3><span class="text-[11px] nums" style="color:var(--note-ink-3);">' + installed.length + ' 个</span></div>'
        + '<div class="rounded-lg border" style="border-color:var(--note-border);">' + list + '</div></section>');
    }
    if (cat === '关于') {
      const cl = changelog();
      return settingsPanel(cat, CATS[cat],
        '<section class="settings-group flex items-center gap-4"><div class="w-14 h-14 rounded-xl flex items-center justify-center" style="background:var(--note-brand-600);"><i data-lucide="brain" class="w-7 h-7" style="color:#FFFFFF;"></i></div>'
        + '<div><div class="text-h3 font-semibold" style="color:var(--note-ink);">第二脑</div><div class="text-caption" style="color:var(--note-ink-3);">版本 ' + esc(currentVersion()) + ' · Electron 桌面版</div></div></section>'
        + '<section class="settings-group"><p class="text-caption leading-relaxed" style="color:var(--note-ink-2);">一个本地优先的 Markdown 第二大脑，专注于快速记录、双向链接与知识图谱的流通。</p></section>'
        + '<section class="settings-group"><div class="flex items-center justify-between mb-3"><h3 class="text-body font-semibold" style="color:var(--note-ink);">版本历史</h3><span class="text-[11px] nums" style="color:var(--note-ink-3);">共 ' + cl.length + ' 个版本</span></div>' + versionHistoryHtml() + '</section>');
    }
    if (cat === 'AI 问答') {
      return settingsPanel(cat, CATS[cat],
        '<section class="settings-group" id="ai-sec-local">'
        + '<div class="flex items-center justify-between mb-4"><h3 class="text-body font-semibold" style="color:var(--note-ink);">本地模型</h3>'
        + '<span id="ai-cfg-status" class="text-[11px] px-2 py-0.5 rounded-full border" style="border-color:var(--note-border); color:var(--note-ink-3); background:var(--note-surface-2);">未加载</span></div>'
        // 模型下载目录：嵌入模型仓库下载落盘位置（默认 userData/models）
        + '<div class="border-t py-3" style="border-color:var(--note-border);">'
        + '<div class="text-[14px]" style="color:var(--note-ink);">模型下载目录</div>'
        + '<div class="text-caption mb-2" style="color:var(--note-ink-3);">嵌入模型仓库下载落盘位置。默认：应用程序数据目录 / models</div>'
        + '<div class="flex items-center gap-2">'
        + '<input type="text" data-ai-cfg="modelDir" placeholder="应用程序数据目录 / models" class="flex-1 rounded-md px-3 py-2 text-[13px] outline-none" style="background:var(--note-surface-2); border:1px solid var(--note-border); color:var(--note-ink);">'
        + '<button data-model-ai="pick" class="flex items-center gap-1 px-2.5 py-2 rounded-md text-[12px] font-medium shrink-0" style="border:1px solid var(--note-border); color:var(--note-ink-2); background:var(--note-surface-2);"><i data-lucide="folder-open" class="w-3.5 h-3.5"></i>选择</button>'
        + '<button data-model-ai="reveal" class="flex items-center gap-1 px-2.5 py-2 rounded-md text-[12px] font-medium shrink-0" style="border:1px solid var(--note-border); color:var(--note-ink-2); background:var(--note-surface-2);"><i data-lucide="external-link" class="w-3.5 h-3.5"></i>打开</button>'
        + '</div></div>'
        // 嵌入式模型库：默认 4 个可下载模型
        + '<div class="border-t pt-4 mt-1" style="border-color:var(--note-border);">'
        + '<div class="text-[14px]" style="color:var(--note-ink);">嵌入式模型库</div>'
        + '<div class="text-caption mb-2" style="color:var(--note-ink-3);">常用中文向量化模型，可下载到上方目录后点「使用」设为嵌入模型。</div>'
        + '<div id="ai-model-lib" class="flex flex-col gap-2"></div>'
        + '</div>'
        // 重排序模型库：默认 1 个可下载模型
        + '<div class="border-t pt-4 mt-1" style="border-color:var(--note-border);">'
        + '<div class="text-[14px]" style="color:var(--note-ink);">重排序模型库</div>'
        + '<div class="text-caption mb-2" style="color:var(--note-ink-3);">用于检索结果精排，可下载到上方目录后点「使用」设为重排序模型。</div>'
        + '<div id="ai-rerank-lib" class="flex flex-col gap-2"></div>'
        + '</div>'
        + '<div class="rounded-lg border px-3 py-2.5 my-2.5 flex items-center justify-between gap-4" style="border-color:var(--note-border); background:var(--note-surface-2);">'
        + '<div><div class="text-[14px]" style="color:var(--note-ink);">自动加载</div>'
        + '<div class="text-caption" style="color:var(--note-ink-3);">应用启动时自动加载嵌入模型</div></div>'
        + '<label class="ai-switch shrink-0" title="应用启动时自动加载嵌入模型"><input type="checkbox" data-ai-cfg="autoLoadEmbedding"><span class="ai-switch-slider"></span></label></div>'
        + aiPathField('嵌入模型路径', '模型库点「使用」会以 {modelDir}/模型 变量填入；也可手动选择本地模型目录。{modelDir} 指上方下载目录，加载时自动展开为实际路径', 'embedModelPath', DEFAULT_AI_FIELDS.embedModelPath)
        + aiPathField('重排序模型路径', '模型库点「使用」会以 {modelDir}/模型 变量填入；也可手动选择本地模型目录。{modelDir} 指上方下载目录', 'rerankModelPath', DEFAULT_AI_FIELDS.rerankModelPath)
        + '<div class="border-t pt-4 mt-2" style="border-color:var(--note-border);">'
        + '<button class="flex items-center justify-center gap-1.5 py-2.5 rounded-md text-[13px] font-medium w-full" data-ai-saction="load" style="background:var(--note-brand-600); color:#FFFFFF;"><i data-lucide="cpu" class="w-4 h-4"></i>加载嵌入模型</button></div>'
        + '</section>'
        + '<section class="settings-group" id="ai-sec-gen">'
        + '<div class="flex items-center justify-between mb-3"><h3 class="text-body font-semibold" style="color:var(--note-ink);">生成模型</h3>'
        + '<div class="flex items-center gap-2">'
        + (canManage ? '<label class="flex items-center gap-1 text-[11px] shrink-0" style="color:var(--note-ink-3);" title="自动刷新各组模型的运行状态（加载/卸载按钮随状态显示）">刷新频率<input type="number" min="1" max="3600" data-ai-cfg="modelRefreshSec" class="w-14 px-1.5 py-1 text-[11px] nums text-center rounded-md outline-none" style="background:var(--note-surface-2); border:1px solid var(--note-border); color:var(--note-ink);">秒</label>' : '')
        + '<button class="flex items-center gap-1 px-2.5 py-1.5 rounded-md text-[12px] font-medium" data-ai-saction="add" style="background:var(--note-brand-600); color:#FFFFFF;"><i data-lucide="plus" class="w-3.5 h-3.5"></i>添加模型</button>'
        + '</div></div>'
        + '<div id="ai-model-list" class="rounded-lg border divide-y" style="border-color:var(--note-border);"></div>'
        + '<p class="text-caption mt-2" style="color:var(--note-ink-3);">支持配置多个生成模型（本地 Ollama / 远程 OpenAI 兼容），在问答页顶部切换。列表展示供应商与模型名称。</p>'
        + '<div class="flex items-center justify-between mt-3">'
        + '<div><div class="text-[14px]" style="color:var(--note-ink);">启动常驻</div>'
        + '<div class="text-caption" style="color:var(--note-ink-3);">应用启动时自动常驻最后使用的问答模型（Ollama keep_alive=-1，加速首次问答）</div></div>'
        + '<label class="ai-switch shrink-0" title="应用启动时自动常驻最后使用的问答模型"><input type="checkbox" data-ai-cfg="autoResidentOnStart" checked><span class="ai-switch-slider"></span></label></div>'
        + '<div class="flex items-center justify-between mt-3">'
        + '<div><div class="text-[14px]" style="color:var(--note-ink);">携带历史数据</div>'
        + '<div class="text-caption" style="color:var(--note-ink-3);">AI 问答时携带上文对话历史（关闭则每轮只发送当前问题，顶栏开关同步此设置）</div></div>'
        + '<label class="ai-switch shrink-0" title="问答时是否携带上文对话历史"><input type="checkbox" data-ai-cfg="carryHistory" checked><span class="ai-switch-slider"></span></label></div>'
        + '</section>'
        + '<section class="settings-group" id="ai-sec-agent">'
        + '<div class="flex items-center justify-between mb-3"><h3 class="text-body font-semibold" style="color:var(--note-ink);">Agent 配置</h3>'
        + '<button class="flex items-center gap-1 px-2.5 py-1.5 rounded-md text-[12px] font-medium" data-ai-saction="agent-add" style="background:var(--note-brand-600); color:#FFFFFF;"><i data-lucide="plus" class="w-3.5 h-3.5"></i>添加 Agent</button>'
        + '</div>'
        + '<div id="ai-agent-list" class="rounded-lg border divide-y" style="border-color:var(--note-border);"></div>'
        + '<p class="text-caption mt-2" style="color:var(--note-ink-3);">Agent 是自定义角色助手：为每个 Agent 配置名称与系统提示词（角色设定/行为指令），问答时作为系统提示词注入。AI 问答页底部可切换使用哪个 Agent；未配置时使用默认助手。</p>'
        + '</section>'
        + '<section class="settings-group" id="ai-sec-index">'
        + '<div class="flex items-center justify-between mb-3"><h3 class="text-body font-semibold" style="color:var(--note-ink);">知识库索引</h3><span id="ai-index-status" class="text-[11px] nums" style="color:var(--note-ink-3);">0 片段</span></div>'
        + '<p class="text-caption mb-4" style="color:var(--note-ink-3);">把笔记库全部 Markdown 切分并向量化，供语义检索使用。</p>'
        + '<div class="flex items-center justify-between py-3 mb-1"><div><div class="text-[14px]" style="color:var(--note-ink);">相关度阈值</div><div class="text-caption" style="color:var(--note-ink-3);">检索相关度低于该值的索引块不作为参考资料（0=不过滤，建议 30~50）</div></div><div class="flex items-center gap-1 shrink-0"><input type="number" min="0" max="100" data-ai-cfg="minSimilarity" class="w-16 px-2 py-1.5 text-[12px] nums text-center rounded-md outline-none" style="background:var(--note-surface-2); border:1px solid var(--note-border); color:var(--note-ink);"><span class="text-caption" style="color:var(--note-ink-3);">%</span></div></div>'
        + '<div class="border-t pt-3 mb-1"><div class="text-[14px]" style="color:var(--note-ink);">索引分块默认参数</div><div class="text-caption mb-2" style="color:var(--note-ink-3);">未单独设置的笔记，按此参数生成索引块。</div>'
        + '<div class="grid grid-cols-2 gap-2">'
        + '<div><div class="text-caption mb-1" style="color:var(--note-ink-3);">块大小（字符）</div><input type="number" min="1" data-ai-cfg="blockSize" class="w-full rounded-md px-3 py-2 text-[13px] nums outline-none" placeholder="200" style="background:var(--note-surface-2); border:1px solid var(--note-border); color:var(--note-ink);"></div>'
        + '<div><div class="text-caption mb-1" style="color:var(--note-ink-3);">相邻重叠（字符）</div><input type="number" min="0" data-ai-cfg="overlap" class="w-full rounded-md px-3 py-2 text-[13px] nums outline-none" placeholder="40" style="background:var(--note-surface-2); border:1px solid var(--note-border); color:var(--note-ink);"></div>'
        + '</div>'
        + '<div class="mt-2 grid grid-cols-2 gap-2">'
        + '<div><div class="text-caption mb-1" style="color:var(--note-ink-3);">切分策略</div><select data-ai-cfg="chunkStrategy" class="w-full rounded-md px-2 py-2 text-[13px] outline-none" title="语义分块按标题/段落/句末切分并注入文件名与标题上下文" style="background:var(--note-surface-2); border:1px solid var(--note-border); color:var(--note-ink);"><option value="fixed">固定字符</option><option value="semantic">语义分块</option></select></div>'
        + '<div><div class="text-caption mb-1" style="color:var(--note-ink-3);">单块长度上限（字符）</div><input type="number" min="0" data-ai-cfg="maxChunkSize" class="w-full rounded-md px-3 py-2 text-[13px] nums outline-none" placeholder="300" title="全局统一；0 或留空表示不限制；>0 时每块的宽度不超过块大小与该值的较小者，避免单块过长；语义分块下同样生效" style="background:var(--note-surface-2); border:1px solid var(--note-border); color:var(--note-ink);"></div>'
        + '</div></div>'
        + '<p class="text-caption mt-2" style="color:var(--note-ink-3);">「语义分块」按标题 / 段落 / 句末切分并注入文件名与标题上下文，忽略「相邻重叠」；单块长度上限仍生效。</p>'
        + '<button class="flex items-center justify-center gap-1.5 py-2.5 rounded-md text-[13px] font-medium w-full" data-ai-saction="rebuild" style="background:var(--note-brand-600); color:#FFFFFF;"><i data-lucide="refresh-cw" class="w-4 h-4"></i>重建索引</button>'
        + '<button class="flex items-center justify-center gap-1.5 py-2.5 rounded-md text-[13px] font-medium w-full border mt-2" data-ai-saction="save" style="border-color:var(--note-border); color:var(--note-ink-2); background:var(--note-surface-2);"><i data-lucide="save" class="w-4 h-4"></i>保存配置</button>'
        + '</section>');
    }
    return '';
  }
