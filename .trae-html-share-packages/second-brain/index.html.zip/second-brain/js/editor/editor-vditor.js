﻿/* ============================================
 * 第二脑 — Markdown 编辑引擎 vditor 桥接 + .md Provider
 * 作者: 火 冰
 * 功能:
 *   - 引入开源引擎 vditor（node_modules/vditor/dist，npm 运行时依赖）作为 Markdown 编辑区唯一渲染/编辑实现，
 *     整体承接原自研「源码 textarea + 所见即所得 + 预览」三套 DOM 与全部自研编辑增强。
 *   - 以宿主桥接函数（vdInit / vdSyncValue / vdSetMode / vdSetSource / vdToggleSource / vdGetValue / vdSetValue）驱动 vditor。
 *   - 模式映射：宿主 编辑→ir、分屏→sv(+both)、预览→preview。
 *   - 静态注册 .md/.markdown 的编辑器 Provider（桌面版与网页版共用，保证双端一致）。
 * 说明:
 *   - 依赖 create/ further host globals：edOutdated / edCurrent / restoreS / onEdInput / renderMarkdown / registerEditorProvider。
 *   - renderMarkdown(app-note.js) 仅保留给 AI 问答等非编辑区展示，此处仅作 Provider 契约薄实现。
 * ============================================ */
'use strict';

(function () {
  /** @type {Object|null} vditor 实例（懒创建，首次进入编辑区才 new） */
  let vdInst = null;
  /** @type {string} vditor 编辑节点模式：'ir'(即时渲染) | 'wysiwyg'(所见即所得) | 'sv'(源码分屏) */
  let vdMode = 'ir';
  /** @type {string} 编辑子节点偏好（「编辑」按钮冒泡子菜单选中的编辑节点）：'ir' | 'wysiwyg'，默认 IR */
  let vdEditorNode = 'ir';
  /** @type {string} vditor 视图布局：'editor'(仅编辑) | 'both'(分屏) | 'preview'(纯预览) */
  let vdPreview = 'editor';
  /** @type {string} 实例未创建时的内容暂存缓冲（切换/重建时保内容不丢） */
  let vdBuffer = '';
  /** @type {boolean} vditor 是否已完成首帧异步渲染（options.after 后置为 true）；
   *  未就绪时 vdSyncValue 的内容先暂存 vdPending，避免被首发渲染重启清空 */
  let vdReady = false;
  /** @type {string|null} 待 vditor 异步渲染完成后补渲的内容（启动/快速切换时序缓冲） */
  let vdPending = null;
  /** @type {number} 构建序号自增：标记「当前最新一次 buildVditor」，供异步 after 判断是否本实例，防止旧实例乱序抢占 */
  let vdBuildSeq = 0;
  /** @type {number|null} window.Vditor 脚本未就绪时的延迟重试构建 timer（Bug-075 启动竞态空白修复） */
  let vdBuildRetryTimer = null;
  /** @type {number} 重试剩余次数：500ms × 60 = 30s 上限，避免无限轮询 */
  let vdBuildRetryLeft = 0;

  /* ★ Bug-080: copy 事件拦截——当选中范围涉及表格 TD/TH 时，
   * 用 tab 分隔的 text/plain + 完整 text/html 覆盖 vditor 的 Markdown-only 格式。
   * vditor 原生 copy 会用 lute 把 IR DOM 转 Markdown 放 text/plain，还故意把 text/html 清空！
   * 导致我们 paste 时拿不到 tab 分隔的 grid。这里在 capture 阶段先拦住，自己写正确格式。
   * 作者: 火 冰 */
  document.addEventListener('copy', function (e) {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return;
    const range = sel.getRangeAt(0);
    if (range.collapsed) return; // 没选中内容

    // 判断选中范围内是否有 TD/TH
    const container = range.commonAncestorContainer;
    const containerEl = container.nodeType === 3 ? container.parentElement : container;
    if (!containerEl) return;
    const inTable = containerEl.closest && containerEl.closest('TABLE');
    if (!inTable) return; // 不在表格里 → 放行

    // ★ 关键判断：如果 Selection 的 anchor 和 focus 都在**同一个** TD/TH 内 → 放行！
    // 这种情况是用户在单元格内选中了部分文本（或整 cell 文本），
    // 应该让浏览器/vditor 正常复制选中的文本，而不是触发我们的"整表格"复制逻辑。
    // 只有跨了 cell 边界（选中了多个 cells）才需要拦截改写 clipboardData。
    const anchorEl = sel.anchorNode && (sel.anchorNode.nodeType === 3 ? sel.anchorNode.parentElement : sel.anchorNode);
    const focusEl = sel.focusNode && (sel.focusNode.nodeType === 3 ? sel.focusNode.parentElement : sel.focusNode);
    const anchorCell = anchorEl && (anchorEl.closest && (anchorEl.closest('TD') || anchorEl.closest('TH')));
    const focusCell = focusEl && (focusEl.closest && (focusEl.closest('TD') || focusEl.closest('TH')));
    if (anchorCell === focusCell) {
      return; // 同一个 cell 内 → 放行
    }

    // 收集选中范围内所有 TD/TH
    const selectedCells = [];
    const walker = document.createTreeWalker(inTable, NodeFilter.SHOW_ELEMENT, {
      acceptNode: function (node) {
        const tag = node.tagName;
        if (tag !== 'TD' && tag !== 'TH') return NodeFilter.FILTER_SKIP;
        // 安全判断：cell 是否被 range 选中
        // 某些 Electron/Chrome 版本 Range.intersectsNode 参数校验很严，
        // 用 compareBoundaryPoints 替代更稳定
        try {
          const cellRange = document.createRange();
          cellRange.selectNodeContents(node);
          // 如果 range 与 cellRange 有交集 → 选中
          if (cellRange.compareBoundaryPoints(Range.END_TO_START, range) < 0 &&
              cellRange.compareBoundaryPoints(Range.START_TO_END, range) > 0) {
            return NodeFilter.FILTER_ACCEPT;
          }
        } catch (_) { /* 忽略 range 异常 */ }
        return NodeFilter.FILTER_SKIP;
      }
    });
    let node;
    while ((node = walker.nextNode())) selectedCells.push(node);
    if (selectedCells.length === 0) return;

    // 阻止 vditor 的 copy 处理（它会写 Markdown 格式，我们要 tab 分隔）
    e.stopPropagation();
    e.preventDefault();

    // 计算选中 cells 的矩形范围（在 tableEl 坐标系里的最小行/列到最大行/列）
    const trs = inTable.rows;
    let minRow = Infinity, maxRow = -1, minCol = Infinity, maxCol = -1;
    const cellPos = new Map(); // cellElement → [row, col]
    for (let i = 0; i < trs.length; i++) {
      for (let j = 0; j < trs[i].cells.length; j++) {
        const c = trs[i].cells[j];
        if (selectedCells.includes(c)) {
          cellPos.set(c, [i, j]);
          if (i < minRow) minRow = i;
          if (i > maxRow) maxRow = i;
          if (j < minCol) minCol = j;
          if (j > maxCol) maxCol = j;
        }
      }
    }

    // 构建 tab 分隔的 text/plain 和 HTML 表格
    // ★ 关键：text/plain 里单元格内的换行必须转成 <br>，不能用真实 \n
    // 否则 paste 时 \n 分行会把 cell 内换行误判为行分隔
    const textLines = [];
    const htmlRows = [];
    for (let r = minRow; r <= maxRow; r++) {
      const textCells = [];
      const htmlCells = [];
      for (let c = minCol; c <= maxCol; c++) {
        const cell = trs[r] && trs[r].cells[c];
        if (cell) {
          // cell.innerText 保留单元格内换行（真实 \n），转 <br> 避免与行分隔 \n 混淆
          const plainVal = (cell.innerText || '').replace(/\r?\n/g, '<br>');
          textCells.push(plainVal);
          // HTML 直接用 innerHTML（完整结构，paste 时优先解析 HTML）
          htmlCells.push('<' + cell.tagName + '>' + cell.innerHTML + '</' + cell.tagName + '>');
        } else {
          textCells.push('');
          htmlCells.push('<TD><br></TD>');
        }
      }
      textLines.push(textCells.join('\t'));
      htmlRows.push('<tr>' + htmlCells.join('') + '</tr>');
    }
    const textPlain = textLines.join('\n');
    const textHtml = '<table><tbody>' + htmlRows.join('') + '</tbody></table>';

    e.clipboardData.setData('text/plain', textPlain);
    e.clipboardData.setData('text/html', textHtml);
  }, true);

  /* ============================================================
   * 宿主层 per-tab 独立 undo/redo 历史 + Ctrl+Shift+Z redo 支持（Bug-079 最终方案）
   * 背景：vditor 是全局单例（唯一 vdInst），原生 undo 栈挂在 vditor.undo.{ir,sv,wysiwyg}，
   * 且栈内的 diff_match_patch patch 与当时 DOM 状态紧耦合，**无法在切 tab 时 save/restore**
   * （patch 从 A DOM 拿到 B DOM 上应用结果完全错误）。
   * 方案：放弃 vditor 原生 undo/redo，改为宿主层维护 per-tab 的「整文档内容快照」历史栈：
   *   - vdTabHistory[path] = { undoStack: [content1, content2, ...], redoStack: [], lastPushTs: 0 }
   *   - vditor input 回调时 debounced push 到当前 tab 的 undoStack
   *   - 捕获阶段拦截 Ctrl+Z（undo）/ Ctrl+Shift+Z（redo）/ Ctrl+Y（redo）
   *     对命中者 preventDefault + stopImmediatePropagation 屏蔽 vditor 原生 keydown，
   *     然后从宿主栈取快照调 vdInst.setValue(snap, true)
   * 注意：粒度是「整文档快照」而非 vditor 原生的字符级 diff——这是为了正确性的合理取舍
   * （VS Code / Notion 等主流编辑器也都用文档级 undo）。
   * 作者: 火 冰
   * ============================================================ */
  /** @type {Object.<string, {undoStack:string[], redoStack:string[], lastPushTs:number}>} per-tab 历史栈 */
  let vdTabHistory = {};
  /** @type {string[]} 每个 tab 最近一次 push 后被 setValue 回填的快照（避免 undo 栈里重复存相同内容） */
  let vdLastPushContent = {};
  /** @type {number} push 去抖 timer id（当前 tab 共用一个，input 时 reset） */
  let vdPushDebounceTimer = null;
  /** @type {string|null} push 去抖期间关联的 tab path（timer 到点时校验还是不是同一个 tab） */
  let vdPushDebouncePath = null;
  /** @type {string|null} push 去抖期间预缓存的 md（input 回调传入，避免二次 getValue） */
  let vdPushDebounceMD = null;
  /** @type {string|null} 上一次 input 回调的 v（内容没变时跳过整条回调链） */
  let vdLastInputV = null;

  /** 确保 path 在 vdTabHistory 里有记录，懒初始化 undoStack/redoStack
   * @param {string} path tab path
   * @author 火 冰 */
  function vdEnsureHistory(path) {
    if (!path) return null;
    if (!vdTabHistory[path]) vdTabHistory[path] = { undoStack: [], redoStack: [], lastPushTs: 0 };
    return vdTabHistory[path];
  }

  /** 去抖 push 当前 vditor 内容到 tab 历史栈（500ms debounce）
   * 连续输入时 reset timer，停止 500ms 后再 push；切 tab 时 timer 失效（path 变了）。
   * 大文件优化：input 回调的 v 参数已经是 lute 算好的 md，直接传入可避免二次 DOM→MD 转换。
   * @param {string} path 当前 tab path
   * @param {string} [precomputedMd] 可选的预计算 md（如 input 回调参数），省去 getValue 开销
   * @author 火 冰 */
  function vdDebouncePush(path, precomputedMd) {
    if (!path) return;
    vdPushDebouncePath = path;
    if (precomputedMd != null) vdPushDebounceMD = precomputedMd;   // 缓存预计算的 md
    if (vdPushDebounceTimer) clearTimeout(vdPushDebounceTimer);
    vdPushDebounceTimer = setTimeout(function () {
      // 去抖到点时 path 已变（用户切 tab 了）→ 丢弃
      if (vdPushDebouncePath !== path) return;
      vdPushDebounceTimer = null;
      vdPushDebouncePath = null;
      // 优先用预缓存的 md（input 回调传入的），否则才 getValue
      const md = vdPushDebounceMD != null
        ? vdPushDebounceMD
        : ((vdInst && typeof vdInst.getValue === 'function') ? vdInst.getValue() : vdBuffer);
      vdPushDebounceMD = null;
      vdDoPush(path, md);
    }, 500);
  }

  /** 立即 push 一份快照（切 tab 保存 outgoing 时用，不走去抖）
   * @param {string} path tab path
   * @param {string} md 要 push 的内容
   * @author 火 冰 */
  function vdDoPush(path, md) {
    const h = vdEnsureHistory(path);
    if (!h) return;
    const content = String(md == null ? '' : md);
    // 和上次 push/回填的内容一样 → 不重复存
    if (vdLastPushContent[path] === content) return;
    h.undoStack.push(content);
    h.redoStack = []; // 新 push 清空 redo
    vdLastPushContent[path] = content;
    // 栈上限 100 条
    if (h.undoStack.length > 100) h.undoStack.shift();
  }

  /** ================================================================
   *  大文件性能降级：统一阈值 + requestIdleCallback 延迟重操作
   *  大文件定义：md 内容 > 50KB 或 DOM 节点 > 2000 个
   *  目的：避免 MutationObserver 全量扫描、getMarkdown 重操作阻塞主线程
   *  作者: 火 冰
   *  ================================================================ */
  /** @const {number} 大文件阈值：md 字符数超过此值进入降级模式 */
  const SB_LARGE_MD_THRESHOLD = 50 * 1024;
  /** @const {number} 大 DOM 阈值：元素节点数超过此值进入降级模式 */
  const SB_LARGE_DOM_THRESHOLD = 2000;

  /** 检测当前内容/规模是否为大文件（需性能降级）
   *  @returns {boolean} 是大文件
   *  @author 火 冰 */
  function sbIsLargeContent() {
    const md = vdGetValue();
    if (md && md.length > SB_LARGE_MD_THRESHOLD) return true;
    const root = document.getElementById('ed-vditor');
    if (root && typeof root.querySelectorAll === 'function') {
      // 用 getElementsByTagName('*').length 比 querySelectorAll 快
      if (root.getElementsByTagName('*').length > SB_LARGE_DOM_THRESHOLD) return true;
    }
    return false;
  }

  /** 在 requestIdleCallback（或 rAF 兜底）中执行重操作，大文件下避免阻塞输入响应
   *  @param {Function} fn 要执行的函数
   *  @param {number} [timeout=500] 最大等待毫秒数（即使不空闲也要执行，防饿死）
   *  @author 火 冰 */
  function sbRunWhenIdle(fn, timeout) {
    timeout = timeout || 500;
    if (typeof window.requestIdleCallback === 'function') {
      try { window.requestIdleCallback(fn, { timeout: timeout }); return; } catch (_) { /* 忽略 */ }
    }
    // 兜底：setTimeout + rAF（让浏览器先处理一帧输入）
    setTimeout(function () {
      if (typeof window.requestAnimationFrame === 'function') window.requestAnimationFrame(fn);
      else fn();
    }, 0);
  }

  /** 立即 push 并同步更新 lastPushContent（setValue 回填时防止 undo 栈重复）
   * @param {string} path tab path
   * @param {string} md 内容
   * @author 火 冰 */
  function vdMarkFilled(path, md) {
    vdLastPushContent[path] = String(md == null ? '' : md);
  }

  /** 去抖 push 未到点时主动 flush：清 timer + 立即 vdDoPush 当前内容。
   * 在 Ctrl+Z/Ctrl+Y 执行前调用，确保 in-flight 的编辑状态被捕获后再回退/前进。
   * 大文件优化：优先用预缓存的 md（input 回调传入），省去 getValue 开销。
   * @param {string} path 当前 tab path
   * @author 火 冰 */
  function vdFlushDebounce(path) {
    if (!vdPushDebounceTimer) return;
    // 只 flush 匹配的 path（timer 可能已过期指向其他 tab）
    if (vdPushDebouncePath !== path) { clearTimeout(vdPushDebounceTimer); vdPushDebounceTimer = null; vdPushDebouncePath = null; vdPushDebounceMD = null; return; }
    clearTimeout(vdPushDebounceTimer); vdPushDebounceTimer = null; vdPushDebouncePath = null;
    // 大文件优化：优先用预缓存的 md，只在 null 时才 getValue
    const md = vdPushDebounceMD != null
      ? vdPushDebounceMD
      : ((vdInst && typeof vdInst.getValue === 'function') ? vdInst.getValue() : vdBuffer);
    vdPushDebounceMD = null;
    vdDoPush(path, md);
  }

  /** 执行 undo：从 undoStack 弹出上一个快照，调 setValue 回填
   * Bug-079 修复：Ctrl+Z 时若有未到点的 debounce timer，先 flush 捕获当前编辑状态再回退，
   * 否则 500ms 去抖还没到点，undoStack 里只有起始态，Ctrl+Z 一按全部撤销。
   * @param {string} path 当前 tab path
   * @returns {boolean} 是否成功执行了 undo
   * @author 火 冰 */
  function vdDoUndo(path) {
    vdFlushDebounce(path);
    const h = vdEnsureHistory(path);
    if (!h || h.undoStack.length < 2) return false; // 至少要有初始态 + 一条编辑
    const cur = h.undoStack.pop();
    h.redoStack.push(cur);
    const prev = h.undoStack[h.undoStack.length - 1];
    vdMarkFilled(path, prev);
    try { if (vdInst) vdInst.setValue(prev, true); } catch (_) { /* 忽略 */ }
    window.sbOutlineNotify();
    return true;
  }

  /** 执行 redo：从 redoStack 弹出一条快照，调 setValue 回填
   * 同样先 flush pending debounce（虽然 redo 场景少，但保证一致）。
   * @param {string} path 当前 tab path
   * @returns {boolean} 是否成功执行了 redo
   * @author 火 冰 */
  function vdDoRedo(path) {
    vdFlushDebounce(path);
    const h = vdEnsureHistory(path);
    if (!h || h.redoStack.length === 0) return false;
    const next = h.redoStack.pop();
    h.undoStack.push(next);
    vdMarkFilled(path, next);
    try { if (vdInst) vdInst.setValue(next, true); } catch (_) { /* 忽略 */ }
    window.sbOutlineNotify();
    return true;
  }

  /** 外部清理接口：关闭页签时清理对应历史栈，防内存泄漏。
   * 由 editor-tabs.js 的 closeTabs 调用。
   * @param {string} path 关闭的 tab path
   * @author 火 冰 */
  window.vdClearUndoCache = function (path) {
    if (path in vdTabHistory) delete vdTabHistory[path];
    if (path in vdLastPushContent) delete vdLastPushContent[path];
  };

  /** @type {string[]} 工具栏精简项：承接原自研格式/表格/代码/数学能力，含原生搜索、大纲、导出；
   *  upload 为 vditor 内置上传按钮，支持图片与附件（accept/上传逻辑见 buildVditor 的 upload 配置） */
  const VDTOOLBAR = [
    'undo', 'redo', '|', 'headings', 'bold', 'italic', 'strike', '|',
    'list', 'ordered-list', 'check', 'outdent', 'indent', '|',
    'quote', 'line', 'code', 'inline-code', '|', 'table', 'link', 'upload', '|',
    /* 自定义查找/替换按钮（vditor 无内置，走 Custom 渲染，icon 为内联 SVG）。
     * click 引用的 vdOpenFindbar 是本 IIFE 内函数声明，随调用时已就绪。作者: 火 冰 */
    {
      name: 'sb-find', tip: '查找 (Ctrl+F)',
      icon: '<svg viewBox="0 0 24 24" width="17" height="17" style="fill:none;stroke:currentColor;stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m21 21-5-5"/></svg>',
      click: function () { vdOpenFindbar(false); },
    },
    {
      name: 'sb-replace', tip: '替换 (Ctrl+R)',
      icon: '<svg viewBox="0 0 24 24" width="17" height="17" style="fill:none;stroke:currentColor;stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round"><circle cx="9" cy="11.5" r="6"/><path d="m20.5 20.5-4.6-4.6"/><text x="0" y="24" font-size="13" font-weight="700" style="fill:currentColor;stroke:none">A</text></svg>',
      click: function () { vdOpenFindbar(true); },
    },
    '|',
    /* 代码块工具：行号 / 换行。全局持久化设置，切换后所有代码块立即重绘。
     * 工具栏按钮走 Custom 渲染，运行时根据当前全局设置高亮激活态（is-on）。
     * 作者: 火 冰 */
    {
      name: 'sb-code-ln', tip: '代码块显示行号',
      icon: '<svg viewBox="0 0 24 24" width="17" height="17" style="fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>',
      click: function () {
        const cur = !vdCodeLnOn();
        if (typeof saveS === 'function') saveS('codeLineNumbers', cur);
        vdCodeLnSchedule();
        vdToolbarRefreshStates();   // 更新按钮高亮
      },
    },
    {
      name: 'sb-code-wrap', tip: '代码块内容换行',
      icon: '<svg viewBox="0 0 24 24" width="17" height="17" style="fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round"><line x1="3" y1="6" x2="21" y2="6"/><path d="M3 12h15a3 3 0 1 1 0 6h-4"/><polyline points="16 16 14 18 16 20"/></svg>',
      click: function () {
        const cur = !vdCodeWrapOn();
        if (typeof saveS === 'function') saveS('codeWrap', cur);
        vdCodeLnSchedule();
        vdToolbarRefreshStates();   // 更新按钮高亮
      },
    },
    '|',
    /* 大纲 / 宽屏 / 表格列宽：三者均为 markdown-editor 插件能力，按钮由插件经
     * window.sbVdToolbarAdd 注入编辑工具栏（见插件 main.js），本数组不再声明。
     * 仅当桌面版未加载该插件时这些按钮不出现，功能不依赖宿主。作者: 火 冰 */
    'export',
  ];

  /* 宿主自接管全屏（vdToggleFullscreen）：全屏按钮由宿主用工具栏注入桥注册，
   * 与插件按钮同走 __sbVdToolbarInjects 队列并入工具栏；click 在运行时调用
   * window.vdToggleFullscreen（闭包后部已就绪）。作者: 火 冰 */
  if (typeof window.sbVdToolbarAdd === 'function') {
    window.sbVdToolbarAdd({
      name: 'sb-fullscreen', tip: '全屏 / 退出全屏（Esc）',
      icon: '<svg viewBox="0 0 24 24" width="17" height="17" style="fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round"><path d="M8 3H5a2 2 0 0 0-2 2v3"/><path d="M21 8V5a2 2 0 0 0-2-2h-3"/><path d="M3 16v3a2 2 0 0 0 2 2h3"/><path d="M16 21h3a2 2 0 0 0 2-2v-3"/></svg>',
      click: function () { if (typeof window.vdToggleFullscreen === 'function') window.vdToggleFullscreen(); },
    });
  }

  /* ---------- 资源上传（图片/附件）助手 ---------- */

  /** 是否图片类文件名（决定插入为 `![名](url)` 还是 `[名](url)`）
   * @param {string} name 原始文件名
   * @returns {boolean} 是否为图片
   * @author 火 冰 */
  function isImageName(name) {
    return /\.(png|jpe?g|gif|webp|bmp|svg|ico)$/i.test(String(name || ''));
  }

  /** 生成资源插入 markdown：图片 → `![真实名](url)`，附件 → `[真实名](url)`（笔记内使用真实名）。
   *  暴露到 window 供 jsdom 回归断言调用。
   * @param {string} name 原始真实文件名
   * @param {string} url  note://vault_res/... 资源地址
   * @returns {string} 待插入片段
   * @author 火 冰 */
  function sbResMarkdown(name, url) {
    return isImageName(name) ? '![' + name + '](' + url + ')' : '[' + name + '](' + url + ')';
  }
  window.sbResMarkdown = sbResMarkdown;

  /** 生成附件卡片插入 markdown（Obsidian 风格引言，供 `[!attach]` 语法渲染成卡片）：
   *  `> [!attach] 真实名 note://vault_res/uuid.ext`，使上传的附件在编辑区显示为「醒目指示块」、
   *  预览/阅读渲染为「完整附件卡片」。图片不经过此函数（保持 `![真实名](url)` 行内预览）。
   *  暴露到 window 供 jsdom 回归断言调用。
   * @param {string} name 原始真实文件名
   * @param {string} url  note://vault_res/... 资源地址
   * @returns {string} 待插入的附件卡片引言片段
   * @author 火 冰 */
  function sbAttachMarkdown(name, url) {
    return '> [!attach] ' + name + ' ' + url;
  }
  window.sbAttachMarkdown = sbAttachMarkdown;

  /** 从 note://vault_res/ 地址抽取资源存储名（uuid.ext）；非该协议地址返回空串。
   *  暴露到 window 供 jsdom 回归断言调用。
   * @param {string} url 资源地址
   * @returns {string} 存储名，或空串
   * @author 火 冰 */
  function resolveVaultResUrl(url) {
    if (typeof url !== 'string') return '';
    const m = String(url).match(/^note:\/\/vault_res\/([^?#]+)/);
    return m ? String(m[1]).replace(/^\/+/, '') : '';
  }
  window.resolveVaultResUrl = resolveVaultResUrl;

  /** 上传一批文件到知识库资源目录：每个文件读二进制 → IPC 落盘（UUID 重命名）→ 回填真实名链接。
   *  作为 vditor options.upload.handler；仅桌面版有桥接时生效，网页版提示不支持。
   *  上传成功后将所有片段按序一次性插入光标处。
   * @param {File[]} fileList 待上传文件数组（vditor 已按 accept/mutiple/max 过滤）
   * @returns {Promise<string|void>} 返回错误文案则 vditor 提示，否则静默
   * @author 火 冰 */
  async function handleVdUpload(fileList) {
    if (!fileList || !fileList.length) return;
    const bridge = window.noteDesktop;
    if (!bridge || typeof bridge.uploadResource !== 'function') {
      try { if (vdInst && vdInst.tip) vdInst.tip.show('上传仅桌面版支持'); } catch (_) { /* 忽略提示异常 */ }
      return;
    }
    const snippets = [];
    for (let i = 0; i < fileList.length; i++) {
      const f = fileList[i];
      if (!f) continue;
      try {
        const buf = await f.arrayBuffer();                    // 读取原始二进制
        const res = await bridge.uploadResource(f.name, buf); // 桌面端落盘 .resources，UUID 命名
        if (res && res.url) {
          // 图片保持行内预览；附件插入 `> [!attach] 名 url` 引言，供编辑区指示块/预览卡片渲染
          snippets.push(isImageName(f.name)
            ? sbResMarkdown(res.name || f.name, res.url)
            : sbAttachMarkdown(res.name || f.name, res.url));
        }
      } catch (e) { console.error('[vditor] 上传失败:', f.name, e); }
    }
    if (snippets.length && vdInst) {
      try { vdInst.insertValue(snippets.join('\n')); } catch (_) { /* 插入失败忽略 */ }
    }
  }

  /** HTML 转义（卡片/上下文菜单文本防注入）
   * @param {string} s 原始文本
   * @returns {string} 转义后文本
   * @author 火 冰 */
  function escapeHtml(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  /** HTML 属性转义（与 escapeHtml 一致，供属性值使用）
   * @param {string} s 原始文本
   * @returns {string} 转义后文本
   * @author 火 冰 */
  function escapeAttr(s) {
    return escapeHtml(s);
  }

  /** 附件卡片 HTML（预览/阅读视图）：扩展名徽标 + 真实名 + 下载按钮。
   *  卡片携带 data-sb-res-url / data-sb-res-name，供点击打开、右键下载、复制链接复用。
   *  暴露到 window 供 jsdom 回归断言调用。
   * @param {string} name 原始真实文件名
   * @param {string} url  note://vault_res/... 资源地址
   * @returns {string} 卡片 HTML
   * @author 火 冰 */
  function sbAttachCardHTML(name, url) {
    const m = String(url).match(/\.([0-9a-z]+)(?:$|[?#])/i);
    const label = (m ? m[1] : 'file').toUpperCase().slice(0, 8);
    const safeName = escapeAttr(name || '下载');
    return '<div class="sb-res-card" data-sb-res-url="' + escapeAttr(url) + '" data-sb-res-name="' + safeName + '">'
      + '<span class="sb-res-card-ext">' + escapeHtml(label) + '</span>'
      + '<div class="sb-res-card-main">'
      + '<span class="sb-res-card-name">' + escapeHtml(name || url) + '</span>'
      + '<span class="sb-res-card-url">' + escapeHtml(url) + '</span>'
      + '</div>'
      + '<button type="button" class="sb-res-card-dl" title="下载 ' + safeName + '"></button>'
      + '</div>';
  }
  window.sbAttachCardHTML = sbAttachCardHTML;

  /** 预览/阅读 HTML 变换：把 Obsidian 风格附件引言 `> [!attach] 真实名 note://vault_res/uuid.ext`
   *  渲染成附件卡片（下载/右键菜单），其余内容原样返回。
   *  作为 vditor options.preview.transform；仅识别 note://vault_res 附件，防止误改普通引言。
   *  暴露到 window 供 jsdom 回归断言调用。
   * @param {string} html md2html 输出的 HTML
   * @returns {string} 变换后的 HTML
   * @author 火 冰 */
  function transformPreviewHtml(html) {
    if (!html || String(html).indexOf('[!attach]') === -1) return html;
    const tpl = document.createElement('div');
    tpl.innerHTML = html;
    const qs = Array.prototype.slice.call(tpl.querySelectorAll('blockquote, [data-type="blockquote"]'));
    for (let i = 0; i < qs.length; i++) {
      if (!isAttachCallout(qs[i])) continue;
      let text = String(qs[i].textContent || '').trim();
      if (text.indexOf('[!attach]') !== 0) continue;
      const body = text.slice('[!attach]'.length).trim();
      if (!body) continue;
      const sp = body.lastIndexOf(' ');                 // 最后一段空白切出 url，前面为真实名（允许名含空格）
      const url = body.slice(sp + 1).trim();
      const name = (sp > 0 ? body.slice(0, sp) : url).trim() || url;
      if (!/^note:\/\/vault_res\/[^?#]+$/.test(url)) continue;
      const wrap = document.createElement('div');
      wrap.innerHTML = sbAttachCardHTML(name, url);
      const node = wrap.firstChild;
      if (node) qs[i].parentNode.replaceChild(node, qs[i]);
    }
    return tpl.innerHTML;
  }
  window.sbTransformPreviewHtml = transformPreviewHtml;

  /** 通过 note:// 资源地址下载到本地（fetch→blob→临时链接触发浏览器下载，以真实名保存）。
   *  暴露到 window 供回归断言/复用。
   * @param {string} url  note://vault_res/... 资源地址
   * @param {string} name 保存文件名（真实名）
   * @author 火 冰 */
  async function downloadResource(url, name) {
    try {
      const resp = await fetch(url);
      if (!resp.ok) throw new Error('HTTP ' + resp.status);
      const blob = await resp.blob();
      const objUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = objUrl;
      a.download = name || 'download';
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(function () { try { URL.revokeObjectURL(objUrl); } catch (_) { /* 忽略 */ } }, 10000);
    } catch (e) { console.error('[res] 下载失败:', url, e); }
  }
  window.sbDownloadResource = downloadResource;

  /* ---------- 编辑器/卡片右键菜单 ---------- */

  let sbMenuEl = null;     // 当前展示的右键菜单元素

  /** 关闭右键菜单 */
  function hideSbMenu() { if (sbMenuEl) { sbMenuEl.remove(); sbMenuEl = null; } }
  window.sbHideMenu = hideSbMenu;

  /** 在指定坐标展示一个右键菜单（body 级固定浮层，可防溢出）。
   * @param {Array<{label:string,onClick:Function}>} items 菜单项
   * @param {number} x 视口横坐标
   * @param {number} y 视口纵坐标
   * @author 火 冰 */
  function showSbMenu(items, x, y) {
    hideSbMenu();
    const el = document.createElement('div');
    el.className = 'sb-ctx';
    el.setAttribute('role', 'menu');
    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'sb-ctx-item';
      b.textContent = it.label;
      b.setAttribute('role', 'menuitem');
      (function (onClick) {
        b.addEventListener('click', function (ev) {
          ev.stopPropagation();
          hideSbMenu();
          if (typeof onClick === 'function') { try { onClick(); } catch (_) { /* 忽略菜单回调异常 */ } }
        });
      })(it.onClick);
      el.appendChild(b);
    }
    document.body.appendChild(el);
    const rect = el.getBoundingClientRect();
    let px = x; let py = y;
    if (px + rect.width > window.innerWidth - 8) px = Math.max(8, window.innerWidth - rect.width - 8);
    if (py + rect.height > window.innerHeight - 8) py = Math.max(8, window.innerHeight - rect.height - 8);
    el.style.left = px + 'px';
    el.style.top = py + 'px';
    sbMenuEl = el;
    setTimeout(function () {
      const onDoc = function (ev) { if (!el.contains(ev.target)) hideSbMenu(); document.removeEventListener('mousedown', onDoc, true); };
      document.addEventListener('mousedown', onDoc, true);
    }, 0);
    const onKey = function (ev) { if (ev.key === 'Escape') { hideSbMenu(); document.removeEventListener('keydown', onKey, true); } };
    document.addEventListener('keydown', onKey, true);
  }

  /** 把光标放到指定视口坐标处（右键时把插入点定位到鼠标位置）。
   * @param {number} x 视口横坐标
   * @param {number} y 视口纵坐标
   * @author 火 冰 */
  function placeCaretAtPoint(x, y) {
    try {
      const r = document.caretRangeFromPoint(x, y);
      if (!r) return;
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(r);
      if (vdInst && vdInst.vditor) {
        const v = vdInst.vditor;
        const el = (vdMode === 'sv' && v.sv) ? v.sv.element
          : ((vdMode === 'wysiwyg' && v.wysiwyg) ? v.wysiwyg.element : (v.ir ? v.ir.element : null));
        if (el) el.focus();
      }
    } catch (_) { /* 忽略光标定位异常 */ }
  }

  let sbPickInput = null;   // 惰性创建的隐藏文件选择框（右键「插入图片/上传附件」复用）

  /* 文件选择 accept 由 markdown-editor 插件的 md-context.js 提供（window.sbUploadAccept，
   * 图片 `image/*`、附件非图片扩展名白名单）；此处仅取用并保证无插件时安全回落。 */
  function sbUploadAccept(type) {
    return (typeof window.sbUploadAccept === 'function')
      ? window.sbUploadAccept(type)
      : (type === 'image' ? 'image/*' : '.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.html,.htm,.md,.txt,.sh,.bat,.cmd,.ps1,.csv,.zip,.rar,.7z,.asc');
  }

  /** 弹出文件选择，选中文件经 handleVdUpload 在光标处上传并插入（复用上传/落盘与分流逻辑）。
   *  handleVdUpload 按 isImageName 判断：图片插行内 `![名](url)`、附件插 `> [!attach]` 卡片引言；
   *  故此处仅需按 type 过滤 accept，分流由 handleVdUpload 完成。
   * @param {string} type 'image' 只选图片 | 'attachment' 只选非图片附件
   * @author 火 冰 */
  function pickAndUploadAtCaret(type) {
    if (!window.noteDesktop || typeof window.noteDesktop.uploadResource !== 'function') {
      try { if (vdInst && vdInst.tip) vdInst.tip.show('上传仅桌面版支持'); } catch (_) { /* 忽略提示异常 */ }
      return;
    }
    if (!sbPickInput) {
      sbPickInput = document.createElement('input');
      sbPickInput.type = 'file';
      sbPickInput.style.display = 'none';
      sbPickInput.multiple = true;
      document.body.appendChild(sbPickInput);
      sbPickInput.addEventListener('change', async function () {
        const files = sbPickInput.files ? Array.prototype.slice.call(sbPickInput.files) : [];
        sbPickInput.value = '';
        if (files.length && vdInst) await handleVdUpload(files);
      });
    }
    sbPickInput.accept = sbUploadAccept(type);
    sbPickInput.click();
  }

  /** 编辑器/卡片右键处理：卡片 → 下载/复制链接；编辑区 → 插入图片/上传附件菜单。
   *  （卡片只在预览/阅读出现，卡片右键用下载菜单；IR 表格/代码块右键由专属菜单接管，此处不叠加）
   *  @param {MouseEvent} e 右键事件
   *  @author 火 冰 */
  function onEditorContextMenu(e) {
    const card = e.target && e.target.closest ? e.target.closest('.sb-res-card') : null;
    if (card) {
      const url = card.getAttribute('data-sb-res-url') || '';
      const name = card.getAttribute('data-sb-res-name') || '下载';
      if (url) {
        e.preventDefault();
        e.stopPropagation();
        showSbMenu([
          { label: '下载', onClick: function () { downloadResource(url, name); } },
          { label: '复制链接', onClick: function () { try { navigator.clipboard.writeText(url); } catch (_) { /* 忽略复制异常 */ } } },
        ], e.clientX, e.clientY);
      }
      return;
    }
    // 命中判断用 vditor 内容容器 vdInst.vditor.element（编辑区/预览所在），
    // 不能用 vdInst.element——Vditor 实例从不挂该字段，恒为 undefined，会导致右键菜单永不触发。
    const vdRoot = (vdInst && vdInst.vditor) ? vdInst.vditor.element : (vdEl() || null);
    if (vdInst && e.target && vdRoot && vdRoot.contains(e.target)) {
      // IR 表格/代码块右键交给 showIrTableMenu/showIrCodeMenu 专属菜单，避免两组菜单叠加。
      // 注意不能用 closest('pre')：vditor IR 整个编辑区被一个 <pre class="vditor-reset"> 包裹，
      // 普通文字也会命中 pre，导致通用右键被误短路（Bug-049，见 irCodeAtRightClick）。
      if (vdMode === 'ir') {
        const tg = e.target;
        const el = tg.nodeType === 1 ? tg : (tg.parentElement || null);
        if (el && typeof el.closest === 'function'
          && (el.closest('table') || el.closest('[data-type="code-block"]'))) return;
      }
      e.preventDefault();
      placeCaretAtPoint(e.clientX, e.clientY);
      showSbMenu([
        { label: '插入图片', onClick: function () { pickAndUploadAtCaret('image'); } },
        { label: '上传附件', onClick: function () { pickAndUploadAtCaret('attachment'); } },
      ], e.clientX, e.clientY);
    }
  }
  document.addEventListener('contextmenu', onEditorContextMenu);

  /* ---------- 编辑区附件引言指示块（Obsidian `> [!attach]` 语法） ---------- */

  /** 判断一个块是否为 `> [!attach]` 附件引言：正文取首个 <p> 文本，无 <p> 则用块自身文本，
   *  以行首 `[!attach]` 判定（覆盖 IR/WYSIWYG 原生 blockquote 与 SV 源码 data-type 结构）。
   * @param {HTMLElement} node 块节点
   * @returns {boolean} 是否为附件引言
   * @author 火 冰 */
  function isAttachCallout(node) {
    if (!node) return false;
    let t = '';
    const p = node.querySelector('p');
    t = p ? p.textContent : '';
    if (!t.trim()) t = node.textContent;
    return /^\s*\[!attach\]/.test(t || '');
  }

  /** 标记编辑区中 `> [!attach] ...` 行为的引言块为 `sb-attach-callout`，
   *  仅切换 class（不改 DOM/不动 markdown），供 CSS 显示成醒目附件指示块。
   *  @param {HTMLElement} root 编辑区根
   *  @author 火 冰 */
  function markAttachCallouts(root) {
    if (!root) return;
    const qs = root.querySelectorAll('blockquote, [data-type="blockquote"]');
    for (let i = 0; i < qs.length; i++) {
      qs[i].classList.toggle('sb-attach-callout', isAttachCallout(qs[i]));
    }
  }
  window.sbMarkAttachCallouts = markAttachCallouts;

  let sbCalloutTimer = null;
  /** 防抖标记：编辑内容变后，扫描 IR/WYSIWYG 编辑区给 blockquote 加指示类。
   *  大文件优化：md > 50KB 时改走 requestIdleCallback，避免 120ms timer 阻塞输入响应。
   *  @author 火 冰 */
  function scheduleCalloutMark() {
    if (sbCalloutTimer) return;
    sbCalloutTimer = setTimeout(function () {
      sbCalloutTimer = null;
      if (!vdInst || !vdInst.vditor) return;
      const v = vdInst.vditor;
      const doMark = function () {
        const _t0 = performance.now();
        if (v.ir) markAttachCallouts(v.ir.element);
        if (v.wysiwyg) markAttachCallouts(v.wysiwyg.element);
        if (performance.now() - _t0 > 5 && window.__sbDebugPerf) {
          console.warn('[PERF][calloutMark] large=' + sbIsLargeContent().toString() +
            ' took=' + (performance.now() - _t0).toFixed(1) + 'ms');
        }
      };
      // 大文件 → 空闲时执行；小文件 → 立即（120ms 去抖已保证不会太频繁）
      if (sbIsLargeContent()) sbRunWhenIdle(doMark, 1000);
      else doMark();
    }, 120);
  }

  /** @type {MutationObserver|null} 附件引言块观察器（可重挂目标：启动时 documentElement，vditor 就绪后缩到编辑区） */
  let sbCalloutObs = null;

  /** 挂载/重挂载 MutationObserver 监听结构变化，防抖触发指示块标记。
   *  作用域优先级：vditor 编辑区根 > body > documentElement（保证脚本加载早期也能工作）。
   *  vditor 构建完成后调用此函数把观察范围从 documentElement 缩到编辑区根，
   *  排除工具栏 tooltip、设置面板等无关 DOM 变化。
   *  @author 火 冰 */
  function watchAttachCallouts() {
    // 优先挂 vditor 编辑区根（已就绪时），否则回退 documentElement
    let target = null;
    if (vdInst && vdInst.vditor && vdInst.vditor.element) target = vdInst.vditor.element;
    if (!target) target = document.getElementById('ed-vditor');
    if (!target) target = document.body || document.documentElement;
    if (!target || typeof MutationObserver !== 'function') return;

    // disconnect 旧 observer（若存在）
    if (sbCalloutObs) { try { sbCalloutObs.disconnect(); } catch (_) { /* 忽略 */ } sbCalloutObs = null; }

    try {
      sbCalloutObs = new MutationObserver(function (mutations) {
        // 快速路径：如果 mutation 的 target 不在编辑区或其子树内，直接跳过
        // （启动早期 documentElement 挂的 observer 会捕获整个页面变化，这里过滤）
        if (mutations && vdInst && vdInst.vditor && vdInst.vditor.element) {
          const vdRoot = vdInst.vditor.element;
          for (let i = 0; i < mutations.length; i++) {
            const m = mutations[i];
            if (m.target === vdRoot || (m.target.nodeType === 1 && vdRoot.contains(m.target))) {
              scheduleCalloutMark();
              return;   // 有任何一个 mutation 在编辑区内就触发，去抖保证最终只扫一次
            }
          }
          // 所有 mutation 都不在编辑区内 → 跳过
          return;
        }
        scheduleCalloutMark();
      });
      sbCalloutObs.observe(target, { childList: true, subtree: true });
    } catch (_) { /* 忽略观察异常 */ }
  }

  // 启动即监听（早期挂 documentElement，后续 vditor 构建完成后重挂到编辑区根）
  watchAttachCallouts();

  // 冒泡阶段拦截：卡片下载按钮 → 下载；点卡片主体 → 系统默认程序打开（不导航窗口）
  document.addEventListener('click', function (e) {
    const dl = e.target && e.target.closest ? e.target.closest('.sb-res-card-dl') : null;
    if (dl) {
      const card = dl.closest('.sb-res-card');
      const url = card && card.getAttribute('data-sb-res-url');
      const name = card && card.getAttribute('data-sb-res-name');
      if (url) { e.preventDefault(); e.stopPropagation(); downloadResource(url, name || 'download'); }
      return;
    }
    const card = e.target && e.target.closest ? e.target.closest('.sb-res-card') : null;
    if (card && e.target === card) {
      const url = card.getAttribute('data-sb-res-url');
      const stored = resolveVaultResUrl(url);
      e.preventDefault();
      e.stopPropagation();
      if (stored && window.noteDesktop && typeof window.noteDesktop.openResource === 'function') {
        try { window.noteDesktop.openResource(stored); } catch (_) { /* 忽略打开异常 */ }
      }
    }
  }, false);

  // 资源上传助手全量原样导出到 window，供 jsdom 回归断言调用
  window.__vdRes = {
    isImageName: isImageName,
    sbResMarkdown: sbResMarkdown,
    sbAttachMarkdown: sbAttachMarkdown,
    resolveVaultResUrl: resolveVaultResUrl,
    sbAttachCardHTML: sbAttachCardHTML,
    transformPreviewHtml: transformPreviewHtml,
    markAttachCallouts: markAttachCallouts,
  };

  // 捕获阶段拦截：点击上传附件（note://vault_res 链接）不再导致窗口整体导航，
  // 改用系统默认程序打开；图片链接（vditor 自身的点击预览）放行不拦截。
  document.addEventListener('click', function (e) {
    const src = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!src) return;
    const stored = resolveVaultResUrl(src.getAttribute('href'));
    if (!stored || isImageName(stored)) return;
    e.preventDefault();
    e.stopPropagation();
    const bridge = window.noteDesktop;
    if (bridge && typeof bridge.openResource === 'function') {
      try { bridge.openResource(stored); } catch (_) { /* 打开异常忽略 */ }
    }
  }, true);

  /** 应用当前是否为暗色主题（用于 vditor theme 选项跟随宿主）。
   *  读取全局已解析的 `html[data-theme]`（设置-外观-主题模式 dark/light/auto 的最终结果），
   *  auto 时由 app-core setTheme 已解析为 dark/light
   * author 火 冰 */
  function isDarkTheme() {
    return document.documentElement && document.documentElement.getAttribute('data-theme') === 'dark';
  }

  /** 收集插件注册的「编辑器主题解析器」，归并出 vditor 应应用的 { theme, extraCss }。
   *  解析器由插件经 PluginAPI.registerEditorThemeResolver 注册；取首个合法结果。
   *  无解析器时编辑器按宿主明暗应用 vditor 自带深/浅主题（配色只做外壳，不向编辑器数值映射）。
   *  作者: 火 冰 */
  function resolveVdTheme() {
    const hint = { dark: isDarkTheme() };
    const resolvers = window.__hostThemeResolvers || [];
    for (let i = 0; i < resolvers.length; i++) {
      if (typeof resolvers[i] !== 'function') continue;
      let r = null;
      try { r = resolvers[i](hint); } catch (_) { r = null; }
      if (r && (r.theme === 'dark' || r.theme === 'light')) {
        return { theme: r.theme, extraCss: typeof r.extraCss === 'string' ? r.extraCss : '' };
      }
    }
    return { theme: hint.dark ? 'dark' : 'light', extraCss: '' };
  }
  window.vdResolveVdTheme = resolveVdTheme;

  /** 注入/刷新编辑器额外主题 CSS（插件生成的自定义覆盖样式，持久 <style>，复用同一元素避免堆积）
   *  @param {string} css 可选，为空则清空既有注入
   *  作者: 火 冰 */
  function applyVdExtraCss(css) {
    const id = 'host-vditor-theme-extra';
    let style = document.getElementById(id);
    if (css) {
      if (!style) { style = document.createElement('style'); style.id = id; }
      style.textContent = css;
      // 每次应用都重新 appendChild 到 <head> 末尾（已存在时会移动节点），
      // 确保晚于 vditor 运行时动态注入的主题 <link>，让覆盖样式在级联中胜出。
      document.head.appendChild(style);
    } else if (style) {
      style.textContent = '';
    }
  }

  /** 将 vditor 主题应用到编辑区：先解析（插件可插拔源），再 setTheme + 注入额外 CSS。
   *  已构建实例即时 setTheme；未构建则仅缓存额外 CSS，由 buildVditor 用 resolveVdTheme() 兜底。
   *  作者: 火 冰 */
  function syncVdTheme() {
    const r = resolveVdTheme();
    if (vdInst) {
      try { vdInst.setTheme(r.theme); } catch (_) { /* 忽略同步异常 */ }
    }
    applyVdExtraCss(r.extraCss);
  }
  window.vdSyncTheme = syncVdTheme;

  /** 确定性接管 vditor 三个编辑视图 + 预览窗的显隐（不依赖 vditor 自身的 setPreviewMode，
   *  后者强制把 sv 源码 textarea 置为 display:block，会污染 IR/WYSIWYG 编辑态导致源码区残留挤压）。
   *  依据 vditor 内部元素结构：sv=textarea，ir/wysiwyg 用其外层容器，preview 用预览窗。
   *  - vdMode='sv'（SV 基础）：按 vdPreview 决定 both/editor/preview 三种布局
   *  - vdMode='ir'|'wysiwyg'（编辑节点）：仅显示对应编辑区，源码与预览一律隐藏
   * 作者: 火 冰 */
  function applyVdVisibility() {
    if (!vdInst || !vdInst.vditor) return;
    const v = vdInst.vditor;
    if (!v.sv || !v.ir || !v.wysiwyg || !v.preview) return;
    const sv = v.sv.element;
    const prev = v.preview.element;
    const ir = v.ir.element.parentElement;
    const wy = v.wysiwyg.element.parentElement;
    if (vdMode === 'sv') {
      sv.style.display = (vdPreview === 'preview') ? 'none' : 'block';
      prev.style.display = (vdPreview === 'both' || vdPreview === 'preview') ? 'block' : 'none';
      ir.style.display = 'none';
      wy.style.display = 'none';
      // 展示预览窗时确保其已渲染当前内容（vditor 构建时不一定触发）
      if (prev.style.display === 'block') { try { v.preview.render(v); } catch (_) { /* 忽略渲染异常 */ } }
    } else {
      sv.style.display = 'none';
      prev.style.display = 'none';
      ir.style.display = (vdMode === 'ir') ? 'block' : 'none';
      wy.style.display = (vdMode === 'wysiwyg') ? 'block' : 'none';
    }
    // sv 分屏源码行号随视图显隐刷新（非 sv 时自动清理）
    vdSvGutterRefresh();
    // 代码块行号随布局切换重扫（IR/WYSIWYG/sv 三布局的唯一收口，隐藏 pane 由 offsetParent 判定跳过）
    vdCodeLnSchedule();
  }

  /** 取视觉锚点元素（vditor 挂载容器） */
  function vdEl() {
    return document.getElementById('ed-vditor');
  }

  /** 安全取当前实例内容：实例未就绪（异步首帧渲染未完成）或 getValue 内部抛错时返回 undefined，
   *  由调用方回退暂存缓冲 vdBuffer。修复 fixValue 崩溃见 Bug 登记，作者: 火 冰 */
  function safeGetValue() {
    if (!vdInst) return undefined;
    try { return vdInst.getValue(); } catch (_) { return undefined; /* 忽略未就绪异常 */ }
  }

  /** 取当前实例内容：有实例用 getValue，否则用暂存缓冲 */
  function vdGetValue() {
    const v = vdInst ? safeGetValue() : vdBuffer;
    return (v === undefined) ? vdBuffer : v;
  }

  /** 内容变更回传给宿主：vditor input/blur 回调统一入口
   * @param {string} v 最新 markdown 源文本 */
  function sync2Host(v) {
    if (typeof onEdInput === 'function') {
      try { onEdInput(v); } catch (_) { /* 回调异常忽略 */ }
    }
  }

  /* ============================================================
   * IR 模式表格右键菜单（IR 表格操作）
   * vditor 原生「表格浮层工具栏」只在 wysiwyg.popover（仅所见即所得出现）。
   * 本模块给 ir 模式补一个等价入口：在表格单元格内**右键**弹出「插入行/列、删除行/列」菜单。
   * 关键同步思路：IR 模式下 vditor 的 getValue/getMarkdown 恒按当前
   * ir.element.innerHTML 实时推导（见 vditor getMarkdown: ir→VditorIRDOM2Md(innerHTML)），
   * 因此直接在 ir.element 的真实 <table> DOM 上增删行/列后，调用 vdInst.getValue()
   * 即得正确 markdown 并 sync2Host 保存，无需触发 vditor 内部重渲染，光标不跳转。
   * 作者: 火 冰
   * ============================================================ */

  /** @type {{table:HTMLElement,tr:HTMLElement,td:HTMLElement}|null} IR 表格右键命中的单元格 */
  let irCtxHit = null;
  /** @type {HTMLElement|null} IR 代码块右键命中的块级包装元素（.vditor-ir__node 等） */
  let irCtxCode = null;

  /** 在目标块级元素前插入一个空段落（修复「表格/代码块作为首元素时无法在其前插入内容」）。
   *  真实算法（DOM 插入 + 光标定位）已迁入 markdown-editor 插件的 md-context.js（window.irInsertAbove），
   *  本宿主仅注入 vdInst 实例并负责 getValue 同步回宿主。
   * @param {HTMLElement} blockEl 命中块内的任意元素（表格/代码块）
   * 作者: 火 冰 */
  function irInsertAbove(blockEl) {
    if (!vdInst || !blockEl) return;
    if (typeof window.irInsertAbove === 'function') window.irInsertAbove(vdInst, blockEl);
    try { sync2Host(vdInst.getValue()); } catch (_) { /* 忽略同步异常 */ }
  }

  /** 判断一个块级元素是否为「空行」（段落 p 且去掉 ZWSP 后无可见文本、无嵌套块）。
   *  空行即 irInsertAbove 插入的 `<p data-block="0">ZWSP<wbr></p>`，Backspace/Delete 上应删除整行。
   * @param {HTMLElement|null} el 待判元素
   * @returns {boolean} 是否为空行
   * 作者: 火 冰 */
  function isEmptyLine(el) {
    if (!el || el.nodeType !== 1 || el.tagName !== 'P') return false;
    if (el.querySelector('[data-block="0"]')) return false; // 含嵌套块不是空行
    return (el.textContent || '').replace(/\u200b/g, '').trim() === '';
  }

  /** 取光标位置所在的最顶层块根（带 `data-block="0"`），无则返回原元素兜底。
   * @param {Node} node 光标起点（文本节点或元素）
   * @returns {HTMLElement|null} 块根
   * 作者: 火 冰 */
  function blockRootOf(node) {
    if (!node) return null;
    let n = node;
    while (n && n.nodeType === 1) {
      if (n.getAttribute('data-block') === '0') return n;
      n = n.parentNode;
    }
    return null;
  }

  /** 判断光标是否位于块的最前面（块首可见文本之前，忽略 ZWSP）。
   * @param {HTMLElement} root 块根
   * @param {Range} range 当前选区
   * @returns {boolean} 光标是否在块最前
   * 作者: 火 冰 */
  function caretAtBlockStart(root, range) {
    try {
      const r2 = document.createRange();
      r2.setStartBefore(root.firstChild || root);
      r2.setEnd(range.startContainer, range.startOffset);
      return r2.toString().replace(/\u200b/g, '').trim() === '';
    } catch (_) { return false; }
  }

  /** 把选区光标放置到某块内（末尾或开头），并聚焦编辑区。
   * @param {HTMLElement} block 目标块
   * @param {boolean} atEnd true=末尾 | false=开头
   * 作者: 火 冰 */
  function placeCaret(block, atEnd) {
    if (!block || block.nodeType !== 1 || !vdInst || !vdInst.vditor.ir) return;
    try {
      const r = document.createRange();
      r.selectNodeContents(block);
      r.collapse(atEnd);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(r);
      vdInst.vditor.ir.element.focus();
    } catch (_) { /* 忽略光标异常 */ }
  }

  /** 删除一个空行块，并把光标定位到相邻块（Backspace→上一块末尾，Delete→下一块开头）；
   *  若未占位到相邻块则聚焦编辑区让用户自行点击；保证删除后编辑器至少留一个块。
   * @param {HTMLElement} root  空行块根
   * @param {string} key  触发的按键（'Backspace' | 'Delete'）
   * 作者: 火 冰 */
  function removeEmptyLine(root, key) {
    if (!vdInst || !root) return;
    const v = vdInst.vditor;
    const prev = root.previousElementSibling;
    const next = root.nextElementSibling;
    root.remove();
    // 防止编辑器被完全清空（vditor 需要一个占位块）
    if (!v.ir.element.firstChild) {
      v.ir.element.insertAdjacentHTML('afterbegin', '<p data-block="0">\u200b<wbr></p>');
    }
    const target = (key === 'Backspace') ? prev : next;
    if (target && target.nodeType === 1) placeCaret(target, key !== 'Backspace');
    else if (v.ir.element) { try { v.ir.element.focus(); } catch (_) { /* 忽略 */ } }
    try { sync2Host(v.getValue()); } catch (_) { /* 忽略同步异常 */ }
  }

  /** 捕获阶段 Backspace/Delete 处理器：修正 IR 模式空行与块前跳转。
   *  规则一：光标在空行上，Backspace/Delete 都删除该空行。
   *  规则二：光标在块（表格/代码块等）最前面按 Backspace，若上一行是空行则删除空行；
   *          若非空行则放行给 vditor 原生（其会跳到上一元素末尾）。
   *  以捕获阶段拦截并在命中时 preventDefault，避免与 vditor 原生 keydown 冲突。
   * @param {KeyboardEvent} e 键盘事件
   * 作者: 火 冰 */
  function handleIrDeleteKeydown(e) {
    const key = e.key;
    if (key !== 'Backspace' && key !== 'Delete') return;
    if (!vdInst || vdMode !== 'ir') return;
    const v = vdInst.vditor;
    const el = v && v.ir ? v.ir.element : null;
    if (!el || !el.contains(e.target)) return;
    const sel = window.getSelection();
    if (!sel || sel.rangeCount !== 1) return;
    const range = sel.getRangeAt(0);
    if (!range.collapsed) return; // 有选区交给 vditor 原生处理删除
    const root = blockRootOf(range.startContainer);
    if (!root) return;
    // 规则一：空行删除
    if (isEmptyLine(root)) {
      e.preventDefault();
      e.stopImmediatePropagation();
      removeEmptyLine(root, key);
      return;
    }
    // 规则二：块最前 Backspace，上一行是空行则删除之
    if (key === 'Backspace' && caretAtBlockStart(root, range)) {
      const prev = root.previousElementSibling;
      if (prev && isEmptyLine(prev)) {
        e.preventDefault();
        e.stopImmediatePropagation();
        prev.remove();
        if (v.ir && v.ir.element) { try { v.ir.element.focus(); } catch (_) { /* 忽略 */ } }
        try { sync2Host(v.getValue()); } catch (_) { /* 忽略同步异常 */ }
      }
    }
  }

  /* 暴露纯 DOM 块级插入/删除助手到 window.__vdBlock（jsdom 回归断言用），不改业务路径 */
  window.__vdBlock = {
    irInsertAbove: irInsertAbove,
    isEmptyLine: isEmptyLine,
    blockRootOf: blockRootOf,
    caretAtBlockStart: caretAtBlockStart,
    handleIrDeleteKeydown: handleIrDeleteKeydown,
  };

  /** 取单元格在其所在行中的列索引
   * @param {HTMLElement} row   行元素（tr）
   * @param {HTMLElement} cell  td/th
   * @returns {number} */
  function irTableCellIndex(row, cell) {
    return Array.prototype.indexOf.call(row.children, cell);
  }

  /** 在当前行上/下方插入一行（行内单元格数与参考行一致；表头行用 th，数据行用 td）
   * 边界：表头行(th)下方插入时，新行必须落到 `|---|` 分隔线之下（tbody 首行），
   * 否则会串进 thead 变成第二行表头，序列化后出现在分隔线上方。
   * @param {HTMLElement} table   表格
   * @param {HTMLElement} refRow  参考行
   * @param {boolean} before      true=上方插入 | false=下方插入
   * @returns {HTMLElement} 新行 */
  function irInsertRow(table, refRow, before) {
    const isHeader = refRow.parentNode && refRow.parentNode.nodeName === 'THEAD';
    // 新插入的行一律是数据行（td）。注意：绝不往 thead 里插新表头行，
    // 否则序列化会出现「分隔线上方」的假表头。
    const tr = document.createElement('tr');
    const n = refRow.cells ? refRow.cells.length : 0;
    for (let i = 0; i < n; i++) {
      const cell = document.createElement('td');
      cell.innerHTML = '\u00a0<br>';
      tr.appendChild(cell);
    }
    if (isHeader) {
      // 表头下方插行：作为首条数据行放到 tbody（分隔线之下）
      let tb = table.querySelector('tbody');
      if (!tb) { tb = document.createElement('tbody'); table.appendChild(tb); }
      tb.insertBefore(tr, tb.firstChild || null);
    } else if (before) {
      refRow.parentNode.insertBefore(tr, refRow);
    } else if (refRow.nextSibling) {
      refRow.parentNode.insertBefore(tr, refRow.nextSibling);
    } else {
      refRow.parentNode.appendChild(tr);
    }
    return tr;
  }

  /** 在参考列左/右侧插入一列（对每一行实行插入单元格；表头行用 th，数据行用 td）
   * @param {HTMLElement} table  表格
   * @param {HTMLElement} refRow 参考行（取列数基准）
   * @param {number} idx         参考列索引
   * @param {boolean} before     true=左侧 | false=右侧
   */
  function irInsertCol(table, refRow, idx, before) {
    const rows = table.rows || [];
    for (let r = 0; r < rows.length; r++) {
      const row = rows[r];
      if (!row.cells || row.cells.length <= idx) continue;
      const tag = (row.parentNode && row.parentNode.nodeName === 'THEAD') ? 'th' : 'td';
      const cell = document.createElement(tag);
      cell.innerHTML = '\u00a0<br>';
      if (before) {
        row.cells[idx].parentNode.insertBefore(cell, row.cells[idx]);
      } else {
        row.cells[idx].insertAdjacentElement('afterend', cell);
      }
    }
  }

  /** 删除参考行（边界：表头行不可删，否则失去表头；仅数据行可删，且保留至少一行避免整表被清空）
   * @param {HTMLElement} table  表格
   * @param {HTMLElement} refRow 待删行 */
  function irDeleteRow(table, refRow) {
    const isHeader = refRow.parentNode && refRow.parentNode.nodeName === 'THEAD';
    if (isHeader) return; // 表头行不可删除
    if ((table.rows || []).length > 1) refRow.parentNode.removeChild(refRow);
  }

  /** 删除参考列（每行仅当列数 >1 才删）
   * @param {HTMLElement} table  表格
   * @param {HTMLElement} refRow 参考行
   * @param {number} idx         待删列索引 */
  function irDeleteCol(table, refRow, idx) {
    const rows = table.rows || [];
    for (let r = 0; r < rows.length; r++) {
      const row = rows[r];
      if (!row.cells || row.cells.length <= idx || row.cells.length <= 1) continue;
      row.removeChild(row.cells[idx]);
    }
  }

  /* 暴露纯 DOM 表格助手到 window.__vdTable（jsdom 回归断言用），不改业务路径 */
  window.__vdTable = {
    irInsertRow: irInsertRow,
    irInsertCol: irInsertCol,
    irDeleteRow: irDeleteRow,
    irDeleteCol: irDeleteCol,
    irTableCellIndex: irTableCellIndex,
  };

  /** 构建表格右键菜单单项
   * @param {string} label 文案
   * @param {string} icon  lucide 图标名
   * @param {Function} action 点击回调 */
  function irTableMenuItem(label, icon, action) {
    const item = document.createElement('button');
    item.type = 'button';
    item.style.cssText = 'display:flex;align-items:center;gap:8px;width:100%;'
      + 'padding:6px 10px;border:none;background:transparent;color:var(--note-ink,#333);'
      + 'font-size:13px;text-align:left;cursor:pointer;border-radius:4px;';
    item.addEventListener('mouseover', function () { item.style.background = 'rgba(0,0,0,.06)'; });
    item.addEventListener('mouseout', function () { item.style.background = 'transparent'; });
    item.innerHTML = '<i data-lucide="' + icon + '" class="w-4 h-4"></i><span>' + label + '</span>';
    item.addEventListener('mousedown', function (e) { e.preventDefault(); }); // 不抢走编辑器光标
    item.addEventListener('click', function () { closeIrTableMenu(); action(); });
    return item;
  }

  /** 关闭 IR 右键菜单（表格/代码块共用同一菜单容器元素） */
  function closeIrTableMenu() {
    const menu = document.getElementById('ed-ir-table-menu');
    if (menu) menu.remove();
    const backdrop = document.getElementById('ed-ir-table-backdrop');
    if (backdrop) backdrop.remove();
  }

  /** 通用 IR 右键菜单展示（定位 + 遮罩 + 图标刷新；靠近边缘自动翻转防溢出）
   * @param {number} x 鼠标 X
   * @param {number} y 鼠标 Y
   * @param {Array<{label:string,icon:string,action:Function}>} items 菜单项 */
  function showIrMenu(x, y, items) {
    closeIrTableMenu();
    const menu = document.createElement('div');
    menu.id = 'ed-ir-table-menu';
    menu.style.cssText = 'position:fixed;z-index:180;min-width:160px;padding:6px;'
      + 'background:var(--note-surface-2,#fff);border:1px solid var(--note-border,#e0e0e0);'
      + 'border-radius:8px;box-shadow:0 6px 18px rgba(0,0,0,.16);';
    items.forEach(function (it) { menu.appendChild(irTableMenuItem(it.label, it.icon, it.action)); });
    document.body.appendChild(menu);
    const r = menu.getBoundingClientRect();
    menu.style.left = Math.min(Math.max(8, x), Math.max(8, window.innerWidth - r.width)) + 'px';
    menu.style.top = Math.min(Math.max(8, y), Math.max(8, window.innerHeight - r.height)) + 'px';
    // 遮罩：点击 / 右键 / 滚动 关闭
    const overlay = document.createElement('div');
    overlay.id = 'ed-ir-table-backdrop';
    overlay.style.cssText = 'position:fixed;inset:0;z-index:179;';
    overlay.addEventListener('contextmenu', function (e2) { e2.preventDefault(); closeIrTableMenu(); });
    overlay.addEventListener('click', closeIrTableMenu);
    overlay.addEventListener('scroll', closeIrTableMenu, true);
    document.body.appendChild(overlay);
    if (typeof refreshIcons === 'function') { try { refreshIcons(); } catch (_) { /* 忽略 */ } }
  }

  /** 显示 IR 表格右键菜单（靠近边缘自动翻转防溢出）
   * @param {number} x 鼠标 X
   * @param {number} y 鼠标 Y
   * @param {boolean} isHeader 是否光标在表头行（表头行不提供「上方插入行」「删除该行」） */
  function showIrTableMenu(x, y, isHeader) {
    const items = [];
    const defs = [
      ['在上方插入空行', 'arrow-up-to-line', 'block', 'before'],
      ['在上方插入行', 'arrow-up', 'row', 'before'],
      ['在下方插入行', 'arrow-down', 'row', 'after'],
      ['在左侧插入列', 'arrow-left', 'col', 'before'],
      ['在右侧插入列', 'arrow-right', 'col', 'after'],
      ['删除该行', 'unlink', 'row', 'delete'],
      ['删除该列', 'columns', 'col', 'delete'],
    ];
    defs.forEach(function (d) {
      if (isHeader && (d[2] + ':' + d[3] === 'row:before')) return; // 表头行不可在上方插入
      if (isHeader && (d[2] + ':' + d[3] === 'row:delete')) return; // 表头行不可删除
      items.push({ label: d[0], icon: d[1], action: function () { irTableBarAction(d[2], d[3]); } });
    });
    showIrMenu(x, y, items);
  }

  /** 显示 IR 代码块右键菜单：「在上方插入空行」+ 行号切换 + 换行切换
   * @param {number} x 鼠标 X
   * @param {number} y 鼠标 Y
   * 作者: 火 冰 */
  function showIrCodeMenu(x, y) {
    // 读取当前全局设置状态，动态生成带勾选标记的菜单项
    const lnOn = vdCodeLnOn();
    const wrapOn = vdCodeWrapOn();
    const menu = [{
      label: '在上方插入空行',
      icon: 'arrow-up-to-line',
      action: function () { irInsertAbove(irCtxCode); },
    }, {
      label: (lnOn ? '✓ ' : '  ') + '显示行号',
      icon: 'list',
      action: function () {
        if (typeof saveS === 'function') saveS('codeLineNumbers', !lnOn);
        vdCodeLnSchedule();
      },
    }, {
      label: (wrapOn ? '✓ ' : '  ') + '内容换行',
      icon: 'wrap-text',
      action: function () {
        if (typeof saveS === 'function') saveS('codeWrap', !wrapOn);
        vdCodeLnSchedule();
      },
    }];
    showIrMenu(x, y, menu);
  }

  /** 右键命中探测：落在 ir 编辑区某表格单元格内
   * @param {Event}  e 右键事件
   * @param {Object} v vditor 内部对象（vdInst.vditor）
   * @returns {{table:HTMLElement,tr:HTMLElement,td:HTMLElement}|null} */
  function irTableAtRightClick(e, v) {
    const node = e.target;
    if (!node || !v.ir || !v.ir.element || !v.ir.element.contains(node)) return null;
    const td = (node.nodeType === 1) ? node.closest('td,th')
      : (node.parentElement && node.parentElement.closest('td,th'));
    if (!td) return null;
    const tr = td.parentNode;
    const table = tr && tr.closest ? tr.closest('table') : null;
    return table ? { table: table, tr: tr, td: td } : null;
  }

  /** 右键命中探测：落在 ir 编辑区某代码块（.vditor-ir__node[data-type="code-block"] 内的 <pre><code>）中。
   *  注意不能用 closest('pre') 判定——vditor IR 会把整个编辑区内容包在一个 <pre class="vditor-reset"> 里，
   *  普通文字也命中 pre 而被误判为代码块（Bug-049）；须以代码块节点 data-type 区分。
   * @param {Event}  e 右键事件
   * @param {Object} v vditor 内部对象（vdInst.vditor）
   * @returns {HTMLElement|null} 代码块块级元素 */
  function irCodeAtRightClick(e, v) {
    const node = e.target;
    if (!node || !v.ir || !v.ir.element || !v.ir.element.contains(node)) return null;
    const el = (node.nodeType === 1) ? node : (node.parentElement || null);
    if (!el || typeof el.closest !== 'function') return null;
    // 真实代码块：外层带 data-type="code-block" 的 .vditor-ir__node（内含 <pre><code>）
    const blk = el.closest('[data-type="code-block"]');
    if (!blk || !v.ir.element.contains(blk)) return null;
    return blk;
  }

  /** 执行行/列操作并同步保存（右键菜单动作）
   * @param {string} axis 'row'|'col'|'block'
   * @param {string} op   'before'|'after'|'delete' */
  function irTableBarAction(axis, op) {
    if (!irCtxHit || !vdInst) return;
    const hit = irCtxHit;
    if (axis === 'block') {
      irCtxHit = null;
      irInsertAbove(hit.table);   // 在上方插入空行（含同步保存）
      return;
    }
    const v = vdInst.vditor;
    const idx = irTableCellIndex(hit.tr, hit.td);
    if (axis === 'row') {
      if (op === 'delete') irDeleteRow(hit.table, hit.tr);
      else irInsertRow(hit.table, hit.tr, op === 'before');
    } else {
      if (op === 'delete') irDeleteCol(hit.table, hit.tr, idx);
      else irInsertCol(hit.table, hit.tr, idx, op === 'before');
    }
    // IR 下 getValue 实时由 ir.element.innerHTML 推导，改完直接回传宿主保存
    try { sync2Host(vdInst.getValue()); } catch (_) { /* 忽略同步异常 */ }
    irCtxHit = null;
    if (v.ir && v.ir.element) { try { v.ir.element.focus(); } catch (_) { /* 忽略 */ } }
  }

  /* IR 右键：落在表格单元格内弹表格菜单；落在代码块内弹代码块菜单；其余（切 IR 或非块）放行默认 */
  document.addEventListener('contextmenu', function (e) {
    if (!vdInst || vdMode !== 'ir') { irCtxHit = null; irCtxCode = null; return; }
    const v = vdInst.vditor;
    const hit = irTableAtRightClick(e, v);
    if (hit) {
      e.preventDefault();
      irCtxHit = hit; irCtxCode = null;
      const isHeader = hit.tr && hit.tr.parentNode && hit.tr.parentNode.nodeName === 'THEAD';
      showIrTableMenu(e.clientX, e.clientY, isHeader);
      return;
    }
    const code = irCodeAtRightClick(e, v);
    if (code) {
      e.preventDefault();
      irCtxCode = code; irCtxHit = null;
      showIrCodeMenu(e.clientX, e.clientY);
      return;
    }
    irCtxHit = null; irCtxCode = null;
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeIrTableMenu(); });
  // 捕获阶段拦截 IR 光标下的 Backspace/Delete，修正「空行删不掉」与「块前删除空行」问题
  document.addEventListener('keydown', handleIrDeleteKeydown, true);

  /** 统一编辑器工具栏图标的悬浮提示：朝下显示名称(+快捷键)。
   *  vditor 内置项 tipPosition 均为朝上（n/nw/ne），而编辑器容器 #ed-vditor 是
   *  overflow:hidden 且工具栏位于最顶端——朝上的悬浮延伸出容器被裁剪、故默认项看不到悬浮；
   *  自定义项无方向后缀、落在图标下方，在容器内可见。这里把全部图标悬浮统一朝下（__s），
   *  复用 vditor 自带 aria-label 渲染（内容 = tip + 快捷键，快捷键按自身实际设置显示；
   *  无快捷键项仅显示名称）。作者: 火 冰
   * @param {object} vd vditor 实例（含 toolbar.elements） */
  function sbEnsureToolbarHoverTips(vd) {
    if (!vd || !vd.toolbar || !vd.toolbar.elements) return;
    const names = Object.keys(vd.toolbar.elements);
    for (let i = 0; i < names.length; i++) {
      const node = vd.toolbar.elements[names[i]];
      if (!node) continue;
      // 按钮或其子图标都可能承载 .vditor-tooltipped；统一改为朝下以防上溢出被裁剪
      const tipEls = node.querySelectorAll('.vditor-tooltipped');
      for (let j = 0; j < tipEls.length; j++) {
        const b = tipEls[j];
        let al = (b.getAttribute('aria-label') || '').trim();
        if (!al || al === 'undefined' || al === 'null') al = (b.getAttribute('data-type') || '');
        // 自绘悬浮提示数据：名称 + 实际快捷键（快捷区 <键> 转 [键]）；无快捷键项仅名称。
        // 内容复用 vditor aria-label，快捷键按其实际设置显示，不编造。
        const norm = al.replace(/\s*<([^>]+)>\s*$/, ' [$1]').trim();
        b.setAttribute('data-sb-tip', norm);
        // 移除 vditor 自带 ::after 悬浮源(aria-label)与原生 title，杜绝与自绘浮层重复显示
        b.removeAttribute('aria-label');
        b.removeAttribute('title');
      }
    }
  }
  /* 暴露测试句柄：供 regression 断言悬浮数据（data-sb-tip）正确 */
  window.__sbEnsureToolbarTips = sbEnsureToolbarHoverTips;

  /* ============================================================
   * 工具栏自绘悬浮浮层（兜底：vditor ::after / 原生 title 在本环境容器内不可见）
   * 在文档捕获阶段根据光标位置定位到编辑器工具栏按钮，弹一个 fixed 浮层显示
   * 名称(+快捷键)。fixed 定位、不受任何 overflow:hidden 裁剪，保证必见。
   * 作者: 火 冰
   * ============================================================ */
  let sbTipEl = null;

  /** 取工具栏按钮悬浮文本（优先自绘数据，回退 aria/title/data-type） */
  function sbToolbarTipText(b) {
    return String(b.getAttribute('data-sb-tip')
      || b.getAttribute('aria-label')
      || b.getAttribute('data-type') || '').trim();
  }

  /** 在光标位置附近显示悬浮浮层 */
  function sbTipShow(txt, x, y) {
    if (!txt) return;
    if (!sbTipEl) {
      sbTipEl = document.createElement('div');
      sbTipEl.className = 'sb-tip';
      sbTipEl.style.display = 'none';
      document.body.appendChild(sbTipEl);
    }
    sbTipEl.textContent = txt;
    const gw = sbTipEl.offsetWidth || 0, gh = sbTipEl.offsetHeight || 0;
    let nx = x + 12, ny = y + 14;
    if (nx + gw > window.innerWidth - 4) nx = x - gw - 12;
    if (ny + gh > window.innerHeight - 4) ny = y - gh - 10;
    sbTipEl.style.left = nx + 'px';
    sbTipEl.style.top = ny + 'px';
    sbTipEl.style.display = 'block';
  }

  /** 隐藏悬浮浮层 */
  function sbTipHide() {
    if (sbTipEl) sbTipEl.style.display = 'none';
  }

  /** 绑定全局悬浮委托：命中编辑器工具栏按钮时自绘提示（事件委托，按钮重建仍生效） */
  function sbInitToolbarTip() {
    document.addEventListener('mousemove', function (e) {
      const t = e.target;
      // 屏蔽 file input 的原生悬停提示（Chromium 约 3 秒后显示「未选择任何文件」：vditor 上传用
      // 透明 <input type=file> 覆盖在按钮上承接原生选择，悬停即触发该 UA tooltip）。首次 hover
      // 即把 title 清空（空 title 不显示 tooltip），不影响上传（上传点击走按钮 click 校验，与 title 无关）。
      if (t && t.tagName === 'INPUT' && String(t.type) === 'file' && !t.hasAttribute('title')) {
        t.setAttribute('title', '');
      }
      // 命中工具栏任意带悬浮类的元素：普通内置/自定义项是 button 内 .vditor-tooltipped 图标，
      // 而「上传」按钮 vditor 单独渲染为 div.vditor-tooltipped（非 button，见 vditor toolbar
      // 构建 tagName=upload?'div':'button'）。故统一按 .vditor-tooltipped 命中，避免上传悬浮不显示。
      const tipEl = t && t.closest
        && t.closest('#ed-vditor .vditor-toolbar .vditor-tooltipped');
      if (!tipEl) { sbTipHide(); return; }
      sbTipShow(sbToolbarTipText(tipEl), e.clientX, e.clientY);
    });
    document.addEventListener('mouseout', function (e) {
      if (e.target && e.target.closest && e.target.closest('#ed-vditor .vditor-toolbar .vditor-tooltipped')) sbTipHide();
    });
    // 编辑器视图重建后重新绑定不受影响（事件委托挂在 document，无需重绑）
  }
  sbInitToolbarTip();

  /** 构建 vditor 实例（核心装配）。在 vdInst 存在时先销毁保留内容。
   * 说明：edit/split/preview 用 setPreviewMode 切换，无需重建；仅 ir↔sv 切换才重建。 */
  function buildVditor() {
    const el = vdEl();
    // 重建前保底取当前内容：实例存在时 try 取 getValue，失败（异步首帧未完成/销毁中途，此时
    // vditor 内部 this.Vditor 尚未就绪，IR 下 getValue 访问 VditorIRDOM2Md 会抛 Undefined，
    // 导致启动/快速重建时编辑区空白）则回退暂存缓冲 vdBuffer。作者: 火 冰
    const cur = vdInst ? safeGetValue() : undefined;
    const value = (cur != null) ? cur : vdBuffer;
    if (vdInst) { try { vdInst.destroy(); } catch (_) { /* 忽略销毁异常 */ } }
    vdInst = null;
    vdReady = false;   // 重建后视为未就绪，待 after 回调确认首帧渲染完成
    if (!el || typeof window.Vditor !== 'function') {
      vdBuffer = value;   // vditor 不可用（如 jsdom/无依赖）时保留缓冲，保障宿主不崩
      // Bug-075：容器已存在而 window.Vditor 脚本未就绪（note:// 启动时主进程 clearCache 与
      // 渲染端脚本加载存在竞态），原实现静默放弃且永不重试 → 整窗编辑区永久空白、无报错。
      // 改为 500ms 间隔延迟重试构建（60 次上限 30s），jsdom 回归沙箱无真实脚本仍保持跳过；
      // el 不存在（视图尚未重建）时不重试：后续 openNote→vdSyncValue→ensureVd 会再次触发。
      if (el && !vdBuildRetryTimer
          && !(navigator && /jsdom/i.test(navigator.userAgent))) {
        vdBuildRetryLeft = 60;
        vdBuildRetryTimer = setTimeout(function retryBuild() {
          vdBuildRetryTimer = null;
          if (vdInst || vdBuildRetryLeft-- <= 0) return;   // 已有实例 / 重试耗尽即停
          const el2 = vdEl();
          if (!el2 || typeof window.Vditor !== 'function') {
            vdBuildRetryTimer = setTimeout(retryBuild, 500);
            return;
          }
          buildVditor();   // 脚本就绪：重走正常构建，vdBuffer 中的待渲内容随 value 装载
        }, 500);
      }
      return;
    }
    /* 闭包捕获待创建实例：vditor 的 after 回调是平调用（this 不指向实例），
     * 且可能在 new 返回前触发，故用 inst 变量在构造后立即填充，供回调取用。 */
    let inst = null;
    const seq = ++vdBuildSeq;   // 本次构建序号：after 据此识别是否为当前最新实例，防并发乱序
    const opts = {
      mode: vdMode,
      value: value,
      cache: false,
      // 资源直接走 node_modules/vditor/dist（npm 运行时依赖，随包分发，含官方 dist 目录结构），
      // 避免从 unpkg.com 拉 i18n/lute/主题/icons 造成弱网下编辑区十几秒才渲染（Bug-029），
      // 也避免在仓库内 vendor 复制 vditor 导致 dist 迁移占用/历史膨胀（Bug-031）。
      cdn: 'node_modules/vditor',
      theme: resolveVdTheme().theme,
      /* 工具栏 = 宿主内置项 + 插件/宿主经注入桥入队的自定义按钮（宽屏/列宽/大纲/全屏） */
      toolbar: VDTOOLBAR.concat(window.__sbVdToolbarInjects || []),
      preview: {
        delay: 50, cdn: '', mode: (vdPreview === 'both') ? 'both' : 'editor', transform: transformPreviewHtml,
        // 隐藏预览顶部的动作条（Desktop/Tablet/Mobile/Wechat/知乎 等预览动作按钮），置空 actions 即不渲染
        actions: [],
        // 预览/阅读模式代码块行号由宿主自绘（.sb-code-gutter，见下方「代码块行号」模块）：
        // vditor 内置 .vditor-linenumber 与 code 内边距/字号错位不可修（Bug-065），故内置行号保持关闭，
        // 仅以本配置防内置残留。源码模式行号由宿主自绘（vdSvGutterRefresh），与此无关。
        hljs: { lineNumber: false },
      },
      // 上传图片/附件：accept 覆盖图片与常用附件（pdf/office/脚本/压缩包等），
      // handler 由桌面端 IPC 落盘 .resources（UUID 重命名），笔记内链接使用真实名。
      upload: {
        max: 50 * 1024 * 1024,
        multiple: true,
        accept: 'image/*,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.html,.htm,.md,.txt,.sh,.bat,.cmd,.ps1,.csv,.zip,.rar,.7z,.asc',
        filename: function (name) { return name; },
        handler: handleVdUpload,
      },
      /* Bug-079: 输入时 debounced push 当前 tab 的 undo 历史（500ms 去抖）。
       * vditor 原生 undo 栈已被宿主层取代，这里维护 per-tab 独立历史。作者: 火 冰 */
      input: function (v) {
        const _p0 = performance.now();
        if (v === vdLastInputV) return;   // 内容未变跳过整条回调链
        vdLastInputV = v;

        const _g0 = performance.now();
        sync2Host(v);
        const _g1 = performance.now();

        const _o0 = performance.now();
        window.sbOutlineNotify();
        const _o1 = performance.now();

        const _u0 = performance.now();
        if (vdMode === 'sv') {
          if (vdSvGutter._deb) clearTimeout(vdSvGutter._deb);
          vdSvGutter._deb = setTimeout(function () { vdSvGutterRefresh(); }, 300);
        }
        const _u1 = performance.now();

        const _d0 = performance.now();
        if (vdLastTabPath) vdDebouncePush(vdLastTabPath, v);
        const _d1 = performance.now();

        const _p1 = performance.now();
        const _P = _p1 - _p0;
        if (_P > 5) {
          console.warn('[PERF][INPUT] total=', _P.toFixed(1), 'ms',
            'mode=' + vdMode,
            'sync2Host=', (_g1 - _g0).toFixed(1),
            'outline=', (_o1 - _o0).toFixed(1),
            'gutter=', (_u1 - _u0).toFixed(1),
            'debPush=', (_d1 - _d0).toFixed(1));
        }
      },
      blur: function () {
        // 首帧异步渲染完成前（vdReady=false）不触发保存：此时 vditor 内部未就绪，getValue 抛错
        // 会回退暂存缓冲，若缓冲为空会把空内容经 onEdInput 落入防抖保存，覆盖磁盘——笔记被自动清空
        // （Bug-052，文件只剩 1 字节换行）。渲染完成后才允许 blur 同步内容。作者: 火 冰
        if (!vdReady) return;
        const md = vdGetValue();
        sync2Host(md);
        // Bug-079: blur 时立即 push 一份到当前 tab 的 undo 栈（不走去抖），
        // 确保切 tab 后 outgoing 的历史点已被记录。作者: 火 冰
        if (vdLastTabPath) vdDoPush(vdLastTabPath, md);
      },
      /* vditor 首帧异步渲染完成后的回调：把 init 期间积压的待渲内容补进编辑器，
       * 修复启动/快速切换时「工具栏渲染正常但内容区空白」的时序问题。
       * 注意回调内 this 不指向实例，必须用 inst/vdInst 显式引用。
       * 作者: 火 冰 */
      after: function () {
        // 仅最新一次构建的实例才消费暂存内容/接管显隐：启动/快速切换时 vdInit 先以
        // 默认 IR 构建一次，恢复记忆模式（如 WYSIWYG）再重建一次，两次异步 after 可能乱序。
        // 若旧实例的 after 先触发，会抢占共享 vdPending 并把内容 setValue 到已销毁实例上，
        // 使当前活动实例渲染后空白（Bug-050 启动编辑器闪烁后空白）。故 seq 不匹配旧实例则放行。
        if (seq !== vdBuildSeq) return;
        vdReady = true;
        const target = inst || vdInst;
        const pending = (vdPending != null) ? vdPending : '';
        vdPending = null;
        if (pending !== '' && target) {
          try { target.setValue(pending, true); console.log('[vditor] 首帧渲染完成，已补渲 ' + pending.length + ' 字符'); }
          catch (e) { console.warn('[vd-after] setValue error: ' + e); }
        }
        // 异步首帧渲染后，vditor 可能按默认 preview 布局重置各视图显隐；
        // 再确定性覆盖一次，确保进入「仅源码/仅预览」等布局时其它视图不残留。
        applyVdVisibility();
        // 统一工具栏图标悬浮方向朝下（内置项朝上悬浮在 overflow:hidden 容器内被裁剪，不可见）
        sbEnsureToolbarHoverTips(target);
        // 新实例异步渲染完成后，通知插件大纲重建（切文档/分屏重建场景下标题实时跟随）
        window.sbOutlineNotify();
        // 首帧补渲（setValue）完成后再扫一次代码块行号（observer 可能晚于补渲触发）
        vdCodeLnSchedule();
        // 工具栏自定义按钮（行号/换行）首次渲染后同步激活态高亮
        vdToolbarRefreshStates();
        // 性能优化：vditor 就绪后把附件引言块 observer 从 documentElement 重挂到编辑区根，
        // 排除工具栏 tooltip、设置面板等无关 DOM 变化触发的无效扫描
        watchAttachCallouts();
      },
    };
    try {
      inst = new window.Vditor(el, opts);
      vdInst = inst;
      // 构建期不清空 vdBuffer：vditor 首帧渲染是异步的（after 前 vdReady=false），期间 blur/异常
      // 回退暂存缓冲时，若 vdBuffer 已清空会把空内容经 onEdInput 落盘覆盖磁盘——笔记被自动清空
      // （Bug-052）。vdBuffer 恒为最近一次 vdSyncValue/vdSetValue 的内容，由下次同步覆盖，无残留。
      // 构建后应用解析出的额外主题 CSS（插件注入的编辑器覆盖样式）
      applyVdExtraCss(resolveVdTheme().extraCss);
      // 构建后确定性应用当前模式对应的视图显隐（sv 三种布局 / ir / wysiwyg），
      // 取代 vditor setPreviewMode（其对 'preview' 无效且会强制 sv 源码可见）
      applyVdVisibility();
      // 构建即挂代码块行号观察器并首轮扫描（IR 渲染态/预览/阅读代码块行号）
      vdCodeLnEnsureObserver();
    } catch (err) {
      vdInst = null;
      vdBuffer = value;
      console.error('[vditor] 初始化失败：', err);
    }
  }

  /** 确保实例存在并返回（懒创建）；vditor 不可用时返回 null。
   * 冷启动（开机后首次）时编辑器装载与视图重建/插件重挂并发，#ed-vditor 容器可能被替换，
   * 旧实例仍指向已摘除节点：对它的 setValue 只写进脱离 DOM 的节点，界面恒空白且切换文件也无法
   * 恢复（Bug-069，仅新窗/重启重建才恢复）。故检测到实例根节点已脱离文档即销毁重建到当前容器，
   * 保证内容始终进入可视实例。作者: 火 冰 */
  function ensureVd() {
    const root = vdInst && vdInst.vditor && vdInst.vditor.element;
    if (vdInst && root && root.isConnected === false) {
      if (window.SBLog) window.SBLog.warn('[vditor] 实例容器已脱离文档，自愈重建');
      else console.warn('[vditor] 实例容器已脱离文档，自愈重建');
      try { vdInst.destroy(); } catch (_) { /* 忽略销毁异常 */ }
      vdInst = null;
      vdReady = false;
    }
    if (!vdInst) buildVditor();
    return vdInst;
  }

  /* ---------- 宿主桥接函数（暴露到 globalThis，供 editor-host.js 与插件 action 调用） ---------- */

  /** 初始化：懒创建 vditor 实例（首次渲染实际内容见 vdSyncValue） */
  window.vdInit = function () {
    vdPreview = 'editor';
    ensureVd();
  };

  /** 把某篇笔记内容同步进编辑区（首次打开懒创建实例）；内容会覆盖编辑器当前内容并重置为保存态
   * 说明：分屏(both)布局下 vditor 运行期 setValue 只刷新右侧预览、左侧源码面板不同步，会呈现
   * 「左大片空白 + 右侧窄条」；故分屏态改为销毁重建实例，让两侧面板都用新内容填充。
   * Bug-079 升级：path 变化时先 save outgoing undo → setValue(md,true) → restore incoming undo，
   * 实现每页签独立 Ctrl+Z 历史栈；path 不变（Provider 切换等）则只 setValue。
   * @param {string} md markdown 源文本
   * @param {string} [path] 当前 tab path（不传则跳过 undo 历史隔离） */
  /** @type {string|null} 上次 vdSyncValue 同步过的 tab path（切 tab 时识别 outgoing/incoming） */
  let vdLastTabPath = null;

  /* Bug-079: 捕获阶段拦截 Ctrl+Z / Ctrl+Shift+Z / Ctrl+Y，用宿主层 per-tab 历史栈执行 undo/redo。
   * 放在捕获阶段（capture=true）且先 preventDefault+stopImmediatePropagation，
   * 彻底屏蔽 vditor 原生的 keydown 处理和 Chromium 默认行为。
   * 必须在 IIFE 顶层立即注册一次，不能等 vditor 构建好（否则快速 Ctrl+Z 可能没拦截到）。
   * 作者: 火 冰 */
  document.addEventListener('keydown', function (e) {
    if (!vdInst || !vdLastTabPath) return;
    // 快捷键目标必须在编辑器容器内（输入框、下拉菜单等走默认行为）
    const vdEl = (vdInst && vdInst.vditor && vdInst.vditor.element) || document.getElementById('ed-vditor');
    if (!vdEl) return;
    const active = document.activeElement;
    if (!active || !vdEl.contains(active)) return;
    if (e.altKey) return;   // Alt 组合键不拦截
    const ctrl = e.ctrlKey || e.metaKey;
    if (!ctrl) return;
    const k = e.key;
    const isZ = (k === 'z' || k === 'Z');
    const isY = (k === 'y' || k === 'Y');
    if (!isZ && !isY) return;
    const path = vdLastTabPath;
    if (isZ && !e.shiftKey) {
      // Ctrl+Z → undo
      e.preventDefault(); e.stopImmediatePropagation();
      vdDoUndo(path);
    } else if ((isZ && e.shiftKey) || isY) {
      // Ctrl+Shift+Z / Ctrl+Y → redo
      e.preventDefault(); e.stopImmediatePropagation();
      vdDoRedo(path);
    }
  }, true);

  /* Bug-080: 拦截 beforeinput（DOM 修改**之前**）和 paste 事件（兜底），
   * 实现 vditor 表格单元格多格粘贴（Excel 复制 tab 分隔）。
   * 根因：vditor 原生 + 浏览器默认 paste 行为是把剪贴板内容整段塞进当前 contenteditable，
   * 不解析 tab 分隔多格分发。**paste 事件拦截太晚**（DOM 已被修改），
   * 必须在 **beforeinput** 阶段拦截（inputType='insertFromPaste'）+ preventDefault。
   * 同时保留 paste 事件拦截作为 fallback（某些场景 beforeinput e.data 为空）。
   * 作者: 火 冰 */

  /** 用 Selection API 找到光标所在的 TD/TH。
   * 关键：vditor contenteditable 的 document.activeElement 是整个编辑器容器（.vditor-wysiwyg），
   * 不是光标所在的 cell。必须用 window.getSelection().anchorNode 往上 traverse。
   * @returns {HTMLElement|null} 光标所在的 TD/TH，或 null
   * @author 火 冰 */
  function vdGetCursorCell() {
    try {
      const sel = window.getSelection();
      if (!sel || sel.rangeCount === 0) return null;
      const node = sel.anchorNode;
      if (!node) return null;
      // 文本节点：parentElement 往上找
      if (node.nodeType === 3) {
        const parent = node.parentElement;
        return parent ? (parent.closest && (parent.closest('TD') || parent.closest('TH'))) : null;
      }
      // 元素节点：直接 closest
      if (node.nodeType === 1) {
        return node.closest && (node.closest('TD') || node.closest('TH'));
      }
      return null;
    } catch (_) { return null; }
  }

  /** 解析剪贴板内容到 grid[row][col]。
   * 优先解析 text/html（用 TD/TH 边界最明确，cell 内换行不被误判），
   * 没有 HTML 时 fallback 到 text/plain（\n 分行、\t 分列、<br> 还原 cell 内换行）。
   * @param {string} html clipboardData.getData('text/html')
   * @param {string} plain clipboardData.getData('text/plain')
   * @returns {Array<Array<{text:string, isHtml:boolean}>>|null} grid，null 表示无法解析
   * @author 火 冰 */
  function vdParseClipboardToGrid(html, plain) {
    // 1) 优先解析 HTML（最准）
    if (html && /<table[\s\S]*<(td|th)[\s\S]*<\/(td|th)>[\s\S]*<\/table>/i.test(html)) {
      try {
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        const table = doc.querySelector('table');
        if (table && table.rows.length > 0) {
          const grid = [];
          for (let i = 0; i < table.rows.length; i++) {
            const rowCells = [];
            const cells = table.rows[i].cells;
            if (cells.length === 0) continue; // 跳过空行（thead/tbody 可能的结构）
            for (let j = 0; j < cells.length; j++) {
              const c = cells[j];
              // 用 innerHTML 保留 cell 内换行等结构
              rowCells.push({ text: c.innerHTML || '', isHtml: true });
            }
            grid.push(rowCells);
          }
          if (grid.length > 0) {
            return grid;
          }
        }
      } catch (_) { /* 忽略 HTML 解析异常 */ }
    }

    // 2) Fallback: 解析 text/plain
    if (!plain) return null;
    const cleaned = plain.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    const rows = cleaned.split('\n');
    while (rows.length > 0 && rows[rows.length - 1].trim() === '' && rows.length > 1) rows.pop();
    const grid = rows.map(function (r) {
      return r.split('\t').map(function (cell) {
        // copy 时把 cell 内换行转成 <br> 避免和行分隔 \n 混淆
        // paste 时把 <br> 还原回 \n（作为 cell 内换行）
        return { text: cell.replace(/<br\s*\/?>/gi, '\n'), isHtml: false };
      });
    });
    return grid;
  }

  /** 核心分发函数：把 grid[row][col] 从 cellEl 开始逐格填充表格。
   * 超出边界时自动扩展行列。
   * @param {HTMLElement} cellEl 活动单元格（TD/TH）
   * @param {Array<Array<{text:string, isHtml:boolean}>>} grid 从剪贴板解析来的二维数组
   * @author 火 冰 */
  function vdPasteTableGrid(cellEl, grid) {
    if (!grid || grid.length === 0) return;

    // ★ 单格内容：从光标位置插入，保留 cell 内其他内容
    if (grid.length === 1 && grid[0].length === 1) {
      const item = grid[0][0];
      const val = item.text;

      try {
        const sel = window.getSelection();
        if (sel && sel.rangeCount > 0) {
          const range = sel.getRangeAt(0);
          // 只处理光标在 cellEl 内的情况
          if (cellEl.contains(range.startContainer)) {
            range.deleteContents();
            if (item.isHtml) {
              // HTML 内容：创建 fragment 插入
              const temp = document.createElement('div');
              temp.innerHTML = val;
              const frag = document.createDocumentFragment();
              while (temp.firstChild) frag.appendChild(temp.firstChild);
              range.insertNode(frag);
            } else {
              // 纯文本：把 \n 转 <br> 让 vditor 渲染
              const html = val ? val.replace(/\r?\n/g, '<br>') : '';
              const temp = document.createElement('div');
              temp.innerHTML = html;
              const frag = document.createDocumentFragment();
              while (temp.firstChild) frag.appendChild(temp.firstChild);
              range.insertNode(frag);
            }
            // 光标移到插入内容末尾
            range.collapse(false);
            sel.removeAllRanges();
            sel.addRange(range);
            vdDebouncePush(vdLastTabPath);
            // Bug-080 补：触发宿主层保存（vditor input 因 preventDefault 没触发）
            const md1 = vdGetValue(); sync2Host(md1);
            window.sbOutlineNotify && window.sbOutlineNotify();
            vdSvGutterRefresh && vdSvGutterRefresh();
            return;
          }
        }
      } catch (_) { /* Selection 操作异常，fallback 到覆盖 */ }

      // Fallback：光标不在 cell 内或插入失败 → 覆盖当前 cell
      cellEl.innerHTML = item.isHtml ? (val || '<br>') : (val ? val.replace(/\r?\n/g, '<br>') : '<br>');
      vdDebouncePush(vdLastTabPath);
      // Bug-080 补：触发宿主层保存
      const md2 = vdGetValue(); sync2Host(md2);
      window.sbOutlineNotify && window.sbOutlineNotify();
      vdSvGutterRefresh && vdSvGutterRefresh();
      return;
    }

    // ★ 多格内容：从 cellEl 开始逐格覆盖

    // 定位起始 cell 坐标
    const tableEl = cellEl.closest('TABLE');
    let startRow = -1, startCol = -1;
    const trs = tableEl.rows;
    for (let i = 0; i < trs.length; i++) {
      const tds = trs[i].cells;
      for (let j = 0; j < tds.length; j++) {
      }
      if (startRow >= 0) break;
    }

    // 先清 cellEl 里 vditor/浏览器已经塞进来的内容
    cellEl.innerHTML = '<br>';

    // 逐格填充；表格不够大时自动扩展
    for (let r = 0; r < grid.length; r++) {
      let row = startRow + r;
      while (row >= tableEl.rows.length) {
        const lastTR = tableEl.rows[tableEl.rows.length - 1];
        if (!lastTR) break;
        const hasTh = /^\s*th\s*$/i.test(lastTR.firstElementChild && lastTR.firstElementChild.tagName);
        const newTR = document.createElement('tr');
        for (let c = 0; c < lastTR.cells.length; c++) {
          const tag = hasTh ? 'TH' : 'TD';
          const newCell = document.createElement(tag);
          newCell.innerHTML = '<br>';
          newTR.appendChild(newCell);
        }
        tableEl.appendChild(newTR);
      }
      const curTR = tableEl.rows[row];
      if (!curTR) continue;

      for (let c = 0; c < grid[r].length; c++) {
        let col = startCol + c;
        while (col >= curTR.cells.length) {
          const refTD = curTR.cells[curTR.cells.length - 1];
          const tag = refTD ? refTD.tagName : 'TD';
          const newCell = document.createElement(tag);
          newCell.innerHTML = '<br>';
          curTR.appendChild(newCell);
        }
        const cell = curTR.cells[col];
        if (!cell) continue;
        const item = grid[r][c];
        const val = item.text;

        // isHtml=true → innerHTML 保留结构（cell 内换行 <br> 等）
        // isHtml=false → innerHTML 把 \n 转成 <br> 让 vditor 能渲染
        if (item.isHtml) {
          cell.innerHTML = val || '<br>';
        } else {
          // 纯文本里可能有 cell 内换行（已还原成 \n），转 <br> 保留
          cell.innerHTML = val ? val.replace(/\r?\n/g, '<br>') : '<br>';
        }
      }
    }

    // 选中起始 cell 让用户继续编辑
    try {
      cellEl.focus();
      const sel = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(cellEl);
      range.collapse(false);
      sel.removeAllRanges();
      sel.addRange(range);
    } catch (_) { /* 忽略 focus 异常 */ }

    // Bug-080 补：触发宿主层保存（vditor input 因 preventDefault 没触发）
    vdDebouncePush(vdLastTabPath);
    const md3 = vdGetValue(); sync2Host(md3);
    window.sbOutlineNotify && window.sbOutlineNotify();
    vdSvGutterRefresh && vdSvGutterRefresh();
  }

  /** beforeinput 阶段拦截（DOM 修改**之前**）——主拦截入口 */
  document.addEventListener('beforeinput', function (e) {
    // 只关心粘贴动作
    if (e.inputType !== 'insertFromPaste') return;
    if (!vdInst) return;
    const vdEl = (vdInst && vdInst.vditor && vdInst.vditor.element) || document.getElementById('ed-vditor');
    if (!vdEl) return;
    const active = document.activeElement;
    if (!active || !vdEl.contains(active)) return;
    const cellEl = vdGetCursorCell();
    if (!cellEl) return; // 不在表格里 → 放行

    // beforeinput 的 e.data 只有纯文本，没有 HTML（Chrome 行为）
    let text = '';
    if (e.data && typeof e.data === 'string' && e.data.length > 0) text = e.data;
    if (!text) return; // 没内容 → 放行让 paste 兜底

    e.preventDefault();
    e.stopImmediatePropagation();
    const grid = vdParseClipboardToGrid(null, text);
    if (grid) vdPasteTableGrid(cellEl, grid);
  }, true);

  /** paste 事件兜底：某些 Electron 版本 beforeinput e.data 可能为空，这里从 clipboardData 取 */
  document.addEventListener('paste', function (e) {
    if (!vdInst) return;
    const vdEl = (vdInst && vdInst.vditor && vdInst.vditor.element) || document.getElementById('ed-vditor');
    if (!vdEl) return;
    const active = document.activeElement;
    if (!active || !vdEl.contains(active)) return;
    const cellEl = vdGetCursorCell();
    if (!cellEl) return;

    // 拿 text/plain 和 text/html，vdParseClipboardToGrid 会优先 HTML
    let html = '', plain = '';
    if (e.clipboardData && e.clipboardData.getData) {
      try { html = e.clipboardData.getData('text/html') || ''; } catch (_) { html = ''; }
      try { plain = e.clipboardData.getData('text/plain') || ''; } catch (_) { plain = ''; }
    } else if (window.clipboardData) {
      try { plain = window.clipboardData.getData('Text') || ''; } catch (_) { plain = ''; }
    }
    if (!html && !plain) return;

    e.preventDefault();
    e.stopImmediatePropagation();
    const grid = vdParseClipboardToGrid(html, plain);
    if (grid) vdPasteTableGrid(cellEl, grid);
  }, true);

  /** 把某篇笔记内容同步进编辑区（首次打开懒创建实例）；内容会覆盖编辑器当前内容并重置为保存态
   * 说明：分屏(both)布局下 vditor 运行期 setValue 只刷新右侧预览、左侧源码面板不同步，会呈现
   * 「左大片空白 + 右侧窄条」；故分屏态改为销毁重建实例，让两侧面板都用新内容填充。
   * Bug-079：path 变化时立即 push outgoing 快照到宿主历史栈，然后 setValue(clearStack=true)，
   * 最后 incoming redoStack 清空。宿主层拦截 Ctrl+Z/Shift+Z/Y 实现 per-tab 独立 undo。
   * @param {string} md markdown 源文本
   * @param {string} [path] 当前 tab path（不传则跳过 outgoing push 和 incoming redo 清空） */
  window.vdSyncValue = function (md, path) {
    vdBuffer = String(md == null ? '' : md);
    // 经 ensureVd 懒创建；若旧实例根节点已脱离文档（冷启动视图重建后容器被替换）则销毁重建，
    // 避免 setValue 写进已摘除节点、界面恒空白（Bug-069）。
    ensureVd();
    if (!vdInst) return;
    // 实例尚未完成异步渲染（vditor 的 mode 首帧渲染是异步的，见 options.after）：
    // 立即 setValue 会因首发渲染后重置而被丢弃，导致启动/快速切换时编辑区空白。
    // 故未就绪时先暂存，待 after 回调再补渲染进去。
    if (!vdReady) { vdPending = vdBuffer; return; }
    if (vdPreview === 'both') {
      // 分屏视图：重建实例以完整刷新左源码/右预览，避免 setValue 在分屏下的内容不同步窄条
      if (vdLastTabPath) { /* 切 tab 时分屏重建也要 push outgoing，但实例马上销毁，先从 vdBuffer 取 */ }
      try { vdInst.destroy(); } catch (_) { /* 忽略销毁异常 */ }
      vdInst = null;
      buildVditor();
      if (path) { vdLastTabPath = path; vdMarkFilled(path, vdBuffer); }
      return;
    }
    /* 切 tab 识别：path 显式传入且与上次不同 → push outgoing + 清 incoming redo；
     * path 未传或相同（Provider 切换）→ 只 setValue，不动历史栈。
     * 作者: 火 冰 */
    const pathChanged = (path != null && path !== vdLastTabPath);
    if (pathChanged) {
      // push outgoing：从 vditor 当前实例读内容（尚未被 setValue 覆盖）
      if (vdLastTabPath) {
        const curContent = (typeof vdInst.getValue === 'function') ? vdInst.getValue() : vdBuffer;
        vdDoPush(vdLastTabPath, curContent);
      }
      // 清 incoming redoStack（undoStack 保留）
      const h = vdEnsureHistory(path);
      if (h) { h.redoStack = []; }
      // 初始首次打开该 tab 时，把磁盘 md push 进 undoStack 作为「起始快照」
      if (h && h.undoStack.length === 0) {
        h.undoStack.push(vdBuffer);
        vdLastPushContent[path] = vdBuffer;
      }
      // 清除可能残留在旧 path 上的 debounce timer
      if (vdPushDebounceTimer) { clearTimeout(vdPushDebounceTimer); vdPushDebounceTimer = null; vdPushDebouncePath = null; vdPushDebounceMD = null; }
    }
    try { vdInst.setValue(vdBuffer, true); } catch (_) { /* 忽略 */ }
    if (pathChanged) { vdLastTabPath = path; vdMarkFilled(path, vdBuffer); }
    window.sbOutlineNotify();   // 切笔记后通知插件大纲重建，标题实时跟随当前文件
  };

  /** 仅在暂存缓冲层面设置内容（无实例时用于清空/占位，例如删除当前笔记后）
   * @param {string} md markdown 源文本 */
  window.vdSetValue = function (md) {
    vdBuffer = String(md == null ? '' : md);
    // 清空场景（如删除当前笔记后）：重置 path tracking，防止下次 vdSyncValue 误操作旧 path 的历史栈
    vdLastTabPath = null;
    if (vdPushDebounceTimer) { clearTimeout(vdPushDebounceTimer); vdPushDebounceTimer = null; vdPushDebouncePath = null; vdPushDebounceMD = null; }
    if (vdInst) { try { vdInst.setValue(vdBuffer, true); } catch (_) { /* 忽略 */ } }
    window.sbOutlineNotify();   // 切换/载入文档后通知插件大纲重建，标题实时跟随当前文件
  };

  /** 获取编辑区当前内容 */
  window.vdGetValue = vdGetValue;

  /** 切换编辑/预览/分屏三态：绑定 vditor 能力
   *  - 'edit'    → 编辑（编辑节点由 vdEditorNode 决定：ir 即时渲染 / wysiwyg 所见即所得），只显示编辑区
   *  - 'split'   → 分屏（SV 源码分屏：左源码右预览）
   *  - 'preview' → 预览（SV 纯预览，只展示整幅渲染结果）
   * 说明：不再调用 vditor setPreviewMode('editor')（它会把 sv 源码 textarea 置为 display:block，
   *       污染 IR/WYSIWYG 编辑态、残留挤压编辑区——修复切换页签/新开笔记编辑区变窄 Bug）。
   *       视图显隐统一由 applyVdVisibility 确定性接管。
   * @param {string} mode 'edit' | 'split' | 'preview'
   * author 火 冰 */
  window.vdSetMode = function (mode) {
    if (mode === 'preview') {
      // 纯预览 = SV 模式 + preview.mode=preview（整幅渲染，不含源码）
      vdMode = 'sv';
      vdPreview = 'preview';
      applyVdOrRebuild();
      return;
    }
    if (mode === 'split') {
      // 分屏 = SV 源码分屏：重建实例使源码/预览左右并排
      vdMode = 'sv';
      vdPreview = 'both';
      applyVdOrRebuild();
      return;
    }
    // 编辑：单选已由 vdSetEditorNode 写入 vdMode(ir/wysiwyg)；保证处于编辑节点且仅显示编辑区
    if (vdMode === 'sv') {
      // 从分屏/预览退回编辑：恢复上次编辑节点，需重建实例使编辑节点生效
      vdMode = vdEditorNode;
      vdPreview = 'editor';
      buildVditor();
      return;
    }
    // 非 SV 态（ir/wysiwyg 已就位）：仅需确定性隐藏源码/预览、显示当前编辑节点
    vdPreview = 'editor';
    applyVdVisibility();
  };

  /** 在 SV 源码分屏基础上直接切换到指定预览布局（both 源码+预览 / editor 仅源码 / preview 仅预览）。
   *  这是「分屏」按钮悬浮直选与「预览」按钮的统一入口，也承载分屏「点击循环」。
   *  - 已处于 SV 视图且实例就绪（currentMode==='sv'）：直接切换显隐，避免重建闪烁、保留内容
   *  - 否则重建实例（含从编辑态进入分屏）
   * @param {'both'|'editor'|'preview'} pm 预览布局
   * author 火 冰 */
  window.vdSetPreviewMode = function (pm) {
    if (['both', 'editor', 'preview'].indexOf(pm) === -1) pm = 'both';
    vdMode = 'sv';
    vdPreview = pm;
    applyVdOrRebuild();
  };

  /** 内部：已处于 SV 视图（vditor currentMode==='sv'）直接切显隐，否则重建实例进入 SV。
   * author 火 冰 */
  function applyVdOrRebuild() {
    if (vdInst && vdInst.vditor && vdInst.vditor.currentMode === 'sv') {
      applyVdVisibility();
      return;
    }
    buildVditor();
  }

  /** 选择编辑子节点（供「编辑」按钮冒泡子菜单调用）：即时渲染 / 所见即所得
   * @param {'ir'|'wysiwyg'} node 编辑节点类型 */
  window.vdSetEditorNode = function (node) {
    vdEditorNode = (node === 'wysiwyg') ? 'wysiwyg' : 'ir';
    // 非编辑态（预览/分屏）仅记录偏好，不改 vdMode（编辑态由 vdMode 承载实例节点）
    if (vdPreview === 'editor') {
      if (vdMode === vdEditorNode) return;
      vdMode = vdEditorNode;
      buildVditor();      // 重建以应用新编辑节点
    }
  };

  /** 读取当前编辑子节点偏好（供宿主展示「编辑 · 所见即所得 / 即时渲染」）
   * @returns {'ir'|'wysiwyg'} */
  window.vdGetEditorNode = function () { return vdEditorNode; };

  /** 切换源码/即时渲染（插件 mde-toggle-source 直接调用，翻转当前编辑节点模式） */
  window.vdToggleSource = function () {
    vdMode = vdMode === 'sv' ? 'ir' : 'sv';
    buildVditor();
  };

  /* ============================================================
   * 大纲浮层——能力与 UI 已迁入 markdown-editor 插件（MD-07 自研面板 sb-outline-*）。
   * 插件需取「当前可跳转的编辑内容源 DOM」来构建大纲树，但它依赖宿主闭包 vdMode/vdInst，
   * 插件沙箱无法访问，故宿主保留此最小数据访问桥 sbOutlineSource() 并暴露到 window。
   * 面板的树构建/定位/折叠/切换等 UI 逻辑全部由 markdown-editor 插件承担：按钮经
   * window.sbVdToolbarAdd 注入、高亮经 window.vdSetToolbarCurrent 同步、内容/全屏变化
   * 经宿主派发的 sbOutlineChange 事件触发刷新/重定位（见 sbOutlineNotify）。作者: 火 冰
   * ============================================================ */

  /** 取当前可跳转的编辑内容源（返回含标题节点的 DOM 元素，纯源码 textarea 返回 null）
   *  - IR / WYSIWYG：各自编辑节点
   *  - SV 分屏/预览：预览渲染面板（source 面板无标题 DOM）；纯 SV 源码 → null（等价禁用）
   * @returns {HTMLElement|null} */
  function sbOutlineSource() {
    const v = vdInst && vdInst.vditor;
    if (!v) return null;
    if (vdMode === 'sv') {
      if (v.preview && v.preview.element && v.preview.element.style.display !== 'none') {
        return v.preview.previewElement || v.preview.element;
      }
      return null;
    }
    if (vdMode === 'ir') return v.ir.element;
    if (vdMode === 'wysiwyg') return v.wysiwyg.element;
    return null;
  }
  window.sbOutlineSource = sbOutlineSource;

  /** 派生事件：编辑器内容/模式/可视区域变化时，通知插件大纲刷新或重定位（无插件时无害）。
   *  调用点：vditor input 回调、异步渲染 after、vdSyncValue/vdSetValue、宿主全屏切换。 */
  window.sbOutlineNotify = function () {
    try { window.dispatchEvent(new Event('sbOutlineChange')); } catch (_) { /* 忽略 */ }
  };

  /* ============================================================
   * sv 分屏源码行号 gutter（自绘，复用宿主旧 .ed-gutter 手法）。
   * vditor 的 options.lineNumber 只服务代码块（vditor-linenumber，见 preview.hljs.lineNumber）
   * 与 IR 高亮，并不在 sv 源码 <textarea> 侧渲染行号——故 sv 分屏的源码行号由宿主自绘。
   * 结构要点：sv 源码 textarea（v.sv.element）自身不滚动（vditor 用 paddingBottom 增高、
   * 由父滚动容器滚动，见 index.js 7102/12778），故行号列必须锚定在「滚动父容器」上并按
   * sc.scrollTop 平移（不能按 ta.scrollTop，其恒为 0）；同时用 textarea 的 paddingTop 让
   * 行号与首行文本对齐、paddingLeft 让出左缘。样式见 css/app.css .sb-sv-gutter。作者: 火 冰
   * ============================================================ */
  const SB_SV_GUTTER_ID = 'sb-sv-gutter';
  const vdSvGutter = { _deb: null };   // sv 源码行号列去抖 timer（大笔记每行强制 reflow 会卡死）

  /** 取 sv 源码 textarea（vditor.sv.element） */
  function vdSvTextarea() {
    return (vdInst && vdInst.vditor && vdInst.vditor.sv && vdInst.vditor.sv.element) || null;
  }

  /** 向上找最近的可渲染滚动父容器（overflowY auto/scroll 且确有滚动条），无则返回 null */
  function vdSvScroller(ta) {
    let n = ta && ta.parentElement;
    while (n) {
      const s = window.getComputedStyle(n);
      if ((/auto|scroll/.test(s.overflowY)) && n.scrollHeight > n.clientHeight) return n;
      n = n.parentElement;
    }
    return null;
  }

  /** 滚动/变更时按真实滚动偏移 translateY 平移行号列（避免重排）。
   *  说明：sv 源码 <textarea> 自身 overflow:auto（vditor index.css .vditor-sv），它是真实滚动器；
   *  行号列在外层绝对定位、无法放进 textarea 内，故需按实际 scrollTop 反向平移来贴合滚动后的行。
   *  只接受滚动偏移量，不再依赖某个具体容器，避免取到非滚动父容器的恒 0 值把位移重置。 */
  function vdSvGutterOnScroll(st) {
    const g = document.getElementById(SB_SV_GUTTER_ID);
    if (g && typeof st === 'number') g.style.transform = 'translateY(' + (-st) + 'px)';
  }

  /* 捕获式监听任意滚动：直接取实际滚动元素 e.target.scrollTop（textarea 或套在其上的滚动容器），
   * 仅当目标含 sv 源码 textarea 时才平移行号列（预览/大纲滚动不影响）。 */
  document.addEventListener('scroll', function (e) {
    const t = e.target;
    if (!t || t.nodeType !== 1) return;
    const g = document.getElementById(SB_SV_GUTTER_ID);
    const ta = vdSvTextarea();
    if (!g || !ta) return;
    if (t.contains(ta)) vdSvGutterOnScroll(t.scrollTop);
  }, true);

  /** 测量单个逻辑行在 sv 源码 textarea 相同断行规则下的实际可视行数（换行后的行数 = 像素高 ÷ 行高）。
   *  用隐藏测量元素复刻 textarea 的 white-space:pre-wrap + word-break:break-word 断行并实测高度，
   *  取代早期「canvas 像素宽 ÷ 可用宽向上取整」的估算法——后者只在 CJK 逐字换行下精确，西文按词换行
   *  会高估行数，在窄分屏/长西文行时行号逐行向下漂移（对不齐）。作者: 火 冰
   * @param {string} line 单个逻辑行文本（不含换行符）
   * @param {number} availW 可用文本宽度（px，= textarea 内容区宽）
   * @param {number} lh 行高（px）
   * @param {CSSStyleDeclaration} cs textarea 的计算样式（用于复刻断行/字距/字体）
   * @returns {number} 该行换行后的可视行数（≥1）
   * author huobing */
  function vdSvLineRows(line, availW, lh, cs) {
    let m = vdSvLineRows.hidden;
    if (!m) {
      m = document.createElement('div');
      m.style.position = 'absolute'; m.style.left = '-99999px'; m.style.top = '0';
      m.style.visibility = 'hidden';
      m.style.whiteSpace = 'pre-wrap';
      m.style.boxSizing = 'border-box'; m.style.padding = '0'; m.style.margin = '0'; m.style.border = '0';
      vdSvLineRows.hidden = m;
      document.body.appendChild(m);
    }
    // 逐项复刻 textarea 的换行/字距/字体相关属性，宽度 = 其内容区可用宽，使断行结果与 textarea 一致
    m.style.fontFamily = cs.fontFamily || 'monospace';
    m.style.fontSize = cs.fontSize || '16px';
    m.style.fontStyle = (cs.fontStyle && cs.fontStyle !== 'normal') ? cs.fontStyle : 'normal';
    m.style.lineHeight = lh + 'px';
    m.style.width = availW + 'px';
    m.style.wordBreak = cs.wordBreak || 'break-word';
    m.style.wordWrap = cs.wordWrap || 'break-word';
    m.style.overflowWrap = cs.overflowWrap || 'break-word';
    m.style.letterSpacing = cs.letterSpacing || 'normal';
    m.style.wordSpacing = cs.wordSpacing || 'normal';
    m.style.tabSize = cs.tabSize || '8';
    m.style.fontVariantLigatures = cs.fontVariantLigatures || 'no-common-ligatures';
    m.textContent = line;
    return Math.max(1, Math.round((m.scrollHeight || lh) / lh));
  }

  /** 重建 sv 源码行号列：仅 vdMode==='sv' 且实例就绪时生效，否则移除 gutter 并还原内边距。
   *  每个数字 div 高度 = 该逻辑行换行后的实际像素高度，gutter 总高随内容增高（通栏到底），
   *  配合 translateY 平移即与文本逐行对齐、滚动到哪显示到哪。 */
  function vdSvGutterRefresh() {
    const ta = vdSvTextarea();
    let g = document.getElementById(SB_SV_GUTTER_ID);
    // 隐藏条件：sv 源码 textarea 不可见（如纯预览 vdPreview='preview' 下 sv 被 display:none）或
    // 非 sv 模式 / 实例未就绪时，一律移除 gutter 并还原内边距，避免行号列残留渲染到预览布局。
    const svHidden = !ta || !document.getElementById('ed-vditor') || vdMode !== 'sv' ||
      window.getComputedStyle(ta).display === 'none';
    if (svHidden) {
      if (g && g.parentNode) g.parentNode.removeChild(g);
      if (ta) ta.style.paddingLeft = '';
      return;
    }
    if (!g) {
      const sc = vdSvScroller(ta) || ta.parentElement;
      if (!sc) return;
      if (sc.style.position !== 'relative' && sc.style.position !== 'absolute' && sc.style.position !== 'fixed') {
        sc.style.position = 'relative';   // 行号列 absolute 锚到含 textarea 的定位容器
      }
      g = document.createElement('div');
      g.id = SB_SV_GUTTER_ID;
      g.className = 'sb-sv-gutter';   // 命中 css/app.css 的 #ed-vditor .sb-sv-gutter（仅设 id 匹配不到 class 选择器，样式全丢：无背景/无宽度/未绝对定位而落到文档流顶，行号跑到 textarea 外面）
      sc.insertBefore(g, sc.firstChild);
      window.addEventListener('resize', function () { vdSvGutterRefresh(); });   // 宽度变化影响换行，重建行高
    }
    const cs = window.getComputedStyle(ta);
    const lh = parseFloat(cs.lineHeight) || (parseFloat(cs.fontSize) || 16) * 1.4;   // 行高（px）
    const pt = parseFloat(cs.paddingTop) || 0;                                       // 对齐首行文本
    // 文本换行可用宽度 = textarea 内容区（clientWidth 为 padding-box 宽，扣除左右内边距）
    const availW = Math.max(0, ta.clientWidth - (parseFloat(cs.paddingLeft) || 0) - (parseFloat(cs.paddingRight) || 0));
    const lines = (ta.value || '').split('\n');
    const key = lh.toFixed(2) + '|' + pt.toFixed(1) + '|' + availW.toFixed(1) + '|' + lines.length;
    if (g.__key === key) { vdSvGutterOnScroll(ta.scrollTop); return; }   // 行数/宽度/行高未变则仅对齐，避免每键重建
    g.__key = key;
    g.style.setProperty('--gutter-lh', lh.toFixed(2) + 'px');
    g.style.paddingTop = pt + 'px';
    const frag = document.createDocumentFragment();
    for (let i = 0; i < lines.length; i++) {
      const d = document.createElement('div');
      d.textContent = String(i + 1);
      const rows = vdSvLineRows(lines[i], availW, lh, cs);   // 按 textarea 真实断行测量该行换行后的行数（对不齐根因修复）
      d.style.height = (rows * lh).toFixed(2) + 'px';   // 换行后的真实行高，使各行号与文本逐行对齐、gutter 总高通栏到底
      frag.appendChild(d);
    }
    g.innerHTML = '';
    g.appendChild(frag);
    vdSvGutterOnScroll(ta.scrollTop);
    ta.style.paddingLeft = '40px';   // 给行号列让位（约 4 位数字宽 + 间隙，与 .sb-sv-gutter 宽度配套）
  }
  window.vdSvGutterRefresh = vdSvGutterRefresh;

  /* ============================================================
   * 代码块行号（宿主自绘 .sb-code-gutter）：覆盖 IR 渲染态 / 预览 / 阅读。
   * 不开 vditor 内置行号（Bug-065 判定其 rows 与 code 内边距/字号错位不可修），
   * 与 sv 源码行号同用 vdSvLineRows 实测断行，逐行对齐有保证。
   * 设置键用新键 'codeLineNumbers'（默认开）：旧键 'lineNumbers' 是旧源码行号按钮的历史语义，
   * 用户机器可能残留 false 值，新功能沿用会继承旧值导致默认不显示，故分键。
   * IR 源码编辑态 / WYSIWYG 源码态 / 图表块排除。
   * 作者: 火 冰
   * ============================================================ */
  const SB_CODE_LN_SKIP = ['mermaid', 'echarts', 'math', 'abc', 'plantuml', 'graphviz', 'flowchart', 'mindmap', 'katex', 'smiles'];
  let vdCodeLnObs = null;        // MutationObserver 单例（重建实例时先 disconnect 再重挂，防泄漏）
  let vdCodeLnScheduled = false; // rAF 合并标志：同一帧内多次触发只扫一次

  /** 行号开关是否生效：惰性读持久化设置，默认开 */
  function vdCodeLnOn() {
    try { return !!(typeof restoreS === 'function' ? restoreS('codeLineNumbers', true) : true); }
    catch (_) { return true; }
  }

  /** 代码块内容换行开关：惰性读持久化设置，默认关（保持代码原始格式、横向滚动）
   *  开启后 pre 加 sb-code-wrap class，由 CSS 覆盖 white-space 为 pre-wrap。
   *  author 火 冰 */
  function vdCodeWrapOn() {
    try { return !!(typeof restoreS === 'function' ? restoreS('codeWrap', false) : false); }
    catch (_) { return false; }
  }

  /** 同步工具栏自定义按钮（行号/换行）的激活态高亮
   *  vditor 自定义按钮走 DOM 渲染，vditor 自身不管激活态；
   *  这里按当前全局设置给按钮加/移除 is-on class（蓝色高亮）。
   *  被 after 回调首次调用 + 工具栏按钮 click 后立即调用。
   *  author 火 冰 */
  function vdToolbarRefreshStates() {
    const root = document.getElementById('ed-vditor');
    if (!root) return;
    const lnBtn = root.querySelector('.vditor-toolbar [data-name="sb-code-ln"], .vditor-toolbar button.sb-code-ln');
    const wrapBtn = root.querySelector('.vditor-toolbar [data-name="sb-code-wrap"], .vditor-toolbar button.sb-code-wrap');
    // vditor 自定义按钮可能用 data-name 或 button.title，双选择器兜底
    const allBtns = root.querySelectorAll('.vditor-toolbar button');
    allBtns.forEach(function (btn) {
      if (btn.title && btn.title.indexOf('行号') !== -1) btn.classList.toggle('is-on', vdCodeLnOn());
      if (btn.title && btn.title.indexOf('换行') !== -1) btn.classList.toggle('is-on', vdCodeWrapOn());
    });
  }

  /** 判定一个 pre 是否为「可注入行号的渲染态代码块」。
   * @param {Element} pre 待判定的 pre 元素
   * @returns {Element|null} 可注入时返回其 code 元素，否则 null */
  function vdCodeLnMatch(pre) {
    if (!pre || pre.tagName !== 'PRE' || pre.offsetParent === null) return null;   // 隐藏 pane（如仅源码布局的预览侧）跳过，防 0 宽测量畸形
    const cls = (typeof pre.className === 'string') ? pre.className : '';          // CD-45：className 判型后再用
    if (/\bvditor-ir__marker--pre\b/.test(cls) || /\bvditor-wysiwyg__pre\b/.test(cls)) return null;   // 源码编辑态不带行号
    const code = pre.querySelector('code');
    if (!code) return null;
    /* 渲染态判据：vditor 高亮渲染必给 code 加 hljs class（dist index.js L3202，未知语言回落 plaintext 也加），
     * 而各编辑态（IR fence 编辑态 / IR 激活编辑态 pre.vditor-reset / WYSIWYG 源码态）一律无 hljs。
     * 行号只挂在已高亮渲染的块上，以此兜底所有编辑态形态。 */
    if (!/\bhljs\b/.test((typeof code.className === 'string') ? code.className : '')) return null;
    const m = /language-([\w-]+)/.exec((typeof code.className === 'string') ? code.className : '');
    if (m && SB_CODE_LN_SKIP.indexOf(m[1]) !== -1) return null;                    // 图表/公式块（会被替换渲染）
    return code;
  }

  /** 取 pre 下已注入的行号列（children 遍历，兼容无 :scope 支持的环境） */
  function vdCodeLnGutterOf(pre) {
    for (let i = 0; i < pre.children.length; i++) {
      const c = pre.children[i];
      if (c.classList && c.classList.contains('sb-code-gutter')) return c;
    }
    return null;
  }

  /** 单块注入/更新：先让位（paddingLeft）再测量，保证 availW 为注入态真实宽；三元组去重未变跳过。
   *  gutter 挂在 pre 下、code 外：highlightRender 重写 code.innerHTML 不伤行号列。
   *  行高计算规则：
   *    - 默认（white-space: pre，不换行）：每行 height = 1 * lh，横向滚动超长行 = 1 行高
   *    - 开启换行（pre.sb-code-wrap → white-space: pre-wrap）：用 vdSvLineRows 计算折行后多行高
   *  author 火 冰 */
  function vdCodeLnInject(pre, code) {
    if (pre.style.position === '') pre.style.position = 'relative';
    pre.style.paddingLeft = '36px';                          // 先占位让出左缘，clientWidth 随之收缩（再测量）
    const cs = window.getComputedStyle(code);
    const lh = parseFloat(cs.lineHeight) || (parseFloat(cs.fontSize) || 16) * 1.4;
    const availW = Math.max(0, code.clientWidth - (parseFloat(cs.paddingLeft) || 0) - (parseFloat(cs.paddingRight) || 0));
    const text = code.textContent || '';
    const wrapOn = vdCodeWrapOn();                            // 当前是否开启代码块换行
    const old = vdCodeLnGutterOf(pre);
    // 去重签名追加 wrapOn：换行开关切换后必须重建行号 height
    const sig = text + '|' + availW.toFixed(1) + '|' + lh.toFixed(2) + '|' + (wrapOn ? 'w' : 'n');
    if (old && old.__lnSig === sig) return;                    // 文本/宽度/行高/换行模式未变不重建
    if (old && old.parentNode) old.parentNode.removeChild(old);
    const g = document.createElement('div');
    g.className = 'sb-code-gutter';
    g.__lnSig = sig;
    g.style.top = (code.offsetTop + (parseFloat(cs.paddingTop) || 0)) + 'px';   // 与首行文本对齐
    const frag = document.createDocumentFragment();
    const lines = text.replace(/\n$/, '').split('\n');
    for (let i = 0; i < lines.length; i++) {
      const d = document.createElement('div');
      d.textContent = String(i + 1);
      if (wrapOn) {
        // 换行模式：pre-wrap + break-word，按折行后多行计算 height
        const rows = vdSvLineRows(lines[i], availW, lh, cs);
        d.style.height = (rows * lh).toFixed(2) + 'px';
      } else {
        // 默认模式：white-space: pre 不换行，超长行横向滚动，行高固定单行
        d.style.height = lh.toFixed(2) + 'px';
      }
      frag.appendChild(d);
    }
    g.appendChild(frag);
    pre.appendChild(g);
  }

  /** 关闭态/反向拆除：移除 gutter 并还原 pre 内边距（CSS 类无法还原 JS 内联 padding，故整块拆除） */
  function vdCodeLnTeardown(root) {
    if (!root || !root.querySelectorAll) return;
    root.querySelectorAll('pre > .sb-code-gutter').forEach(g => {
      const pre = g.parentNode;
      if (g.parentNode) g.parentNode.removeChild(g);
      if (pre) pre.style.paddingLeft = '';
    });
  }

  /** 扫描入口：开=逐块注入/更新，关=全量拆除（幂等，可重复调用）。
   *  同时同步 sb-code-wrap class（codeWrap 设置）：开启换行时给 pre 加 class，关闭移除。 */
  function vdCodeLnScan(root) {
    if (!root || !root.querySelectorAll) return;
    const wrapOn = vdCodeWrapOn();   // 全局换行设置（每个代码块统一应用）
    if (!vdCodeLnOn()) { vdCodeLnTeardown(root); }   // 行号关闭时全量拆除 gutter（保留 wrap class）
    root.querySelectorAll('pre').forEach(pre => {
      const code = vdCodeLnMatch(pre);
      // 代码块换行：无论行号开/关都同步 wrap class（设置面板独立控制）
      if (code) pre.classList.toggle('sb-code-wrap', wrapOn);
      if (code && vdCodeLnOn()) vdCodeLnInject(pre, code);
      else if (code === null) {                                                 // 曾注入后转为编辑态/图表块 → 还原
        const g = vdCodeLnGutterOf(pre);
        if (g) { if (g.parentNode) g.parentNode.removeChild(g); pre.style.paddingLeft = ''; }
        pre.classList.remove('sb-code-wrap');   // 非渲染态代码块移除 wrap class
      }
    });
  }

  /** rAF 合并调度：同一帧内多次触发（observer/回调/resize）只扫一次。
   *  大文件优化：md > 50KB 或 DOM > 2000 节点时，改为 requestIdleCallback 延迟执行，
   *  让浏览器先处理输入渲染，空闲时再做代码块行号扫描（包含 scrollHeight 强制 reflow）。
   *  @author 火 冰 */
  function vdCodeLnSchedule() {
    if (vdCodeLnScheduled) return;
    vdCodeLnScheduled = true;
    const run = function () {
      vdCodeLnScheduled = false;
      const _t0 = performance.now();
      vdCodeLnScan(document.getElementById('ed-vditor'));
      const _d = performance.now() - _t0;
      if (_d > 3 && window.__sbDebugPerf) {
        console.warn('[PERF][codeLnScan] ms=' + _d.toFixed(1) + 'ms large=' + sbIsLargeContent().toString());
      }
    };
    if (sbIsLargeContent()) {
      sbRunWhenIdle(run, 2000);   // 大文件：空闲时扫，超时 2s 防饿死
    } else if (typeof window.requestAnimationFrame === 'function') {
      window.requestAnimationFrame(run);   // 小文件：一帧内响应
    } else {
      setTimeout(run, 0);
    }
  }

  /** 挂/重挂观察器到当前实例根：childList（代码块渲染/重建）+ attributes（class=IR 编辑态切换、
   *  style=applyVdVisibility 切 pane display）。回调只 schedule，扫描在 rAF 中统一做。 */
  function vdCodeLnEnsureObserver() {
    const rootEl = (vdInst && vdInst.vditor && vdInst.vditor.element) || document.getElementById('ed-vditor');
    if (!rootEl) return;
    if (vdCodeLnObs) vdCodeLnObs.disconnect();
    vdCodeLnObs = new MutationObserver(function () {
      if (!rootEl.isConnected) return;                       // 脱离文档（CD-02/CD-54）不再处理
      vdCodeLnSchedule();
    });
    vdCodeLnObs.observe(rootEl, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'style'] });
    vdCodeLnSchedule();
  }

  /* 开关切换副作用入口（设置页调用）：关=立即全量拆除，开=重扫注入 */
  window.vdCodeGutterSetEnabled = function (on) {
    const rootEl = document.getElementById('ed-vditor');
    if (!on && rootEl) vdCodeLnTeardown(rootEl);
    vdCodeLnSchedule();
  };

  /* 代码块换行开关切换副作用入口（设置页调用）：切换后重扫所有代码块的 wrap class
   *  author 火 冰 */
  window.vdCodeWrapSetEnabled = function (on) {
    vdCodeLnSchedule();   // 扫描时 vdCodeWrapOn() 会读取最新值并应用
  };

  /* 测试/调试钩子（仿 __sbProjFence 惯例）：扫描核心纯 DOM 可测 */
  window.vdCodeGutterScan = vdCodeLnScan;

  if (!(navigator && /jsdom/i.test(navigator.userAgent))) {
    window.addEventListener('resize', vdCodeLnSchedule);     // 宽度变化 → availW 变化 → 去重键失效重建
  }

  /** 销毁实例（切库/卸载编辑器时释放资源） */
  window.vdDestroy = function () {
    if (vdCodeLnObs) { vdCodeLnObs.disconnect(); vdCodeLnObs = null; }   // 同步拆代码块行号观察器，防跨实例泄漏
    if (vdInst) { try { vdInst.destroy(); } catch (_) { /* 忽略 */ } }
    vdInst = null;
  };

  /* 关键修复：插件异步加载时序竞态
   *
   * 问题：目录插件 markdown-editor 的 main.js 在异步 loadDirPlugins 中加载完成后，
   * 会通过 window.sbVdToolbarAdd 把「宽屏 / 表格列宽 / 大纲」三个按钮注入到
   * window.__sbVdToolbarInjects 队列。但如果 buildVditor 在此之前就被执行过（启动时
   * initEditor → openNote → renderArticle → ensureVd → buildVditor），vditor 实例
   * 创建时读到的注入队列还是空的，三个按钮就丢失了，且 vditor toolbar 创建后不会
   * 自动再读队列。用户切预览/编辑节点模式时触发 ir↔sv 重建，此时插件已加载完，按钮
   * 就出现了——这就是「切换预览就出来」的根因。
   *
   * 修复：暴露 window.vdRebuild，供 loadDirPlugins 全部加载完后调用。如果 vditor
   * 实例已存在（说明首次 buildVditor 已经跑过但插件按钮还没注入），主动销毁并重建
   * 一次，让 toolbar 从完整注入队列构建，三个按钮立即出现。
   *
   * 作者: 火 冰 */
  window.vdRebuild = function () {
    if (!vdInst) return;   // 还没创建过实例，无需重建（下次 buildVditor 自然会读到完整注入队列）
    const mode = vdMode;
    const preview = vdPreview;
    // 保留当前内容（buildVditor 内部 safeGetValue 会在销毁前取值，这里只是保底）
    const cur = safeGetValue();
    if (cur != null) vdBuffer = cur;
    // 销毁旧实例并重建
    vdDestroy();
    buildVditor();
    // 还原模式（buildVditor 默认按 vdMode/vdPreview 构建，这里保险一下）
    if (vdMode !== mode || vdPreview !== preview) {
      setVdMode(mode);
      vdPreview = preview;
      applyVdVisibility();
    }
    // 同步高亮插件按钮状态（宽屏/列宽）
    if (typeof window.mdeRestoreWide === 'function') window.mdeRestoreWide();
    if (typeof window.mdeRestoreTableAuto === 'function') window.mdeRestoreTableAuto();
  };

  /* ---------- 宿主自接管全屏（舍弃 vditor 内置 fullscreen，其还原在宿主下不可靠） ---------- */

  /** 是否处于宿主全屏态 */
  let vdHf = false;

  /** 切换宿主全屏：给 body 加 ed-fs-active（隐藏外围 UI，编辑区独占撑满）。
   *  说明: 不再依赖 fixed 铺满（transform 包裹元素会劫持 containing block 导致铺不满视口），
   *      改为隐藏左文件树/右面板/顶栏/状态栏后由编辑区 flex 占满。
   *      退出靠 Esc 或再次点击 vditor 工具栏「全屏」按钮（不再弹右上角浮动退出键，见 ED-55）。
   *      作者: 火 冰 */
  function vdHostFullscreen(on) {
    vdHf = on;
    document.body.classList.toggle('ed-fs-active', on);
    document.documentElement.classList.toggle('ed-fs-active', on);
    // 全屏/退出后 #ed-vditor 可视区域变化：通知插件大纲重定位到新的编辑区右上角
    window.sbOutlineNotify();
  }

  /** 面板上「全屏」按钮入口：切换宿主全屏 */
  window.vdToggleFullscreen = function () {
    vdHostFullscreen(!vdHf);
  };

  /** 设置 vditor 工具栏指定自定义按钮的高亮态（menu--current 品牌色）。
   *  由 markdown-editor 插件在宽屏/列宽状态变化时调用，同步其迁入工具栏的按钮高亮。
   * @param {string} name  按钮 name（VDTOOLBAR 自定义项 name，如 sb-wide / sb-table-layout）
   * @param {boolean} on   是否高亮 */
  window.vdSetToolbarCurrent = function (name, on) {
    const inst = vdInst;
    if (!(inst && inst.vditor && inst.vditor.toolbar && inst.vditor.toolbar.elements)) return;
    const btn = inst.vditor.toolbar.elements[name];
    const el = btn && btn.firstElementChild;
    if (!el) return;
    el.classList.toggle('vditor-menu--current', !!on);
  };

  /** Esc 退出生效的全屏 */
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && vdHf) vdHostFullscreen(false);
  });

  /* ============================================================
   * 查找/替换（Ctrl+F 查找，Ctrl+R 替换）
   * vditor 4.0 无内置查找条，宿主旧实现也已随 #ed-edit textarea 退役失效。
   * 本模块基于 vditor 三种编辑模式的可编辑元素统一实现：
   *   - sv（分屏源码）：vdInst.vditor.sv.element 为 <textarea>，按 value 匹配 + setSelectionRange 跳转；
   *   - ir / wysiwyg（富文本）：对应 .ir.element / .wysiwyg.element 为 contenteditable，
   *     用 TreeWalker 遍历文本节点拼接全文，把全局偏移映射回 Range 选区跳转。
   * UI 复用 app.css 的 .ed-findbar/.show-replace，DOM 位于 #ed-vditor 之外（随编辑区顶部显示），
   * 因此不受 vditor destroy/rebuild 清空影响。宿主通过 window.vdFindbar 薄转发调用。
   * 作者: 火 冰
   * ============================================================ */

  /** @type {string} 当前查找关键词 */
  let vdFindQ = '';
  /** @type {Array<{start:number,end:number}>} 当前匹配的全局偏移列表 */
  let vdFindMatches = [];
  /** @type {number} 当前高亮匹配索引（0 起） */
  let vdFindIdx = -1;
  /** @type {boolean} 查找/替换条是否打开（宿主 app-layout.js Escape 依赖同名逻辑） */
  let vdFindOpen = false;

  /* 查找/替换历史：各自持久化（restoreS/saveS），供输入框 <datalist> 下拉回填 */
  const SB_FIND_HIST_KEY = 'sbFindHist';
  const SB_REPLACE_HIST_KEY = 'sbReplaceHist';
  const SB_HIST_MAX = 10;

  /** 读取某类历史记录（字符串数组）。作者: 火 冰
   * @param {string} key 记忆键（SB_FIND_HIST_KEY / SB_REPLACE_HIST_KEY）
   * @returns {string[]} 历史列表，无则空数组 */
  function vdHistGet(key) {
    try {
      const arr = (typeof restoreS === 'function') ? restoreS(key, null) : null;
      return Array.isArray(arr) ? arr : [];
    } catch (_) { return []; }
  }

  /** 把一次输入记入历史：去重置顶，限 SB_HIST_MAX 条，写盘并刷新下拉。
   * @param {string} key 记忆键
   * @param {string} val 输入值（空串不记）
   * @author 火 冰 */
  function vdHistRecord(key, val) {
    if (!val) return;
    try {
      let arr = vdHistGet(key).filter(function (x) { return x !== val; });
      arr.unshift(val);
      if (arr.length > SB_HIST_MAX) arr.length = SB_HIST_MAX;
      if (typeof saveS === 'function') saveS(key, arr);
      vdHistRender(key, arr);
    } catch (_) { /* 忽略 */ }
  }

  /** 把历史渲染进对应 <datalist>，使输入框聚焦即可下拉选择。
   * @param {string} key 记忆键
   * @param {string[]} [arr] 历史列表，省略则自读
   * @author 火 冰 */
  function vdHistRender(key, arr) {
    const listId = (key === SB_FIND_HIST_KEY) ? 'sb-find-history' : 'sb-replace-history';
    const dl = document.getElementById(listId);
    if (!dl) return;
    arr = arr || vdHistGet(key);
    dl.textContent = '';
    arr.forEach(function (v) { const o = document.createElement('option'); o.value = v; dl.appendChild(o); });
  }

  /** 正则特殊字符转义（editor-core.js 的 escapeReg 为本 IIFE 私有，此处自建）
   * @param {string} s 原始字符串
   * @returns {string} 正则安全字符串
   * @author 火 冰 */
  function vdFindEscape(s) {
    return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  /** 取当前编辑元素的文本快照：sv 用 textarea.value；ir/wysiwyg 用 TreeWalker 拼接文本节点。
   *  返回 { type:'sv'|'rich', text, el, seg }，seg 为 [{node,start,len}] 供全局偏移→DOM 映射。
   * @returns {{type:string,text:string,el:Element,seg:Array}|null} 快照，无实例返回 null
   * @author 火 冰 */
  function vdTextSnapshot() {
    if (!vdInst || !vdInst.vditor) return null;
    if (vdMode === 'sv') {
      const ta = vdInst.vditor.sv && vdInst.vditor.sv.element;
      if (!ta) return null;
      return { type: 'sv', text: ta.value || '', el: ta, seg: null };
    }
    const el = (vdMode === 'ir')
      ? (vdInst.vditor.ir && vdInst.vditor.ir.element)
      : (vdInst.vditor.wysiwyg && vdInst.vditor.wysiwyg.element);
    if (!el) return null;
    const seg = [];
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null);
    let acc = 0, n;
    while ((n = walker.nextNode())) {
      const t = n.nodeValue || '';
      seg.push({ node: n, start: acc, len: t.length });
      acc += t.length;
    }
    return { type: 'rich', text: el.textContent || '', el, seg };
  }

  /** 估算当前光标的「全文全局偏移」，用于打开查找时定位到光标之后的第一个匹配。
   * @param {Object} snap vdTextSnapshot 结果
   * @returns {number} 全局偏移，无法确定返回 -1
   * @author 火 冰 */
  function vdGlobalCaret(snap) {
    if (!snap) return -1;
    if (snap.type === 'sv') return (snap.el.selectionStart != null) ? snap.el.selectionStart : -1;
    const sel = window.getSelection ? window.getSelection() : null;
    if (!sel || sel.rangeCount === 0 || !sel.anchorNode) return -1;
    for (let i = 0; i < snap.seg.length; i++) {
      if (snap.seg[i].node === sel.anchorNode) return snap.seg[i].start + (sel.anchorOffset || 0);
    }
    return -1;
  }

  /** 把全局偏移 [start,end) 映射为编辑元素选区选中（sv→setSelectionRange，rich→Range）。
   * @param {Object} snap   vdTextSnapshot 结果
   * @param {number} start  全局起始偏移
   * @param {number} end    全局结束偏移
   * @author 火 冰 */
  function vdSelectRange(snap, start, end) {
    if (!snap) return;
    if (snap.type === 'sv') {
      const ta = snap.el;
      try { ta.setSelectionRange(start, end); } catch (_) { /* 忽略 */ }
      return;
    }
    if (!snap.seg.length) return;
    let i = 0;
    while (i < snap.seg.length && snap.seg[i].start + snap.seg[i].len <= start) i++;
    if (i >= snap.seg.length) i = snap.seg.length - 1;
    const sg = snap.seg[i];
    const offS = Math.max(0, start - sg.start);
    const offE = Math.min(sg.len, end - sg.start);
    const sel = window.getSelection ? window.getSelection() : null;
    if (!sel) return;
    const range = document.createRange ? document.createRange() : null;
    if (!range) return;
    try {
      range.setStart(sg.node, offS);
      range.setEnd(sg.node, offE);
      sel.removeAllRanges();
      sel.addRange(range);
    } catch (_) { /* 忽略边界异常 */ }
  }

  /** 把全局偏移映射为一个 Range（富文本，支持起点终点落在不同文本节点）。
   * @param {Object} snap   vdTextSnapshot 结果
   * @param {number} start  全局起始偏移
   * @param {number} end    全局结束偏移
   * @returns {Range|null} Range，非富文本或越界返回 null
   * @author 火 冰 */
  function vdBytesToRange(snap, start, end) {
    if (!snap || snap.type !== 'rich' || !snap.seg.length) return null;
    const seg = snap.seg;
    let a = 0; while (a < seg.length - 1 && seg[a].start + seg[a].len <= start) a++;
    let b = 0; while (b < seg.length - 1 && seg[b].start + seg[b].len <= end) b++;
    try {
      const rg = document.createRange();
      rg.setStart(seg[a].node, Math.max(0, Math.min(seg[a].len, start - seg[a].start)));
      rg.setEnd(seg[b].node, Math.max(0, Math.min(seg[b].len, end - seg[b].start)));
      return rg;
    } catch (_) { return null; }
  }

  /** 清除匹配临时变色（CSS Custom Highlight）。作者: 火 冰 */
  function vdClearHighlight() {
    try {
      if (typeof CSS !== 'undefined' && CSS.highlights) {
        CSS.highlights.delete('sb-find');
        CSS.highlights.delete('sb-find-current');
      }
    } catch (_) { /* 忽略 */ }
  }

  /** 应用匹配临时变色（富文本）：全集用 sb-find，当前项用 sb-find-current 叠加亮色。
   *  不破坏编辑区 DOM，因此不会打断输入框焦点。作者: 火 冰
   * @param {Object} snap 快照
   * @param {number} cur  当前匹配索引 */
  function vdApplyHighlight(snap, cur) {
    if (!snap || snap.type !== 'rich' || typeof Highlight === 'undefined') return;
    if (typeof CSS === 'undefined' || !CSS.highlights) return;
    const all = [];
    let curRg = null;
    for (let i = 0; i < vdFindMatches.length; i++) {
      const rg = vdBytesToRange(snap, vdFindMatches[i].start, vdFindMatches[i].end);
      if (!rg) continue;
      if (i === cur) curRg = rg;
      all.push(rg);
    }
    try {
      if (all.length) CSS.highlights.set('sb-find', new Highlight(...all));
      if (curRg) CSS.highlights.set('sb-find-current', new Highlight(curRg));
    } catch (_) { /* 忽略 */ }
  }

  /** 把当前匹配处滚动到可视区顶部（sv 用行偏移 + 高度-可视高裁剪；富文本 scrollIntoView(start)）。
   * @param {Object} snap        快照
   * @param {number} startOffset 当前匹配的全局起始偏移
   * @author 火 冰 */
  function vdScrollCurrentTop(snap, startOffset) {
    if (!snap) return;
    if (snap.type === 'sv') {
      const ta = snap.el;
      const lh = Number((window.getComputedStyle && window.getComputedStyle(ta).lineHeight) || '') || 20;
      const lineCount = snap.text.slice(0, startOffset).split('\n').length;
      const sc = document.getElementById('ed-split') || ta;
      const top = Math.max(0, (lineCount - 1) * lh);
      const maxTop = Math.max(0, (ta.scrollHeight || 0) - (sc.clientHeight || 0));
      sc.scrollTop = Math.min(top, maxTop);
      return;
    }
    const rg = vdBytesToRange(snap, startOffset, startOffset + Math.max(1, vdFindQ.length));
    if (!rg) return;
    const el = (rg.startContainer.nodeType === 3) ? rg.startContainer.parentElement : rg.startContainer;
    if (el && el.scrollIntoView) el.scrollIntoView({ block: 'start', inline: 'nearest' });
  }

  /** 更新/执行查找：按当前输入框关键词在编辑元素全文匹配。
   *  结果以临时变色高亮、当前项定位到可视区顶部；不改变输入框焦点。
   *  计数与跳转基准统一为「当前编辑元素可见文本」。作者: 火 冰 */
  function vdRunFind() {
    const inp = document.getElementById('vd-find-input');
    const count = document.getElementById('vd-find-count');
    const q = inp ? (inp.value || '') : '';
    vdFindQ = q;
    vdFindMatches = [];
    vdFindIdx = -1;
    if (q) vdHistRecord(SB_FIND_HIST_KEY, q);
    const snap = vdTextSnapshot();
    vdClearHighlight();
    if (!snap || !q) { if (count) count.textContent = '0 / 0'; return; }
    const re = new RegExp(vdFindEscape(q), 'gi');
    let m;
    while ((m = re.exec(snap.text)) !== null) {
      vdFindMatches.push({ start: m.index, end: m.index + m[0].length });
      if (m[0].length === 0) re.lastIndex++;   // 防空匹配死循环
    }
    if (!vdFindMatches.length) { if (count) count.textContent = '0 / 0'; return; }
    // 当前项：优先定位光标之后，无可定位置则取第一个
    const caret = vdGlobalCaret(snap);
    let cur = 0;
    if (caret >= 0) {
      for (let i = 0; i < vdFindMatches.length; i++) {
        if (vdFindMatches[i].start >= caret) { cur = i; break; }
      }
    }
    vdFindIdx = cur;
    vdApplyHighlight(snap, cur);
    // sv 模式无法 CSS 高亮，退化为选中当前匹配（不抢焦点）
    if (snap.type === 'sv') vdSelectRange(snap, vdFindMatches[cur].start, vdFindMatches[cur].end);
    vdScrollCurrentTop(snap, vdFindMatches[cur].start);
    if (count) count.textContent = (cur + 1) + ' / ' + vdFindMatches.length;
  }

  /** 导航到上一个/下一个匹配（dir=-1 上，+1 下）。保持输入框焦点、更新高亮与计数。
   * @param {number} dir 方向 */
  function vdFindNav(dir) {
    if (!vdFindMatches.length) return;
    vdFindIdx = (vdFindIdx + dir + vdFindMatches.length) % vdFindMatches.length;
    const snap = vdTextSnapshot();
    if (snap) {
      if (snap.type === 'sv') vdSelectRange(snap, vdFindMatches[vdFindIdx].start, vdFindMatches[vdFindIdx].end);
      vdApplyHighlight(snap, vdFindIdx);
      vdScrollCurrentTop(snap, vdFindMatches[vdFindIdx].start);
    }
    const count = document.getElementById('vd-find-count');
    if (count) count.textContent = (vdFindIdx + 1) + ' / ' + vdFindMatches.length;
    const inp = document.getElementById('vd-find-input');
    if (inp) { try { inp.focus(); } catch (_) { /* 忽略 */ } }
  }

  /** 替换当前高亮匹配为「替换为」输入框内容。
   *  sv 用 textarea setSelectionRange + execCommand；rich 用 Range 选区 + execCommand（触发 input 回传宿主）。
   *  @author 火 冰 */
  function vdDoReplace() {
    const rInp = document.getElementById('vd-replace-input');
    const r = rInp ? (rInp.value || '') : '';
    if (!vdFindQ || vdFindIdx < 0 || !vdFindMatches.length) return;
    if (r) vdHistRecord(SB_REPLACE_HIST_KEY, r);
    const snap = vdTextSnapshot();
    if (!snap) return;
    const mm = vdFindMatches[vdFindIdx];
    try {
      if (snap.type === 'sv') {
        const ta = snap.el;
        ta.focus();
        ta.setSelectionRange(mm.start, mm.end);
        if (document.execCommand) document.execCommand('insertText', false, r);
      } else {
        vdSelectRange(snap, mm.start, mm.end);
        const sel = window.getSelection ? window.getSelection() : null;
        if (sel && sel.rangeCount && document.execCommand) document.execCommand('insertText', false, r);
      }
    } catch (_) { /* 忽略替换异常 */ }
    try { sync2Host(vdGetValue()); } catch (_) { /* 忽略同步异常 */ }
    vdRunFind();
  }

  /** 替换全部匹配（sv 从后往前 setSelectionRange+execCommand；rich 从后往前迭代替换）。
   *  @author 火 冰 */
  function vdDoReplaceAll() {
    const rInp = document.getElementById('vd-replace-input');
    const r = rInp ? (rInp.value || '') : '';
    if (!vdFindQ) return;
    if (r) vdHistRecord(SB_REPLACE_HIST_KEY, r);
    const snap = vdTextSnapshot();
    if (!snap) return;
    try {
      if (snap.type === 'sv') {
        const ta = snap.el;
        const re = new RegExp(vdFindEscape(vdFindQ), 'gi');
        const ms = [];
        let m;
        while ((m = re.exec(ta.value)) !== null) { ms.push({ s: m.index, e: m.index + m[0].length }); }
        for (let k = ms.length - 1; k >= 0; k--) {
          ta.setSelectionRange(ms[k].s, ms[k].e);
          if (document.execCommand) document.execCommand('insertText', false, r);
        }
      } else {
        // 富文本：从最后一个匹配向前迭代，每步重新快照以对抗 execCommand 引发的节点变化
        let guard = 0;
        while (guard++ < 5000) {
          const s = vdTextSnapshot();
          if (!s) break;
          const re = new RegExp(vdFindEscape(vdFindQ), 'gi');
          let last = null, m;
          while ((m = re.exec(s.text)) !== null) last = { s: m.index, e: m.index + m[0].length };
          if (!last) break;
          vdSelectRange(s, last.s, last.e);
          const sel = window.getSelection ? window.getSelection() : null;
          if (!sel || !sel.rangeCount || !document.execCommand) break;
          document.execCommand('insertText', false, r);
        }
      }
    } catch (_) { /* 忽略批量替换异常 */ }
    try { sync2Host(vdGetValue()); } catch (_) { /* 忽略同步异常 */ }
    vdRunFind();
  }

  /** 打开查找/替换条（Ctrl+F 查找、Ctrl+R 替换）。
   * @param {boolean} [replace] 是否打开替换模式
   * @returns {boolean} 是否打开成功 */
  function vdOpenFindbar(replace) {
    const bar = document.getElementById('ed-vditor-find');
    if (!bar) return false;
    bar.hidden = false;
    bar.classList.toggle('show-replace', !!replace);
    // 打开时渲染两个输入框的历史下拉
    vdHistRender(SB_FIND_HIST_KEY);
    vdHistRender(SB_REPLACE_HIST_KEY);
    const inp = document.getElementById('vd-find-input');
    if (inp) {
      if (!inp.value && !vdFindQ) {
        // 预填当前鼠标选区文本（若有）
        const sel = window.getSelection ? window.getSelection() : null;
        if (sel && sel.toString) {
          const t = sel.toString();
          if (t) { inp.value = t; }
        }
      }
      inp.focus();
      inp.select();
    }
    vdFindOpen = true;
    if (typeof setTimeout === 'function') setTimeout(vdRunFind, 0);
    return true;
  }

  /** 关闭查找/替换条，并清除匹配临时变色 */
  function vdCloseFindbar() {
    const bar = document.getElementById('ed-vditor-find');
    if (bar) bar.hidden = true;
    vdFindOpen = false;
    vdClearHighlight();
  }

  /** 判断当前 keydown 目标是否应被编辑器查找捕获：
   *  编辑器容器可见 + 焦点在编辑区容器内、或查找条（含其输入框）、或 body/无焦点。
   *  这样 Ctrl+F/Ctrl+R 在查询/替换输入框获得焦点时同样生效，同时避免误拦截宿主其他输入框。
   * @param {Event} e 键盘事件
   * @returns {boolean} 是否应拦截 */
  function vdShouldCatchKey(e) {
    const vd = vdEl();
    if (!vd || vd.offsetParent === null) return false;   // 编辑器未显示，交给系统
    const t = e.target;
    if (!t || t === document || t === document.body) return true;
    const el = (t.nodeType === 1) ? t : (t.parentElement || null);
    if (!el) return true;
    const bar = document.getElementById('ed-vditor-find');
    if (bar && !bar.hidden && bar.contains(el)) return true;  // 焦点在查找/替换输入框
    return vd.contains(el);
  }

  // Ctrl+F 查找 / Ctrl+R 替换快捷键（cmd 兼容 mac，阻断系统查找条）
  document.addEventListener('keydown', function (e) {
    if (!(e.ctrlKey || e.metaKey)) return;
    if (e.isComposing) return;                       // 中文输入法组合中不触发
    const k = String(e.key || '').toLowerCase();
    if (k === 'f' && !e.shiftKey && !e.altKey) {
      if (!vdShouldCatchKey(e)) return;              // 焦点不在编辑器内，放行系统查找
      e.preventDefault();
      vdOpenFindbar(false);
    } else if (k === 'r' && !e.shiftKey && !e.altKey) {
      if (!vdShouldCatchKey(e)) return;
      e.preventDefault();
      vdOpenFindbar(true);
    }
  });

  // findbar 交互绑定（DOM 事件：输入实时查找、上一/下一、替换/全部替换、关闭）
  document.addEventListener('input', function (e) {
    if (e.target && e.target.id === 'vd-find-input') vdRunFind();
  });
  document.addEventListener('click', function (e) {
    const id = e.target && e.target.id;
    if (id === 'vd-find-next') vdFindNav(1);
    else if (id === 'vd-find-prev') vdFindNav(-1);
    else if (id === 'vd-replace-one') vdDoReplace();
    else if (id === 'vd-replace-all') vdDoReplaceAll();
    else if (id === 'vd-find-close') vdCloseFindbar();
  });

  // 宿主薄转发入口
  window.vdFindbar = {
    open: vdOpenFindbar,
    close: vdCloseFindbar,
    /** 切换文档后重算匹配（供宿主 openNote 调用，不抢焦点） */
    refresh: vdRunFind,
    /** 暴露给宿主/回归：当前是否打开 */
    get open_() { return vdFindOpen; },
  };

  /* ---------- 注册 .md/.markdown 编辑器 Provider ---------- */

  // 全局主题变更（设置-外观-主题模式 / 命令面板切换主题）→ 即时同步 vditor 主题。
  // app-core setTheme 每次都会更新 html[data-theme]（dark/light/auto 的已解析结果），以此为唯一信号源。
  if (window.MutationObserver) {
    const themeObs = new MutationObserver(function () { syncVdTheme(); });
    themeObs.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
  }

  /** 注册编辑器 Provider：宿主 openNote 按后缀路由到本引擎（.md/.markdown）。
   * 用模块级标记防重复注册（宿主注册 + 可能的插件残留都可能再调）。 */
  function registerVdProvider() {
    if (typeof registerEditorProvider !== 'function') return;
    if (window.__vdProviderRegistered) return;
    window.__vdProviderRegistered = 1;
    registerEditorProvider({
      id: 'markdown-editor',
      name: 'Markdown Editor',
      extensions: ['.md', '.markdown'],
      openers: [
        { id: 'edit', label: '编辑', icon: 'pencil' },
        { id: 'preview', label: '预览', icon: 'eye' },
        { id: 'split', label: '分屏', icon: 'columns-2' },
      ],
      toolbar: [],
      sidebar: [
        { id: 'props', label: '属性' },
        { id: 'backlinks', label: '反向链接' },
        { id: 'tags', label: '标签' },
      ],
      open: function () { return Promise.resolve(); },
      /* 编辑区渲染已由 vditor 全权承担（vdInit/vdSetMode 驱动）——
         renderWysiwyg 仅保留契约空实现，避免宿主回退调用 app-note.js 的 renderMarkdown，
         保证 markdown 轻量渲染模块与编辑区彻底解耦。 */
      renderWysiwyg: function () { return ''; },
      getMd: function () { return vdGetValue(); },
      buildContextMenu: function () { return []; },
      renderSidebar: function () { return Promise.resolve(); },
    });
  }

  // 脚本已晚于 app-plugins.js 加载，直接注册；额外兜底 DOM 就绪后再注册一次（防顺序异常）
  registerVdProvider();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', registerVdProvider);
  } else {
    registerVdProvider();
  }
})();
