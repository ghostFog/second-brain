﻿/* ============================================
 * 第二脑 — 编辑器宿主·打开/保存/模式/编辑区
 * 作者: 火 冰
 * 功能: 打开笔记与模式路由、保存与字数、标题、启动初始化（initEditor）、
 *       源码/所见即所得模式骨架、查找替换、编辑区宿主
 * ============================================ */

'use strict';

  /* 伪路径/项目路由兜底 shim：当 project-mode.js 未加载时（如无头回归测试）为空实现；
   * 应用运行时会加载 project-mode.js，以同名全局函数覆盖为真实实现（加载顺序更靠后）。
   * 作者: 火 冰 */
  function sbIsPseudoPath(p) { return false; }
  async function sbSave(path, mdText) { return false; }
  function sbRenderTempArea(tree) { return null; }

  /* 渲染编辑区内容（Provider 化）：优先调用当前 Provider 的 renderWysiwyg，
   * 未实现时回退宿主默认 markdown 渲染（renderMarkdown 全局共享）。
   * @param {string} md 源文本
   * @returns {string} 渲染后的 HTML 字符串
   * 作者: 火 冰 */
  function rwRender(md) {
    if (edProvider && typeof edProvider.renderWysiwyg === 'function') return edProvider.renderWysiwyg(md);
    return renderMarkdown(md);
  }

  /* 从编辑区取回源文本（Provider 化）：优先调用当前 Provider 的 getMd，
   * 未实现时回退宿主默认 domToMd（所见即所得 DOM → Markdown）。
   * @param {Element} wys 所见即所得根元素（回退分支使用）
   * @returns {string} 源文本
   * 作者: 火 冰 */
  function rwGetMd(wys) {
    if (edProvider && typeof edProvider.getMd === 'function') return edProvider.getMd();
    return domToMd(wys);
  }

  /* 统一编辑模式常量集合：'wysiwyg' | 'ir' | 'sv' | 'preview'（阅读）
   * 记忆键 sbEditorMode，未设置默认 'ir'（即时渲染）。
   * author 火 冰 */
  function normalizeEditorMode(m) {
    // sbEditorMode 只存编辑节点偏好：ir / wysiwyg / preview。
    // 'sv' 是视图布局（分屏），由独立键 sbSplitLayout 记忆，打开时默认走编辑态。
    return (['wysiwyg', 'ir', 'preview'].indexOf(m) !== -1) ? m : 'ir';
  }

  /* 读取上次记忆的统一编辑模式
   * @returns {string} 'wysiwyg'|'ir'|'sv'|'preview'
   * author 火 冰 */
  function lastEditorMode() {
    const m = (typeof restoreS === 'function') ? restoreS('sbEditorMode', 'ir') : 'ir';
    return normalizeEditorMode(m);
  }

  /* 上次记忆的编辑节点（锁在 WYSIWYG / IR），供「编辑」按钮点击直接切回可编辑态
   * @returns {'wysiwyg'|'ir'}
   * author 火 冰 */
  function lastEditNode() {
    return (lastEditorMode() === 'wysiwyg') ? 'wysiwyg' : 'ir';
  }

  /* 刷新工具栏模式标签文本（随统一编辑模式）
   * author 火 冰 */
  function updateModeLabel() {
    const label = $('ed-mode-label'); if (!label) return;
    const m = lastEditorMode();
    label.textContent = ({ wysiwyg: 'WYSIWYG', ir: '即时渲染', sv: 'SV', preview: '阅读' })[m] || '编辑';
  }

  /* 应用统一编辑模式并记忆：WYSIWYG/IR=编辑节点、SV=源码分屏（上次布局）、preview=SV 纯预览
   * @param {string} mode 'wysiwyg'|'ir'|'sv'|'preview'
   * 作者: 火 冰 */
  function applyEditorMode(mode) {
    mode = normalizeEditorMode(mode);
    if (typeof saveS === 'function') saveS('sbEditorMode', mode);
    if (mode === 'sv') { applySplitLayout(lastSplitLayout()); }      // SV + 上次分屏布局
    else if (mode === 'preview') { applySplitLayout('preview'); }    // SV + 纯预览
    else { if (typeof vdSetEditorNode === 'function') vdSetEditorNode(mode); setEditorMode('edit'); }
  }

  /* 读取上次记忆的 SV 分屏布局（both/editor/preview），用于恢复分屏细分状态
   * @returns {'both'|'editor'|'preview'}
   * author 火 冰 */
  function lastSplitLayout() {
    const l = (typeof restoreS === 'function') ? restoreS('sbSplitLayout', 'both') : 'both';
    return (['both', 'editor', 'preview'].indexOf(l) !== -1) ? l : 'both';
  }

  /* 应用「分屏」某布局（三种均为 SV 基础 + preview.mode 细分）：
   *  - both    分屏（源码+预览）
   *  - editor  仅源码
   *  - preview 仅预览（预览按钮同样走此）
   * 统一由 vditor 的 SV 视图承载，只切换 preview.mode，并记忆以便跨笔记/重启恢复。
   * @param {'both'|'editor'|'preview'} layout 分屏布局
   * 作者: 火 冰 */
  function applySplitLayout(layout) {
    if (['both', 'editor', 'preview'].indexOf(layout) === -1) layout = 'both';
    if (typeof saveS === 'function') saveS('sbSplitLayout', layout);
    edMode = (layout === 'preview') ? 'preview' : 'split';
    // sbEditorMode 只存编辑节点偏好：仅纯预览(preview)写入 sbEditorMode='preview'，
    // 分屏源码/源码-only 不污染 sbEditorMode，避免下次打开默认进入空白 SV 模式。
    // 分屏布局独立由 sbSplitLayout 记忆，用户主动点"分屏"按钮时才恢复。
    if (layout === 'preview' && typeof saveS === 'function') saveS('sbEditorMode', 'preview');
    if (typeof vdSetPreviewMode === 'function') vdSetPreviewMode(layout);
    const label = $('ed-mode-label');
    if (label) label.textContent = ({ both: '分屏', editor: '源码', preview: '预览' })[layout] || '分屏';
    document.getElementById('ed-mode-pop') && (document.getElementById('ed-mode-pop').hidden = true);
    syncModeButtons();
  }

  /* 「分屏」按钮点击：在 both → editor → preview → both 间循环切换（均在 SV 基础内） */
  function cycleSplitLayout() {
    const order = ['both', 'editor', 'preview'];
    const cur = lastSplitLayout();
    applySplitLayout(order[(order.indexOf(cur) + 1) % 3]);
  }

  /* 编辑器宿主态快照（供 PluginAPI.editor.getState 与 md 编辑器插件读取）
   * 作者: 火 冰 */
  function getEdState() {
    return {
      current: edCurrent, mode: edMode, source: edSource, ext: edExt,
      provider: edProvider ? edProvider.id : null,
    };
  }

  /* 打开当前笔记（命令面板「打开当前笔记」调用） */
  function openCurrentNote() {
    if (edCurrent) openNote(edCurrent);
  }

  /* 打开一篇笔记：读取并装载到编辑器，按后缀路由到编辑器能力 Provider
   * @param {string} path    笔记相对路径
   * @param {Object} [opts]  可选 { mode:'wysiwyg'|'ir'|'sv'|'preview' }
   * 作者: 火 冰 */
  async function openNote(path, opts) {
    if (!path) return;
    opts = opts || {};
    edSel = null;             // 打开笔记后清除目录选中，右侧转笔记属性
    if (edOpenTabs.indexOf(path) === -1) edOpenTabs.push(path);
    // 后缀路由：md → markdown-editor Provider；无 Provider 匹配 → 内置纯文本兜底
    edExt = (typeof fileExtension === 'function') ? fileExtension(path) : '';
    const provs = (typeof pluginManager !== 'undefined' && pluginManager && pluginManager.getEditorProviders)
      ? pluginManager.getEditorProviders(edExt) : [];
    edProvider = provs[0] || null;
    edTextFallback = !!(edProvider && edProvider.isFallback);
    // 内容装载：缓存命中则不重复读；项目模式走项目读桥接（相对项目根的 rel 路径）。
    // 读取失败（误传目录路径触发 EISDIR、文件被删等）时撤销刚压入的页签并返回，
    // 既避免「未处理 Promise 异常」，也不留打不开的幽灵页签。作者: 火 冰
    if (!(path in edOutdated)) {
      try {
        // 项目模式：先探测二进制（project:read 返回 binary 标记）→ 二进制/未支持后缀
        // 调系统默认程序打开（并撤销刚压入的页签，避免留下打不开的幽灵页签）。作者: 火 冰
        const pr = (window.sbProject && window.sbProject.isProjectMode() && !sbIsPseudoPath(path))
          ? await window.sbProject.read(path) : null;
        if (pr && pr.binary) {
          const ti = edOpenTabs.indexOf(path);
          if (ti !== -1) edOpenTabs.splice(ti, 1);
          renderTabs();
          await window.sbProject.openExternal(path);
          showToast('已调用系统默认程序打开：' + path.split('/').pop());
          return;
        }
        const c = pr ? pr.content : await noteStore.read(path);
        edOutdated[path] = c;
        // 单篇密文笔记修复（ENC-04 异常处理）：读取结果仍为密文（当前 keyring 解不开，可能用旧密码加密）
        // → 弹「输入旧密码修复」遮罩（桌面笔记库才可能加密；项目模式不加密跳过）。
        // 时序豁免：锁屏尚未解锁（盐未定，固定盐解不开 M3 会把密文误判为「旧密码密文」）时不弹修复框，
        // 待锁屏解锁后（盐=应用密码明文）由 app-security 重载当前笔记自动解密，仍解不开才弹。作者: 火 冰
        if (typeof c === 'string' && c.indexOf('ENC1:') === 0 && !(window.sbProject && window.sbProject.isProjectMode())) {
          const nd = window.noteDesktop;
          if (nd && nd.security && typeof nd.security.getState === 'function') {
            nd.security.getState().then(function (sec) {
              if (sec && sec.hasPwd && !sec.unlocked) return; // 锁屏未解锁：等解锁后重载，本轮不弹
              if (window.SBEncRepair && typeof window.SBEncRepair.tryRepair === 'function') window.SBEncRepair.tryRepair(path);
            }).catch(function () {
              if (window.SBEncRepair && typeof window.SBEncRepair.tryRepair === 'function') window.SBEncRepair.tryRepair(path);
            });
          } else if (window.SBEncRepair && typeof window.SBEncRepair.tryRepair === 'function') {
            window.SBEncRepair.tryRepair(path);
          }
        }
      } catch (err) {
        const i = edOpenTabs.indexOf(path);
        if (i !== -1) edOpenTabs.splice(i, 1);
        renderTabs();
        console.error('[openNote] 读取笔记失败，已跳过打开:', path, err && (err.message || err));
        // 兜底：当前无任何笔记打开（如启动恢复的目录 tab 失败）时不静默留白，回退打开首个真实笔记；
        // 回退目标与失败路径相同时不再递归（避免无限重开同一失败项）。作者: 火 冰
        const fb = edNotes.length ? edNotes[0].path : null;
        if (!edCurrent && fb && fb !== path) { openNote(fb); }
        return;
      }
    }
    /* 关键时序：edCurrent 必须在「内容真正装载进编辑器」之前设置，而不是 openNote 开头。
     * read 是异步的（await），若在开头就设 edCurrent=path，则从「点击新文件」到「新内容渲染进
     * vditor」之间，编辑器仍显示旧文件，但 edCurrent 已指向新文件——此时 vditor 的 blur/input
     * 事件会把「旧文件可见内容」以新文件路径保存，造成串文件/笔记丢失。故在内容就绪后、渲染前
     * 再激活为当前文件，保证 edCurrent 恒等于「编辑器当前正显示的文件」。作者: 火 冰 */
    edCurrent = path;
    /* 关键时序：在 await file read 完成后、renderArticle 之前，重新路由 Provider。
     * openNote 开头（约第 141-144 行）在 await 之前就调用了 pluginManager.getEditorProviders(edExt)，
     * 但此时目录插件（markdown-editor）可能还在异步加载中（initPluginSystem → loadDirPlugins 无 await），
     * getEditorProviders 只会返回 fallback（id=__fallback__）。await file read 期间，JS 事件循环会处理
     * 目录插件加载完成的微任务，此时 markdown-editor 已注册了真正的 Provider。这里重新获取就能拿到
     * 正确的 Provider id（markdown-editor），避免 renderArticle 中 isMd=false 导致工具栏模式按钮被隐藏。
     * 作者: 火 冰 */
    {
      const freshProvs = (typeof pluginManager !== 'undefined' && pluginManager && pluginManager.getEditorProviders)
        ? pluginManager.getEditorProviders(edExt) : [];
      if (freshProvs[0] && (!edProvider || edProvider.id !== freshProvs[0].id)) {
        edProvider = freshProvs[0];
        edTextFallback = !!(edProvider && edProvider.isFallback);
      }
    }
    // 打开方式：入参优先，否则按上次记忆的统一编辑模式（WYSIWYG/IR/SV/阅读）应用；
    applyEditorMode(opts.mode || lastEditorMode());
    renderTabs();
    renderArticle();
    renderFileTree(edNotes);
    if (findOpen) runFind(); // 切换文档后重新统计匹配
    updateCrumb('editor');   // 面包屑随当前打开笔记路径刷新
    persistRecentTabs();     // 把当前打开标签页写入 .second-brain/recent.json，供下次启动恢复
    // 索引面板已展开时，随当前笔记刷新展示
    const p = $('ed-index-panel');
    if (p && !p.hidden) renderIndexPanel();
  }

  /* 从磁盘强制重载一篇笔记（清缓存 + 去脏后重读）：供插件在外部改动文件（如 Git 回滚/还原）后
   * 刷新编辑器，使编辑区与磁盘真实内容一致，避免把旧缓存内容写回覆盖。作者: 火 冰 */
  function reloadNote(path) {
    if (!path) return;
    if (edOutdated[path] != null) delete edOutdated[path];
    edDirty.delete(path);
    if (path === edCurrent) openNote(path);
  }

  /* ============================
   * ED-60 外部文件变更自动感知
   * 订阅主进程 10s 快照监控推送的 vault:tree-changed（含 added/removed/modified 明细），
   * 800ms 防抖合并事件风暴后：刷新文件树；打开中的笔记按「干净自动同步 / 脏文档保留 / 丢失标记」联动。
   * ============================ */
  let edExtWatchTimer = null;    // 防抖计时器
  let edExtWatchAcc = null;      // 合并中的变更明细 {kind, added:Set, removed:Set, modified:Set}

  /** 绑定外部变更订阅（initEditor 调用；重入先解绑防重复监听）。网页 mock 无此桥时静默降级。
   * @author 火 冰 */
  function bindExternalFsWatch() {
    const nd = window.noteDesktop;
    if (!nd || typeof nd.onVaultTreeChanged !== 'function') return;
    if (typeof nd.offVaultTreeChanged === 'function') nd.offVaultTreeChanged();
    edExtWatchTimer = null;
    edExtWatchAcc = null;
    nd.onVaultTreeChanged(function (data) {
      if (!data) return;
      // 锁屏遮罩下不处理（主进程锁屏期也不推送且不推进基线，解锁后首个周期补推），双保险
      try {
        const st = nd.security && nd.security.getStateSync ? nd.security.getStateSync() : null;
        if (st && st.unlocked === false) return;
      } catch (_) { /* 状态取不到不阻断 */ }
      if (!edExtWatchAcc) edExtWatchAcc = { kind: data.kind || 'vault', added: new Set(), removed: new Set(), modified: new Set() };
      (data.added || []).forEach(function (p) { edExtWatchAcc.added.add(p); edExtWatchAcc.removed.delete(p); });
      (data.removed || []).forEach(function (p) { edExtWatchAcc.removed.add(p); edExtWatchAcc.added.delete(p); });
      (data.modified || []).forEach(function (p) { if (!edExtWatchAcc.added.has(p)) edExtWatchAcc.modified.add(p); });
      if (edExtWatchTimer) clearTimeout(edExtWatchTimer);
      edExtWatchTimer = setTimeout(handleExternalTreeChange, 800);
    });
  }

  /** 防抖到期后的实际处理：刷树 + 打开标签外部联动。
   * 规则：文件丢失→标签标失+保留内容（保存即按原路径恢复）；干净标签外部修改→自动同步（当前标签即时重载，
   * 后台标签换缓存）；脏标签外部修改→保留用户版本仅提示；与缓存一致视为应用内自身操作的回声，幂等忽略。
   * @author 火 冰 */
  async function handleExternalTreeChange() {
    const acc = edExtWatchAcc;
    edExtWatchAcc = null;
    edExtWatchTimer = null;
    if (!acc) return;
    try { await refreshTreeAfterChange(); } catch (_) { /* 树刷新失败不阻断标签联动 */ }
    if (acc.kind === 'project') return; // 项目模式为自动保存模型，本轮只刷树，不做编辑器内容联动，避免覆盖在编内容
    // 刷新后 edNotes 即最新磁盘清单；打开标签命中明细或已不在清单（整目录被删）时纳入检查
    const exists = new Set(edNotes.filter(function (n) { return !n.isFolder; }).map(function (n) { return n.path; }));
    const touched = new Set();
    edOpenTabs.forEach(function (p) {
      if (sbIsPseudoPath(p)) return;
      if (acc.added.has(p) || acc.removed.has(p) || acc.modified.has(p) || !exists.has(p)) touched.add(p);
    });
    if (!touched.size) return;
    let tabsChanged = false;
    for (const p of touched) {
      const name = p.split('/').pop();
      if (!exists.has(p)) { // 外部删除/移动：标记丢失，保留编辑内容
        if (!edMissing.has(p)) {
          edMissing.add(p);
          tabsChanged = true;
          showToast('「' + name + '」已在资源管理器中被删除或移动，内容已保留，保存可恢复到原路径');
        }
        continue;
      }
      if (edMissing.has(p)) { edMissing.delete(p); tabsChanged = true; } // 外部恢复/重建：解除丢失标记
      let disk;
      try { disk = await noteStore.read(p); } catch (_) { continue; }
      const loaded = edOutdated[p];
      if (loaded == null || disk === loaded) continue; // 未加载缓存 或 内容一致（自身保存回声）
      if (edDirty.has(p)) {
        showToast('「' + name + '」已被外部修改，你的未保存更改已保留（未覆盖）');
        continue;
      }
      if (p === edCurrent) {
        reloadNote(p); // 当前标签：清缓存重读并即时渲染
        showToast('「' + name + '」已随外部修改自动更新');
      } else {
        edOutdated[p] = disk; // 后台标签：仅换缓存，切换过去即为磁盘新版
      }
    }
    if (tabsChanged) renderTabs();
  }

  /* 把当前打开的标签页路径列表持久化到 .second-brain/recent.json（桌面版桥接）。
   * 持久化时把当前激活（最后打开/切换）的笔记移到列表末尾，启动恢复据此定位「最后打开的文件」。 */
  function persistRecentTabs() {
    // 项目工作区：无知识库 recent.json，不写入（临时文件也不写入）
    if (window.sbProject && window.sbProject.isProjectMode()) return;
    const nd = window.noteDesktop || {};
    if (nd && nd.recentSave) {
      try {
        const cur = edOpenTabs.slice().filter(function (p) { return !sbIsPseudoPath(p); });
        if (edCurrent && !sbIsPseudoPath(edCurrent) && cur.length > 1) {
          const i = cur.indexOf(edCurrent);
          if (i > -1) { cur.splice(i, 1); cur.push(edCurrent); }
        }
        nd.recentSave({ tabs: cur, pinned: Array.from(edPinned) });
      } catch (_) { /* 记录失败忽略 */ }
    }
  }

  /* 自动调整源码 textarea 高度：取「内容高」与「可视区高」的较大值，
   * 使内容不足时编辑区也撑满与行号 gutter 通栏等高（占满 #ed-split 可视区）；外层 ed-split 统一承载滚动。
   * 作者: 火 冰 */
  function autoResizeTa(ta) {
    if (!ta) return;
    ta.style.height = 'auto';
    const contentH = ta.scrollHeight || 0;
    // 参考容器：唯一滚动容器 #ed-split；其可视高即为编辑区应占满的高度
    const split = $('ed-split');
    let viewportH = 0, tTop = 0, splitTop = 0;
    if (split) {
      const r = split.getBoundingClientRect(); splitTop = r.top; viewportH = split.clientHeight;
      if (ta.getBoundingClientRect) tTop = ta.getBoundingClientRect().top;
    }
    // 剩余高度 = 可视区高 − textarea 顶缘相对滚动容器顶的偏移
    const remain = Math.max(0, viewportH - (tTop - splitTop));
    ta.style.height = Math.max(contentH, remain) + 'px';
  }

  /* 编辑区两种子视图显隐（vditor 化）：源码/所见即所得/预览均由 vditor 自管，
   * 宿主在此仅同步模式按钮的高亮状态。
   * 作者: 火 冰 */
  function applySourceMode() {
    syncModeButtons();
  }

  /* 同步工具条三个模式按钮的高亮：编辑/预览/分屏各自独立，按当前布局模式点亮；
   * 同时点亮「编辑」冒泡子菜单中当前选中的编辑节点（WYSIWYG / IR）
   * 作者: 火 冰 */
  function syncModeButtons() {
    document.querySelectorAll('[data-mode]').forEach(function (b) {
      const m = b.dataset.mode;
      const on = edMode === m;
      b.style.background = on ? 'var(--note-surface-2)' : 'transparent';
      b.style.color = on ? 'var(--note-ink)' : 'var(--note-ink-3)';
    });
    // 「编辑」按钮悬浮菜单：高亮当前使用的编辑节点（WYSIWYG / IR，菜单仅两项编辑节点）
    const node = lastEditNode();
    document.querySelectorAll('#ed-mode-pop [data-mode-item]').forEach(function (item) {
      const on = item.dataset.modeItem === node;
      item.style.background = on ? 'var(--note-surface-2)' : 'transparent';
      item.style.color = on ? 'var(--note-ink)' : 'var(--note-ink-3)';
    });
    // 「分屏」按钮悬浮菜单：高亮当前布局（both/editor/preview 三种 SV 布局）
    const layout = lastSplitLayout();
    document.querySelectorAll('#ed-split-pop [data-split-item]').forEach(function (item) {
      const on = item.dataset.splitItem === layout;
      item.style.background = on ? 'var(--note-surface-2)' : 'transparent';
      item.style.color = on ? 'var(--note-ink)' : 'var(--note-ink-3)';
    });
  }

  /* 编辑输入统一处理：更新缓存/字数/状态栏/防抖保存
   * vditor 在 input 事件把最新文本回调至此；预览联动由 vditor 自管。
   * 作者: 火 冰 */
  function onEdInput(mdText) {
    const _t0 = performance.now();
    // 内容归属在「产生这次输入」时即固定为该文件，后续一律用 p 而非 edCurrent。
    // 原实现在 autosave 去抖 timer 触发时才读 edCurrent，快速切换笔记时会把 A 的内容写进 B
    // （串文件/覆盖丢失），或 A 的去抖 timer 被 B 的输入 clearTimeout 清掉导致 A 的修改不保存。
    const p = edCurrent;
    if (!p) return;
    // 非用户实际修改：内容与已缓存一致且本不是脏文件（失焦同步/程序回灌/blur 重复）→ 忽略，
    // 不写文件，避免把旧/空内容覆盖回磁盘。作者: 火 冰
    const prev = edOutdated[p] || '';
    if (prev === mdText && !edDirty.has(p)) return;
    edOutdated[p] = mdText;
    edDirty.add(p); // 内容变化记为「有未保存更改」
    const cnt = $('ed-count'); if (cnt) cnt.textContent = countChars(mdText) + ' 字';
    const saved = $('ed-saved'); if (saved) saved.textContent = '编辑中…';
    if (!restoreS('edAutoSave', true)) { if (saved) saved.textContent = '自动保存已关闭'; return; }
    // 按文件独立去抖：仅重置本文件自己的 timer，不影响其它正在编辑的笔记（避免切换时丢保存）
    if (edSaveTimers[p]) clearTimeout(edSaveTimers[p]);
    const _t1 = performance.now();

    edSaveTimers[p] = setTimeout(async function () {
      const _s0 = performance.now();
      delete edSaveTimers[p];
      // 保存路由：临时文件（非知识库第二套）走 sbSave 写回原绝对路径，项目文件/知识库按路径路由保存
      const handled = (typeof sbSave === 'function') ? await sbSave(p, mdText) : false;
      const _s1 = performance.now();
      try {
        if (!handled) await noteStore.save(p, mdText);
        const _s2 = performance.now();
        edDirty.delete(p);
        if (edMissing.delete(p)) renderTabs(); // ED-60：丢失标签保存即按原路径恢复，解除丢失样式
        const s = $('ed-saved'); if (s) s.textContent = handled ? (sbIsPseudoPath(p) ? '已保存到临时文件' : '已保存到项目') : '已自动保存';
        const _s3 = performance.now();
        if (_s3 - _s0 > 10) {
          console.warn('[PERF][SAVE] path=', p.split('/').pop(), 'mdLen=', mdText.length,
            'total=', (_s3 - _s0).toFixed(1), 'ms',
            'sbSave=', (_s1 - _s0).toFixed(1),
            'noteStore=', (_s2 - _s1).toFixed(1));
        }
      } catch (err) { console.error('[PERF][SAVE] ERROR:', err); const s = $('ed-saved'); if (s) s.textContent = '保存失败'; }
    }, 800);

    const _t2 = performance.now();
    if (_t2 - _t0 > 3) {
      console.warn('[PERF][onEdInput] path=', p.split('/').pop(), 'mdLen=', mdText.length,
        'total=', (_t2 - _t0).toFixed(1), 'ms',
        'guard+cache=', (_t1 - _t0).toFixed(1),
        'setTimer=', (_t2 - _t1).toFixed(1));
    }
  }

  /* ============================
   * 查找 / 替换（Ctrl+F 查找，Ctrl+R 替换）
   * 实际实现在 editor-vditor.js（window.vdFindbar），针对 vditor 三种编辑模式统一实现。
   * 此处仅保留宿主薄转发：函数名 openFindbar/closeFindbar/runFind 与布尔 findOpen
   * 供 app-layout.js（Esc 关闭）与 openNote（切换文档后重算匹配）等既有调用继续生效。
   * 作者: 火 冰
   * ============================ */

  /* 打开查找/替换条：replace=true 时显示替换行（Ctrl+R），否则仅查找（Ctrl+F） */
  function openFindbar(replace) {
    if (window.vdFindbar && typeof window.vdFindbar.open === 'function') {
      if (window.vdFindbar.open(replace)) findOpen = true;
    }
  }

  /* 关闭查找/替换条 */
  function closeFindbar() {
    findOpen = false;
    if (window.vdFindbar && typeof window.vdFindbar.close === 'function') window.vdFindbar.close();
  }

  /* 切换文档后重新统计匹配（委托 vditor 侧刷新，不抢焦点） */
  function runFind() {
    if (window.vdFindbar && typeof window.vdFindbar.refresh === 'function') window.vdFindbar.refresh();
  }

  /* 根据当前 Provider 控制「编辑/预览/分屏」工具栏按钮显隐。
   *  只有 Markdown Editor (vditor) 才支持多模式切换；CodeMirror 等代码编辑器是单模式编辑器，这些按钮应隐藏。
   *  @param {boolean} show  true=显示模式按钮，false=隐藏
   * 作者: 火 冰 */
  function setModeToolbarVisible(show) {
    const editWrap = document.getElementById('ed-mode-edit-wrap');
    const splitWrap = document.getElementById('ed-split-wrap');
    const previewBtn = document.querySelector('button[data-mode="preview"]');
    if (editWrap) editWrap.style.display = show ? '' : 'none';
    if (splitWrap) splitWrap.style.display = show ? '' : 'none';
    if (previewBtn) previewBtn.style.display = show ? '' : 'none';
  }

  /* 渲染编辑区与元信息/大纲/反链/标签 */
  function renderArticle() {
    const path = edCurrent;
    const md = edOutdated[path] || '';
    /* 双重保险：每次 renderArticle 都重新路由一次 Provider，不依赖 openNote 开头缓存的值。
     * 异步目录插件的 Provider 可能在 openNote 内部 await file read 之后才注册好，
     * 这里直接重新获取能确保用到最新的 Provider，isMd 判定才是正确的。作者: 火 冰 */
    {
      const ext = (typeof fileExtension === 'function') ? fileExtension(path) : edExt;
      const provs = (typeof pluginManager !== 'undefined' && pluginManager && pluginManager.getEditorProviders)
        ? pluginManager.getEditorProviders(ext) : [];
      if (provs[0] && (!edProvider || edProvider.id !== provs[0].id)) {
        edProvider = provs[0];
        edTextFallback = !!(edProvider && edProvider.isFallback);
      }
    }
    const isMd = edProvider && edProvider.id === 'markdown-editor';
    setModeToolbarVisible(isMd);   // 只有 vditor Markdown 编辑器需要模式切换按钮

    // 编辑区 Provider 路由：第三方 Provider（CodeMirror 等）接管编辑区时整体隐藏 vditor 容器、插 DOM、调 open()
    // 切回 Markdown 时恢复 vditor 容器显示，applyVdVisibility 会在 buildVditor after 里正确控制各面板显隐
    if (edProvider && edProvider.id && edProvider.id !== 'markdown-editor' && edProvider.id !== '__fallback__') {
      const vdHost = document.getElementById('ed-vditor');
      if (vdHost) vdHost.style.display = 'none';
      // 清理之前的 provider DOM 容器
      document.querySelectorAll('.sb-provider-dom').forEach(function (n) { n.parentNode.removeChild(n); });
      const wrap = document.createElement('div');
      wrap.className = 'sb-provider-dom';
      wrap.innerHTML = (typeof edProvider.renderWysiwyg === 'function') ? edProvider.renderWysiwyg(md) : '';
      document.getElementById('ed-vditor').parentNode.appendChild(wrap);
      if (typeof edProvider.open === 'function') {
        try { Promise.resolve(edProvider.open(path, md, onEdInput)).catch(function (e) { console.error('[renderArticle] provider.open fail:', e); }); }
        catch (e) { console.error('[renderArticle] provider.open err:', e); }
      }
    } else {
      // Markdown 路径：恢复 vditor 容器显示，清理 provider DOM，内容同步交给 vditor（内部 applyVdVisibility 管显隐）
      const vdHost = document.getElementById('ed-vditor');
      if (vdHost) vdHost.style.display = '';
      document.querySelectorAll('.sb-provider-dom').forEach(function (n) { n.parentNode.removeChild(n); });
      if (typeof vdSyncValue === 'function') vdSyncValue(md, path);
    }
    // 标题/时间/字数组件已按 ED-44 移除：顶部不留标题条，改名统一走文件树（右键「重命名」/双击文件名）
    // 字数/保存状态仍由下方状态栏（ed-count/ed-saved）承担
    const cnt = $('ed-count'); if (cnt) cnt.textContent = countChars(md) + ' 字';
    const saved = $('ed-saved'); if (saved) saved.textContent = '已加载';
    // 标签
    const tags = extractTags(md);
    const tagBox = $('ed-tags'); if (tagBox) tagBox.innerHTML = tags.map(t => '<span class="px-2 py-1 rounded text-[12px] border" style="border-color: var(--note-border); background: var(--note-surface-2); color: var(--note-brand-300);">' + esc(t) + '</span>').join('') || '<span class="text-[11px]" style="color: var(--note-ink-3);">（暂无标签）</span>';
    const tagC = $('ed-tags-count'); if (tagC) tagC.textContent = String(tags.length);
    // 项目工作区 / 临时文件：无知识库反链/属性数据，且侧边面板已隐藏/置空，跳过（避免 fileMeta 越界）
    const altMode = (window.sbProject && window.sbProject.isProjectMode()) || sbIsPseudoPath(path);
    if (!altMode) {
      // 反向链接：其它笔记包含 [[当前名片段]]
      renderBacklinks();
      // 文件属性：文档 id / 路径 / 索引分块起止规则      renderFileProps();
    }
    updateProviderLabel(path);
  }

  function updateProviderLabel(path) {
    const label = document.getElementById('ed-provider-label');
    if (!label) return;
    const ext = (typeof fileExtension === 'function') ? fileExtension(path) : '';
    const provs = (typeof pluginManager !== 'undefined' && pluginManager && pluginManager.getEditorProviders)
      ? pluginManager.getEditorProviders(ext) : [];
    if (!edProvider) { label.textContent = '—'; return; }
    label.textContent = edProvider.name || edProvider.id || '编辑器';
    if (provs.length > 1) {
      label.style.cursor = 'pointer';
      label.style.color = 'var(--note-brand-300)';
      label.title = '点击切换编辑器（共 ' + provs.length + ' 种可用）';
      if (!label.__sbBound) {
        label.addEventListener('click', function (e) {
          e.stopPropagation();
          toggleProviderMenu(path, label);
        });
        label.__sbBound = true;
      }
    } else {
      label.style.cursor = 'default';
      label.style.color = '';
      label.title = '';
    }
  }

  function toggleProviderMenu(path, anchor) {
    const exist = document.getElementById('ed-provider-menu');
    if (exist) { exist.parentNode.removeChild(exist); return; }
    const ext = (typeof fileExtension === 'function') ? fileExtension(path) : '';
    const provs = (typeof pluginManager !== 'undefined' && pluginManager && pluginManager.getEditorProviders)
      ? pluginManager.getEditorProviders(ext) : [];
    if (provs.length <= 1) return;
    const menu = document.createElement('div');
    menu.id = 'ed-provider-menu';
    menu.style.cssText = 'position:absolute;z-index:9999;min-width:180px;padding:4px;border-radius:6px;background:var(--note-surface-2);border:1px solid var(--note-border);box-shadow:0 4px 16px rgba(0,0,0,.15);font-size:12px;color:var(--note-ink);';
    const title = document.createElement('div');
    title.style.cssText = 'padding:4px 8px;color:var(--note-ink-3);font-size:11px;';
    title.textContent = '选择 .' + ext.replace('.', '') + ' 文件编辑器：';
    menu.appendChild(title);
    provs.forEach(function (p) {
      const item = document.createElement('div');
      const isCur = (edProvider && edProvider.id === p.id);
      item.style.cssText = 'padding:6px 10px;border-radius:4px;cursor:pointer;' + (isCur ? 'color:var(--note-brand-300);font-weight:600;' : '');
      item.innerHTML = (isCur ? '✓ ' : '&nbsp;&nbsp;') + (p.name || p.id);
      item.addEventListener('mouseenter', function () { if (!isCur) item.style.background = 'rgba(255,255,255,0.05)'; });
      item.addEventListener('mouseleave', function () { item.style.background = ''; });
      item.addEventListener('click', function (e) {
        e.stopPropagation();
        if (p.id !== edProvider.id) {
          if (typeof pluginManager !== 'undefined' && pluginManager && pluginManager.setProviderPref) {
            pluginManager.setProviderPref(ext, p.id);
          }
          const curPath = edCurrent; edCurrent = null; openNote(curPath);
        }
        if (menu.parentNode) menu.parentNode.removeChild(menu);
      });
      menu.appendChild(item);
    });
    const rect = anchor.getBoundingClientRect();
    menu.style.left = rect.left + 'px'; menu.style.top = (rect.bottom + window.scrollY + 2) + 'px';
    document.body.appendChild(menu);
    setTimeout(function () {
      document.addEventListener('click', function closemenu(e) {
        if (!menu.contains(e.target) && e.target !== anchor) {
          if (menu.parentNode) menu.parentNode.removeChild(menu);
          document.removeEventListener('click', closemenu);
        }
      });
    }, 0);
  }

  /* 选择编辑子节点 IR）：委托 vditor 切换并进入编辑模式。
   * @param {'wysiwyg'|'ir'} node 编辑节点类型
   * 作者: 火 冰 */
  function selectEditNode(node) {
    applyEditorMode(node === 'wysiwyg' ? 'wysiwyg' : 'ir');
    syncModeButtons();               // 高亮当前选择的模式项
  }

  /* 定位冒泡子菜单：基于触发按钮所在容器（相对定位）铺开菜单
   * @param {Element} anchor 相对定位的触发容器
   * @param {Element} pop 冒泡菜单元素
   * 作者: 火 冰 */
  function stylePopAnchor(anchor, pop) {
    pop.style.left = '0px';
    pop.style.top = (anchor.offsetHeight + 4) + 'px';
  }

  /* 切换编辑/预览/分屏模式：映射驱动 vditor 模式（编辑→编辑节点、分屏→SV、预览→纯预览）
   * 作者: 火 冰 */
  function setEditorMode(mode) {
    edMode = mode;
    const label = $('ed-mode-label');
    syncModeButtons();
    if (typeof vdSetMode === 'function') vdSetMode(mode);
    if (label) {
      if (mode === 'edit' && typeof vdGetEditorNode === 'function') {
        const n = vdGetEditorNode();
        label.textContent = n === 'wysiwyg' ? '编辑 · 所见即所得' : '编辑 · 即时渲染';
      } else {
        label.textContent = ({ preview: '预览', split: '分屏', edit: '编辑' })[mode] || mode;
      }
    }
    // 关闭编辑子节点冒泡菜单（如有打开）
    const pop = document.getElementById('ed-mode-pop'); if (pop) pop.hidden = true;
    applySourceMode();
  }

  /* bindWysCopyButton：自研所见即所得代码块悬浮复制按钮——已随 vditor 接管整体退役。
   * 保留空函数占位，避免外部遗留调用断链。作者: 火 冰 */
  function bindWysCopyButton() { return null; }

  /* 编辑器初始化：装载列表 + 默认打开第一篇 */
  async function initEditor() {
    // 先绑定目录区/侧边面板拖拽条：即使下面装载/渲染异常也保证可拖动调宽
    bindTreeResizer();
    bindSideResizer();
    bindExternalFsWatch(); // ED-60：订阅资源管理器外部增删改，自动刷新文件树/打开笔记
    // 项目窗口识别：经 preload 探测当前窗口是否为「打开项目」工作区（非知识库）
    if (window.sbProject) { try { await window.sbProject.detect(); } catch (_) { /* 忽略 */ } }
    let notes = [];
    // 项目模式：不走知识库笔记索引，改为项目文件树（相对项目根的 rel 路径，复用既有渲染）
    if (window.sbProject && window.sbProject.isProjectMode()) {
      edNotes = (await window.sbProject.list()).sort((a, b) => a.path.localeCompare(b.path, 'zh'));
    } else {
      try { notes = await noteStore.list(); }
      catch (err) { console.error('[noteStore.list] 失败：', err); }
      edNotes = notes.sort((a, b) => (a.path).localeCompare(b.path, 'zh'));
    }
    renderFileTree(edNotes);
    // 绑定文件树点击 / 搜索
    const tree = $('file-tree');
    if (tree) tree.addEventListener('click', function (e) {
      // 重命名就地输入框：点击输入框内不触发行的展开/打开/折叠，避免下方重建 DOM 销毁输入框
      if (e.target.closest('input, textarea')) return;
      const file = e.target.closest('.tree-file');
      if (file) {
        const path = file.dataset.path;
        // 双击文件名 → 就地重命名。单击 openNote 会重建文件树 DOM 使原生 dblclick 丢失，
        // 故在此用时间窗判定：<320ms 内再次点击同文件视为双击，第二击直接走重命名、不再 openNote
        const now = Date.now();
        if (edClickPath === path && now - edClickTime < 320) {
          edClickPath = null;
          renameNoteFile(path);
          return;
        }
        edClickPath = path;
        edClickTime = now;
        openNote(path);
        return;
      }
      const folder = e.target.closest('.tree-folder');
      if (folder) {
        const key = folder.dataset.folder;
        // 双击目录名 → 就地重命名。单击折叠/展开会重建文件树 DOM，使原生 dblclick 丢失，
        // 故在此用时间窗判定：<320ms 内再次点击同目录视为双击，第二击直接走重命名、不再折叠
        const now = Date.now();
        if (edClickFolder === key && now - edClickFolderTime < 320) {
          edClickFolder = null;
          renameDirInline(key);
          return;
        }
        edClickFolder = key;
        edClickFolderTime = now;
        if (collapsedFolders.has(key)) collapsedFolders.delete(key); else collapsedFolders.add(key);
        edSel = { type: 'folder', path: key };   // 选中目录 → 右侧显示该目录属性
        renderFileTree(edNotes);
        renderFileProps();
        return;
      }
      // 点击目录区空白 → 显示根目录属性
      edSel = { type: 'folder', path: '' };
      renderFileProps();
    });
    // 双击重命名已改为 click 内时间窗判定（见 .tree-file 分支），避免 openNote 重建 DOM 使 dblclick 丢失
    // ED-61/ED-62 搜索：三段式一体化 + 范围下拉 + Aa 大小写/整词 + 设置齿轮 + localStorage 持久化
    (function setupFullTextSearch() {
      const LS_KEY = 'sb.search.settings';
      const DEFAULTS = { range: 'content', caseSensitive: false, wholeWord: false, snippetLen: 50 };
      const settings = Object.assign({}, DEFAULTS);
      try { Object.assign(settings, JSON.parse(localStorage.getItem(LS_KEY) || '{}')); } catch (_) {}
      // 持久化 Aa 图标状态（视觉：两开关任一开启时 Aa 高亮）
      function persistSettings() { try { localStorage.setItem(LS_KEY, JSON.stringify(settings)); } catch (_) {} }
      function applyAaIcon() {
        const btn = document.getElementById('sb-search-aacase');
        if (!btn) return;
        const active = settings.caseSensitive || settings.wholeWord;
        btn.style.color = active ? 'var(--note-brand-400)' : 'var(--note-ink-3)';
        btn.title = (settings.caseSensitive ? '大小写敏感 ON ' : '') + (settings.wholeWord ? '整词 ON' : '');
      }

      const search = $('file-search');
      if (!search) return;
      // 同步 range 下拉初始值
      const rangeSel = document.getElementById('sb-search-range');
      if (rangeSel) { rangeSel.value = settings.range; rangeSel.addEventListener('change', function () {
        settings.range = this.value; persistSettings();
        // 触发一次即时搜索
        if (search.value.trim().length >= 2) search.dispatchEvent(new Event('input'));
      }); }
      applyAaIcon();

      let debounceTimer = null, blurTimer = null, lastReqToken = 0, suggestionsEl = null;

      /** 动态决定是否发后端搜索请求：range=content 必须走后端（解密全文匹配）；
       *  range=name/title 可走纯前端过滤（速度快、无需 IPC），但仍发后端以复用排序/高亮逻辑；
       *  桥不可用回退纯前端文件名过滤。 */
      function shouldUseBackend(q) {
        if (settings.range === 'content') return true;
        // name/title 范围也走后端（主进程 handler 已做 range 分流且比前端过滤更规范）
        const nd = window.noteDesktop;
        return !!(nd && typeof nd.searchNotes === 'function');
      }

      function ensureSuggestionsEl() {
        if (suggestionsEl && document.body.contains(suggestionsEl)) return suggestionsEl;
        suggestionsEl = document.createElement('div');
        suggestionsEl.setAttribute('role', 'listbox');
        // position:fixed + append body，彻底脱离 ancestors 的 overflow:hidden 裁剪
        suggestionsEl.style.cssText = 'position:fixed;z-index:9999;background:var(--note-background,#fff);border:1px solid var(--note-border,#e5e7eb);'
          + 'border-top:none;border-radius:0 0 8px 8px;box-shadow:0 6px 20px rgba(0,0,0,.12);max-height:320px;overflow-y:auto;'
          + 'font-size:12px;color:var(--note-ink,#111);padding:4px 0;display:none;';
        document.body.appendChild(suggestionsEl);
        return suggestionsEl;
      }

      /** 用锚点元素的 getBoundingClientRect 把 suggestions 浮层定位到其正下方，同宽。
       *  position:fixed 完全脱离祖先 overflow 裁剪（aside overflow-hidden 不再影响）。 */
      function positionSuggestions() {
        const anchor = search.parentElement;
        if (!anchor) return;
        const rect = anchor.getBoundingClientRect();
        const box = ensureSuggestionsEl();
        box.style.left = rect.left + 'px';
        box.style.top = rect.bottom + 'px';
        box.style.width = rect.width + 'px';
      }

      function escapeHtml(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

      function renderSuggestions(list, q) {
        const box = ensureSuggestionsEl();
        if (!list || !list.length) { box.style.display = 'none'; box.innerHTML = ''; return; }
        positionSuggestions(); // 每次显示前重新定位（窗口尺寸/滚动可能变）
        const qRe = q ? new RegExp('(' + q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', settings.caseSensitive ? 'g' : 'gi') : null;
        box.innerHTML = list.map(it => {
          const safeSnippet = escapeHtml(it.snippet || '').replace(qRe, '<mark style="background:#fff3a0;color:#b45309;padding:0 2px;border-radius:2px;">$1</mark>');
          const safeTitle = escapeHtml(it.title || it.path.split('/').pop());
          const folder = it.path.indexOf('/') >= 0 ? it.path.slice(0, it.path.lastIndexOf('/')) : '';
          return '<div role="option" tabindex="-1" data-path="' + escapeHtml(it.path) + '" style="cursor:pointer;padding:8px 10px;line-height:1.4;border-bottom:1px solid var(--note-border,#f3f4f6);transition:background .08s;" onmouseover="this.style.background=\'rgba(124,58,237,.06)\'" onmouseout="this.style.background=\'\'">'
            + '<div style="font-weight:500;color:var(--note-ink,#111);">' + safeTitle + '</div>'
            + (folder ? '<div style="color:var(--note-ink-3,#9ca3af);font-size:11px;margin-top:2px;">📁 ' + escapeHtml(folder) + '</div>' : '')
            + '<div style="color:var(--note-ink-2,#4b5563);margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' + safeSnippet + '</div>'
            + '</div>';
        }).join('');
        box.style.display = 'block';
      }

      function closeSuggestions() { if (suggestionsEl) { suggestionsEl.style.display = 'none'; suggestionsEl.innerHTML = ''; } }

      /** 打开搜索结果对应的笔记。
       * @param {string} path 笔记 vault 内路径（如 "folder/note.md"）
       * @author 火 冰 */
      function openSearchedNote(path) {
        if (!path) return;
        closeSuggestions();
        search.value = '';
        // 调宿主层的 openNote（和文件树点击同一入口）
        if (typeof window.openNote === 'function') {
          window.openNote(path);
        } else if (typeof window.loadNoteByPath === 'function') {
          window.loadNoteByPath(path);
        }
      }

      // 在 suggestionsEl 上用事件委托绑 click（因为 innerHTML 重建会丢 handler）
      // 必须在 ensureSuggestionsEl 创建后、第一次 render 前就绑好
      function bindSuggestionsClick() {
        const box = ensureSuggestionsEl();
        if (box._suggestionsBound) return;
        box._suggestionsBound = true;
        box.addEventListener('click', function (e) {
          const item = e.target.closest && e.target.closest('[data-path]');
          if (!item) return;
          const p = item.getAttribute('data-path');
          if (p) { e.preventDefault(); openSearchedNote(p); }
        });
        // Enter 触发的 click() 也走这里
      }
      bindSuggestionsClick();

      // ------- Aa 切换图标：点击弹出大小写/整词 popover -------
      let aaPopover = null;
      function closeAaPopover() { if (aaPopover) { aaPopover.remove(); aaPopover = null; } }
      function showAaPopover() {
        closeAaPopover();
        aaPopover = document.createElement('div');
        // position:fixed + append body，彻底脱离 aside overflow-hidden 裁剪
        aaPopover.style.cssText = 'position:fixed;z-index:10000;background:var(--note-background,#fff);border:1px solid var(--note-border,#e5e7eb);'
          + 'border-top:none;border-radius:0 0 8px 8px;box-shadow:0 6px 20px rgba(0,0,0,.12);padding:6px;min-width:140px;font-size:12px;';
        function toggle(label, key) {
          const row = document.createElement('label');
          row.style.cssText = 'display:flex;align-items:center;gap:8px;padding:4px 8px;cursor:pointer;border-radius:4px;';
          row.innerHTML = '<input type="checkbox" style="accent-color:#7c3aed;" ' + (settings[key] ? 'checked' : '') + '>'
            + '<span style="color:var(--note-ink,#111);">' + escapeHtml(label) + '</span>';
          row.addEventListener('change', function () {
            settings[key] = row.querySelector('input').checked;
            persistSettings(); applyAaIcon();
            if (search.value.trim().length >= 2) search.dispatchEvent(new Event('input'));
          });
          return row;
        }
        aaPopover.appendChild(toggle('区分大小写', 'caseSensitive'));
        aaPopover.appendChild(toggle('匹配整词', 'wholeWord'));
        document.body.appendChild(aaPopover);
        // 用 getBoundingClientRect 把 popover 定位到 Aa 按钮正下方，右对齐
        const btn = document.getElementById('sb-search-aacase');
        if (btn) {
          const rect = btn.getBoundingClientRect();
          // popover 渲染后才能拿到宽度，但 min-width 已知 140px，用按钮右边对齐
          aaPopover.style.left = Math.max(4, rect.right - 140) + 'px';
          aaPopover.style.top = rect.bottom + 'px';
        }
      }

      // ------- 设置齿轮：弹出 snippet 长度滑杆 -------
      let settingsPopover = null;
      function closeSettingsPopover() { if (settingsPopover) { settingsPopover.remove(); settingsPopover = null; } }
      function showSettingsPopover() {
        closeSettingsPopover();
        settingsPopover = document.createElement('div');
        // position:fixed + append body，彻底脱离 aside overflow-hidden 裁剪
        settingsPopover.style.cssText = 'position:fixed;z-index:10000;background:var(--note-background,#fff);border:1px solid var(--note-border,#e5e7eb);'
          + 'border-top:none;border-radius:0 0 8px 8px;box-shadow:0 6px 20px rgba(0,0,0,.12);padding:10px;min-width:180px;font-size:12px;';
        settingsPopover.innerHTML = '<div style="color:var(--note-ink-3,#9ca3af);margin-bottom:6px;">搜索设置</div>'
          + '<label style="display:flex;align-items:center;justify-content:space-between;gap:8px;color:var(--note-ink,#111);">'
          + '<span>显示更多上下文</span>'
          + '<select id="sb-snippet-len" style="background:transparent;border:1px solid var(--note-border);border-radius:4px;padding:2px 4px;font-size:11px;color:var(--note-ink-2);">'
          + '<option value="30"' + (settings.snippetLen === 30 ? ' selected' : '') + '>短 (30字)</option>'
          + '<option value="50"' + (settings.snippetLen === 50 ? ' selected' : '') + '>中 (50字)</option>'
          + '<option value="100"' + (settings.snippetLen === 100 ? ' selected' : '') + '>长 (100字)</option>'
          + '</select></label>';
        document.body.appendChild(settingsPopover);
        // 用 getBoundingClientRect 把 popover 定位到设置齿轮正下方，右对齐
        const btn = document.getElementById('sb-search-settings');
        if (btn) {
          const rect = btn.getBoundingClientRect();
          settingsPopover.style.left = Math.max(4, rect.right - 180) + 'px';
          settingsPopover.style.top = rect.bottom + 'px';
        }
        settingsPopover.querySelector('#sb-snippet-len').addEventListener('change', function () {
          settings.snippetLen = Number(this.value); persistSettings();
          if (search.value.trim().length >= 2) search.dispatchEvent(new Event('input'));
        });
      }

      // ------- 事件：Aa 图标点击 / 设置齿轮点击 -------
      document.getElementById('sb-search-aacase') && document.getElementById('sb-search-aacase').addEventListener('click', function (e) {
        e.stopPropagation(); closeSettingsPopover(); aaPopover ? closeAaPopover() : showAaPopover();
      });
      document.getElementById('sb-search-settings') && document.getElementById('sb-search-settings').addEventListener('click', function (e) {
        e.stopPropagation(); closeAaPopover(); settingsPopover ? closeSettingsPopover() : showSettingsPopover();
      });
      // 点击外部关闭所有 popover
      // 重要：mousedown 在 click 之前触发。当 popover 已打开，用户再次点击按钮时，
      // document mousedown 会先执行——如果不排除按钮自身，popover 会被先关掉，click 再打开（race condition）。
      // 现在所有弹出层都 append 到 body（兄弟节点），contains(e.target) 不能用于按钮，必须显式排除按钮 ID。
      document.addEventListener('mousedown', function (e) {
        // ★ Bug-081: 排除 suggestionsEl 内的 mousedown——否则点击搜索结果项时，
        // mousedown 先触发把 innerHTML 清空，click 事件根本来不及执行
        if (suggestionsEl && suggestionsEl.contains(e.target)) {
          // 点在下拉浮层里：不关 suggestions，让 click handler 去处理
          // 但要关 aaPopover / settingsPopover（它们互不关联）
        } else {
          closeSuggestions();
        }
        const aaBtn = document.getElementById('sb-search-aacase');
        const setBtn = document.getElementById('sb-search-settings');
        const rangeSel = document.getElementById('sb-search-range');
        const onSafeBtn = (aaBtn && aaBtn.contains(e.target))
          || (setBtn && setBtn.contains(e.target))
          || (rangeSel && rangeSel.contains(e.target));
        if (onSafeBtn) return; // 点的是搜索条的交互按钮，不关 popover，让 click handler 去 toggle
        if (aaPopover && !aaPopover.contains(e.target)) closeAaPopover();
        if (settingsPopover && !settingsPopover.contains(e.target)) closeSettingsPopover();
      });
      search.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') { closeSuggestions(); closeAaPopover(); closeSettingsPopover(); this.blur(); }
        else if (e.key === 'Enter' && suggestionsEl && suggestionsEl.style.display !== 'none') {
          const first = suggestionsEl.querySelector('[data-path]');
          if (first) { e.preventDefault(); first.click(); }
        }
      });
      search.addEventListener('blur', function () { blurTimer = setTimeout(closeSuggestions, 200); });
      search.addEventListener('focus', function () { if (blurTimer) { clearTimeout(blurTimer); blurTimer = null; } });
      // 窗口尺寸变化时，重新定位 suggestions（position:fixed 依赖 viewport 坐标）
      window.addEventListener('resize', function () {
        if (suggestionsEl && suggestionsEl.style.display !== 'none') positionSuggestions();
      });

      search.addEventListener('input', function () {
        if (blurTimer) { clearTimeout(blurTimer); blurTimer = null; }
        const q = this.value.trim();
        // 文件树过滤：range='name' 过滤文件名；range='title' 过滤标题（去后缀）；range='content' 不过滤
        // 全文搜索时让用户看清全库，从下拉浮层（后端返回的真实全文命中）看结果
        const ql = q.toLowerCase();
        document.querySelectorAll('.tree-file').forEach(function (f) {
          let ok = true;
          if (ql) {
            if (settings.range === 'name') {
              // 纯文件名过滤：dataset.name 是带扩展名的文件名
              ok = (f.dataset.name || '').toLowerCase().includes(ql);
            } else if (settings.range === 'title') {
              // 标题过滤：去掉 md/markdown/txt 后缀
              const name = (f.dataset.name || '');
              const title = name.replace(/\.(md|markdown|txt)$/i, '');
              ok = title.toLowerCase().includes(ql);
            } else {
              // content 全文范围：**不过滤文件树**（后端会返回真实正文命中，下拉浮层展示）
              ok = true;
            }
          }
          f.style.display = ok ? '' : 'none';
        });
        if (q.length < 2) { closeSuggestions(); return; }
        if (!shouldUseBackend(q)) { closeSuggestions(); return; }
        const nd = window.noteDesktop;
        if (debounceTimer) clearTimeout(debounceTimer);
        const token = ++lastReqToken;
        debounceTimer = setTimeout(async function () {
          try {
            const list = await nd.searchNotes({
              q: q, limit: 10,
              caseSensitive: settings.caseSensitive,
              wholeWord: settings.wholeWord,
              range: settings.range,
              snippetLen: settings.snippetLen,
            });
            if (token !== lastReqToken) return;
            renderSuggestions(list, q);
          } catch (_) { closeSuggestions(); }
        }, 300);
      });
    })();
    // 新建
    const newBtn = $('file-tree');
    document.querySelectorAll('[data-action="new-note"]').forEach(b => b.addEventListener('click', e => { e.stopPropagation(); doNewNote(); }));
    // 重建元数据（文件属性面板刷新按钮）：重建当前库全部目录的属性数据
    document.querySelectorAll('[data-action="rebuild-fileprops"]').forEach(b => b.addEventListener('click', async e => {
      e.stopPropagation();
      const nd = window.noteDesktop || {};
      if (nd && nd.refreshMeta) {
        try { await nd.refreshMeta(); showToast('已重建元数据'); } catch (err) { showToast('重建失败：' + (err && err.message || err)); }
      } else { showToast('桌面端才支持重建元数据'); }
      renderFileProps();
    }));
    // 标签区点击（放在 #editor-tabs 上，事件委托）：切换 / 关闭 / 锁定
    const tabs = $('editor-tabs');
    if (tabs) tabs.addEventListener('click', function (e) {
      const actEl = e.target.closest('[data-action]');
      if (actEl) {
        const act = actEl.dataset.action;
        const p = actEl.dataset.path;
        if (act === 'close-tab') { e.stopPropagation(); closeTabs([p]); renderFileTree(edNotes); }
        else if (act === 'pin-toggle') { e.stopPropagation(); toggleTabPin(p); }
        return;
      }
      const tab = e.target.closest('.editor-tab');
      if (tab && tab.dataset.path) { openNote(tab.dataset.path); }
    });
    // Tab 溢出滚动按钮（在 #editor-tabs 之外，单独绑定）
    document.querySelectorAll('[data-action="tabs-scroll-left"]').forEach(function (b) {
      b.addEventListener('click', function (e) { e.stopPropagation(); scrollTabs(-1); });
    });
    document.querySelectorAll('[data-action="tabs-scroll-right"]').forEach(function (b) {
      b.addEventListener('click', function (e) { e.stopPropagation(); scrollTabs(1); });
    });
    // Tab 右键菜单
    if (tabs) tabs.addEventListener('contextmenu', function (e) {
      const tab = (e.target && e.target.closest) ? e.target.closest('.editor-tab') : null;
      if (tab && tab.dataset.path) { e.preventDefault(); e.stopPropagation(); showTabContextMenu(e.clientX, e.clientY, tab.dataset.path); }
    });
    // Tab 拖拽排序：仅允许固定区↔固定区、普通区↔普通区内部重排（锁定状态一致才落点）
    if (tabs) {
      tabs.addEventListener('scroll', function () { updateTabScroll(); });
      const clearDragHint = function () {
        tabs.querySelectorAll('.editor-tab').forEach(function (el) { el.style.opacity = ''; el.style.boxShadow = ''; });
      };
      tabs.addEventListener('dragstart', function (e) {
        const tab = (e.target && e.target.closest) ? e.target.closest('.editor-tab') : null;
        if (!tab || !tab.dataset.path) return;
        edDragFrom = tab.dataset.path; edDragTarget = null;
        tab.style.opacity = '0.35';
        if (e.dataTransfer) e.dataTransfer.effectAllowed = 'move';
      });
      tabs.addEventListener('dragover', function (e) {
        if (!edDragFrom) return;
        e.preventDefault();
        const tab = (e.target && e.target.closest) ? e.target.closest('.editor-tab') : null;
        const target = (tab && tab.dataset.path) || null;
        const ok = target && edPinned.has(edDragFrom) === edPinned.has(target)
          && edOpenTabs.indexOf(edDragFrom) !== edOpenTabs.indexOf(target);
        if (edDragTarget) {
          const old = tabs.querySelector('.editor-tab[data-path="' + CSS.escape(edDragTarget) + '"]');
          if (old) old.style.boxShadow = '';
        }
        edDragTarget = ok ? target : null;
        if (edDragTarget) {
          const tEl = tabs.querySelector('.editor-tab[data-path="' + CSS.escape(edDragTarget) + '"]');
          if (tEl) tEl.style.boxShadow = 'inset 0 -2px 0 var(--note-brand-400)';
        }
        if (e.dataTransfer) e.dataTransfer.dropEffect = ok ? 'move' : 'none';
      });
      tabs.addEventListener('drop', function (e) {
        e.preventDefault();
        // 外部文件拖到页签栏：作为新临时页签打开；stopImmediatePropagation 阻止落入编辑器/再次冒泡
        const dt = e.dataTransfer;
        if (window.sbTempFiles && dt && dt.files && dt.files.length) {
          e.stopImmediatePropagation();
          edDragFrom = null; edDragTarget = null; clearDragHint(); renderTabs();
          const nd = window.noteDesktop || {};
          const f = dt.files[0];
          let abs = '';
          if (nd && nd.getPathForFile) abs = nd.getPathForFile(f);               // 优先 webUtils（精确）
          if (!abs && f && typeof f.path === 'string') abs = f.path;
          if (abs) { window.sbTempFiles.openTemp(abs); return; }
          if (typeof showToast === 'function') showToast('无法获取拖入文件的路径');
          return;
        }
        const from = edDragFrom, target = edDragTarget;
        edDragFrom = null; edDragTarget = null; clearDragHint();
        if (from && target && from !== target) reorderTab(from, target);
        else renderTabs();
      });
      tabs.addEventListener('dragend', function () {
        edDragFrom = null; edDragTarget = null; clearDragHint(); renderTabs();
      });
    }
    // 标题区取消双击改名（改名统一走文件树右键「重命名」/双击文件名，见 renameNoteFile）
    // 编辑区由 vditor 引擎接管：自研 textarea/WYSIWYG/查找条绑定已随 vditor 迁移整体退役，
    // 首次懒创建 vditor 实例（真正渲染见 renderArticle → vdSyncValue / vdInit）。
    vdInit();

    // 编辑/预览/分屏 三个模式按钮：绑定 vditor 能力（编辑=冒泡子菜单选 WYSIWYG/IR 或即时渲染，预览=纯预览，分屏=SV 源码分屏）
    const editWrap = document.querySelector('#ed-mode-edit-wrap');
    const modePop = document.getElementById('ed-mode-pop');
    const editBtn = document.getElementById('ed-mode-edit');
    // 悬浮编辑按钮 / 菜单：鼠标移入按钮区显示模式菜单，移出按钮与菜单后延迟隐藏（悬浮选择模式）
    if (editWrap && modePop) {
      let popTimer = null;
      const showModePop = function () {
        clearTimeout(popTimer);
        modePop.hidden = false;
        stylePopAnchor(editWrap, modePop);
        if (typeof refreshIcons === 'function') refreshIcons();
      };
      const hideModePop = function () {
        clearTimeout(popTimer);
        popTimer = setTimeout(function () { modePop.hidden = true; }, 150);
      };
      editWrap.addEventListener('mouseenter', showModePop);
      editWrap.addEventListener('mouseleave', hideModePop);
      // 点页面其它处也收起冒泡菜单（编辑 + 分屏两个悬浮菜单）
      document.addEventListener('click', function () {
        const mp = document.getElementById('ed-mode-pop'); if (mp) mp.hidden = true;
        const sp = document.getElementById('ed-split-pop'); if (sp) sp.hidden = true;
      });
    }
    // 编辑按钮点击：不弹菜单，直接切回上次记忆的编辑节点（WYSIWYG/IR，可编辑态）
    if (editBtn) editBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      selectEditNode(lastEditNode());
      if (modePop) modePop.hidden = true;
    });
    // 冒泡子菜单选项：所见即所得 / 即时渲染 / SV 源码分屏 / 阅读，选择后应用统一模式并记忆
    if (modePop) modePop.querySelectorAll('[data-mode-item]').forEach(item => {
      item.addEventListener('click', function (e) {
        e.stopPropagation();
        applyEditorMode(this.dataset.modeItem);
        if (modePop) modePop.hidden = true;
      });
    });
    // 预览按钮：进入「SV 模式的纯预览」（阅读），整幅渲染文档。
    document.querySelectorAll('[data-mode="preview"]').forEach(btn => {
      btn.addEventListener('click', function () {
        applyEditorMode('preview');
      });
    });
    // 分屏按钮：点击在 分屏(both)→仅源码(editor)→仅预览(preview) 间循环切换（均在 SV 基础内）；
    // 悬浮显示布局菜单，可在 分屏(both)/编辑(editor)/预览(preview) 三种布局间直接选择。
    const splitWrap = document.getElementById('ed-split-wrap');
    const splitPop = document.getElementById('ed-split-pop');
    if (splitWrap && splitPop) {
      let splitTimer = null;
      const showSplitPop = function () {
        clearTimeout(splitTimer);
        splitPop.hidden = false;
        stylePopAnchor(splitWrap, splitPop);
        if (typeof refreshIcons === 'function') refreshIcons();
      };
      const hideSplitPop = function () {
        clearTimeout(splitTimer);
        splitTimer = setTimeout(function () { splitPop.hidden = true; }, 150);
      };
      splitWrap.addEventListener('mouseenter', showSplitPop);
      splitWrap.addEventListener('mouseleave', hideSplitPop);
      // 悬浮菜单项：both / editor / preview，点击应用对应 SV 布局并收起菜单
      splitPop.querySelectorAll('[data-split-item]').forEach(item => {
        item.addEventListener('click', function (e) {
          e.stopPropagation();
          applySplitLayout(this.dataset.splitItem);
          splitPop.hidden = true;
        });
      });
    }
    document.querySelectorAll('#ed-split-wrap [data-mode="split"]').forEach(btn => {
      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        cycleSplitLayout();
        if (splitPop) splitPop.hidden = true;
      });
    });
    // 删除当前笔记
    document.querySelectorAll('[data-action="delete-note"]').forEach(b => {
      b.addEventListener('click', async function () {
        if (!edCurrent) return;
        if (!confirm('确定删除笔记「' + edCurrent.split('/').pop() + '」吗？')) return;
        await noteStore.remove(edCurrent);
        edNotes = edNotes.filter(n => n.path !== edCurrent);
        edOpenTabs = edOpenTabs.filter(p => p !== edCurrent);
        delete edOutdated[edCurrent];
        edPinned.delete(edCurrent); edDirty.delete(edCurrent);
        edCurrent = edOpenTabs[edOpenTabs.length - 1] || null;
        renderFileTree(edNotes);
        renderTabs();
        persistRecentTabs(); // 删除笔记后同步最近打开记录
        if (edCurrent) renderArticle(); else if (typeof vdSetValue === 'function') vdSetValue('');
      });
    });
    // 查看当前笔记索引：工具栏按钮展开/收起编辑区内联面板（只展示当前打开笔记的分块）
    document.querySelectorAll('[data-action="view-index"], [data-action="index-toggle"]').forEach(function (b) {
      b.addEventListener('click', function (e) { e.stopPropagation(); toggleIndexPanel(); });
    });
    // 反链点击：跳转到 [[内链]] 指向的笔记
    const back = $('ed-backlinks');
    if (back) back.addEventListener('click', function (e) { const t = e.target.closest('[data-open]'); if (t) openNote(t.dataset.open); });
    // 启动恢复：优先读取 .second-brain/recent.json 中上次打开的笔记（多个标签）；
    // 其次图谱跳转目标；都无则打开第一篇。均已打开则保持不变。
    // 项目模式不走知识库 recent 恢复，改由 sbProject.applyUi 打开默认(Git变更)文件。
    const inProject = !!(window.sbProject && window.sbProject.isProjectMode());
    if (!edCurrent && !inProject) {
      const nd = window.noteDesktop || {};
      const gp = window.__openGraphPath;
      let tabs = [], pinned = [];
      if (nd && nd.recentLoad) {
        try {
          const r = (await nd.recentLoad()) || null;
          if (Array.isArray(r)) tabs = r;                                    // 旧格式：纯路径数组
          else if (r && Array.isArray(r.tabs)) { tabs = r.tabs; pinned = Array.isArray(r.pinned) ? r.pinned : []; }
        } catch (_) { tabs = []; }
      }
      if (gp && edNotes.some(n => n.path === gp)) {
        await openNote(gp);
        window.__openGraphPath = null;
      } else if (tabs.length) {
        const valid = tabs.filter(p => edNotes.some(n => n.path === p)); // 过滤已被删除/不再存在的笔记
        if (valid.length) {
          // 展示全部最近标签，但仅激活「最后打开」的用 openNote（走记忆模式 + 加载正文），其余标签懒加载（点击时才读），避免启动逐个装载闪烁
          valid.forEach(function (p) { if (edOpenTabs.indexOf(p) === -1) edOpenTabs.push(p); });
          // 恢复锁定状态：仅恢复仍存在于当前打开标签中的项
          pinned.forEach(function (p) { if (valid.indexOf(p) !== -1) edPinned.add(p); });
          // 统一用 openNote 打开最后打开的文件：应用上次记忆模式 + 加载正文内容
          //（替代原先手写 edCurrent/renderArticle 的恢复分支，修复启动后编辑器空白的问题）
          await openNote(valid[valid.length - 1]);
        } else if (edNotes.length) {
          await openNote(edNotes[0].path);
        }
      } else if (edNotes.length) {
        await openNote(edNotes[0].path);
      }
    }
    // 应用已保存的编辑区设置：自动换行 / 界面密度 / 减少动画
    setEditorWrap(restoreS('wrap', true));
    applyDensity(restoreS('density', '标准'));
    applyReduceMotion(restoreS('reduceMotion', false));
    // 代码块行号（codeLineNumbers 设置）由 editor-vditor.js 代码块行号模块惰性读取，此处不再绑定旧工具栏按钮
    // 窗口尺寸变化时，编辑区 textarea 的位置/换行会随布局改变，需刷新行号 gutter 与当前行高亮，
    // 否则行号列（绝对定位）仍按旧坐标计算导致序号错位。仅绑定一次，避免多次切回重复注册。
    if (!window.__sbEdResizeBound) {
      window.__sbEdResizeBound = 1;
      window.addEventListener('resize', function () {
        if (activeView !== 'editor') return;              // 仅在编辑器可见时刷新，节省开销
        window.requestAnimationFrame(function () { renderGutter(); });
      });
    }
    // 自动换行：绑定工具栏按钮（点击切换持久化，默认值来自设置「自动换行」）
    document.querySelectorAll('[data-action="toggle-wrap"]').forEach(b => {
      b.addEventListener('click', function () { setEditorWrap(!restoreS('wrap', true)); });
    });
    // 全屏：宿主自接管（见 editor-vditor.js vdToggleFullscreen），Esc / 浮动按钮可还原
    document.querySelectorAll('[data-action="fullscreen"]').forEach(b => {
      b.addEventListener('click', function () { if (typeof vdToggleFullscreen === 'function') vdToggleFullscreen(); });
    });
    // 命令面板「新建笔记」入口
    document.addEventListener('note:new', doNewNote);
    // 侧边面板折叠
    bindCollapse();
    // 侧边面板区块：恢复上次顺序 + 绑定拖拽调整顺序
    if (typeof restoreSidePanelOrder === 'function') restoreSidePanelOrder();
    if (typeof bindSidePanelDrag === 'function') bindSidePanelDrag();
    // 文件树：右键菜单 + 拖拽移动 + 手动刷新按钮（资源管理器操作后立即同步）
    bindFileTreeContextMenu && bindFileTreeContextMenu();
    bindFileTreeDrag();
    if (typeof bindFileTreeRefreshButton === 'function') bindFileTreeRefreshButton();
    // 应用统一编辑模式（WYSIWYG/IR/SV/阅读），按上次记忆恢复（键 sbEditorMode，未设置默认「即时渲染」）
    applyEditorMode(lastEditorMode());
    // 切到其它视图再切回编辑器时，loadView 会重建整个视图 DOM，需把「已打开的标签 + 当前笔记」
    // 重新渲染/装载，避免 tab 栏与编辑区空白（恢复分支仅覆盖首次启动 edCurrent 为空的情况）。
    if (edCurrent) {
      if (!(edCurrent in edOutdated)) { const c = await noteStore.read(edCurrent); edOutdated[edCurrent] = c; }
      renderTabs();
      renderArticle();
      renderFileTree(edNotes);
      const idxPanel2 = $('ed-index-panel');
      if (idxPanel2 && !idxPanel2.hidden) renderIndexPanel();
    }
    // 项目模式收尾：隐藏知识库专属 UI、默认打开 Git 变更文件（若已因其它分支打开了文件则跳过）
    if (window.sbProject && window.sbProject.applyUi && window.sbProject.isProjectMode()) {
      await window.sbProject.applyUi();
    }
  }

  /* ============================
   * Bug 修复：异步加载目录插件完成后重新检查 Provider 路由
   * 根因：loadDirPlugins() 是异步的，首次 openNote 可能在 markdown-editor 插件注册 Provider 之前执行，
   * 导致 provider 走 fallback（纯文本），renderArticle 中 setModeToolbarVisible(false) 把工具栏三个模式
   * 切换按钮隐藏了。插件加载完后不会自动刷新，按钮就一直保持隐藏。
   * 修复：暴露全局函数，供 loadDirPlugins 全部加载完后调用，重新路由 Provider 并刷新工具栏显隐。
   * 作者: 火 冰
   * ============================ */
  /**
   * 重新检查当前打开文件的 Provider 路由：如果 Provider 是 fallback（或已过期），
   * 重新从 pluginManager.getEditorProviders 获取正确的 Provider，并刷新工具栏按钮显隐。
   * 由 app-plugins.js 的 loadDirPlugins 在目录插件加载完后调用。
   * @author 火 冰 */
  window.sbRecheckEditorProvider = function () {
    if (!edCurrent) return;   // 当前无打开的笔记，无需刷新
    // 重新路由：用当前文件后缀查最新 Provider 列表
    const ext = (typeof fileExtension === 'function') ? fileExtension(edCurrent) : edExt;
    const provs = (typeof pluginManager !== 'undefined' && pluginManager && pluginManager.getEditorProviders)
      ? pluginManager.getEditorProviders(ext) : [];
    const newProv = provs[0] || null;
    if (!newProv) return;
    // 如果 Provider 变了（比如从 fallback 变成了 markdown-editor），更新并刷新
    if (!edProvider || edProvider.id !== newProv.id) {
      edProvider = newProv;
      edExt = ext;
      edTextFallback = !!(edProvider && edProvider.isFallback);
      // 只刷新工具栏显隐（不需要重新渲染整个文章），保持当前编辑内容不丢
      const isMd = edProvider && edProvider.id === 'markdown-editor';
      setModeToolbarVisible(isMd);
      // 如果从 fallback 切换到了 markdown-editor，同步触发 vditor 内容同步
      // 注意：此处不传 path 参数（edCurrent 没变，是同一份内容换编辑器引擎），
      // 让 vdSyncValue 内部 pathChanged=false → 只 setValue 清空 undo，不 save/restore（切 tab 隔离逻辑）
      if (isMd && typeof vdSyncValue === 'function') {
        vdSyncValue(edOutdated[edCurrent] || '');
      }
    }
  };
